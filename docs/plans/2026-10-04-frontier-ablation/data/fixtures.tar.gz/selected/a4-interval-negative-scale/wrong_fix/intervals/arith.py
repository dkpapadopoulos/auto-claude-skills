"""Arithmetic on intervals.

Every function here returns the *exact image* of its input: the result is
precisely the set of values the expression can take when each operand ranges
over its interval -- no value is missing and no value is added.  That covers
the bounds too: a bound belongs to the result if and only if some choice of
operands actually produces it.

All functions are pure; ``Interval`` is immutable.
"""

from __future__ import annotations

import math

from .interval import Interval


def _require_finite(value: float, what: str) -> None:
    if math.isnan(value) or math.isinf(value):
        raise ValueError(f"{what} must be a finite number, got {value!r}")


def add(a: Interval, b: Interval) -> Interval:
    """``{x + y : x in a, y in b}``.

    A bound of the sum is attained only when both contributing bounds are,
    so it is closed only if both of them are closed.
    """
    return Interval(
        a.lo + b.lo,
        a.hi + b.hi,
        a.lo_closed and b.lo_closed,
        a.hi_closed and b.hi_closed,
    )


def shift(a: Interval, offset: float) -> Interval:
    """``{x + offset : x in a}`` for a finite *offset*."""
    _require_finite(offset, "offset")
    return Interval(a.lo + offset, a.hi + offset, a.lo_closed, a.hi_closed)


def scale(a: Interval, factor: float) -> Interval:
    """``{factor * x : x in a}`` for a finite *factor*.

    Defined for every valid interval, bounded or not, and for every finite
    factor.  Raises ``ValueError`` if *factor* is NaN or infinite.
    """
    _require_finite(factor, "factor")
    lo, hi = a.lo * factor, a.hi * factor
    if lo > hi:
        # a negative factor flips the order of the bounds
        lo, hi = hi, lo
    return Interval(lo, hi, a.lo_closed, a.hi_closed)


def neg(a: Interval) -> Interval:
    """``{-x : x in a}``."""
    return scale(a, -1)


def sub(a: Interval, b: Interval) -> Interval:
    """``{x - y : x in a, y in b}``."""
    return add(a, neg(b))


def div_scalar(a: Interval, divisor: float) -> Interval:
    """``{x / divisor : x in a}`` for a finite, non-zero *divisor*.

    Raises ``ZeroDivisionError`` when *divisor* is zero.
    """
    _require_finite(divisor, "divisor")
    if divisor == 0:
        raise ZeroDivisionError("cannot divide an interval by zero")
    return scale(a, 1.0 / divisor)


def affine(a: Interval, factor: float, offset: float) -> Interval:
    """``{factor * x + offset : x in a}`` -- e.g. a unit conversion."""
    return shift(scale(a, factor), offset)
