import math
import unittest

from intervals import (
    Interval,
    add,
    affine,
    div_scalar,
    neg,
    parse,
    scale,
    sub,
)


class NegativeFactorTests(unittest.TestCase):
    def test_scale_negative_closed(self):
        self.assertEqual(scale(Interval(1, 2), -3), Interval(-6, -3))

    def test_scale_negative_moves_open_upper_bound_to_lower(self):
        # [1, 2) * -1 == (-2, -1]
        self.assertEqual(
            scale(Interval(1, 2, True, False), -1), Interval(-2, -1, False, True)
        )

    def test_scale_negative_moves_open_lower_bound_to_upper(self):
        # (1, 2] * -2 == [-4, -2)
        self.assertEqual(
            scale(Interval(1, 2, False, True), -2), Interval(-4, -2, True, False)
        )

    def test_scale_negative_membership_matches_image(self):
        result = scale(Interval(1, 2, True, False), -1)
        self.assertTrue(result.contains(-1))
        self.assertTrue(result.contains(-1.5))
        self.assertFalse(result.contains(-2))

    def test_scale_negative_unbounded(self):
        # [1, +inf) * -1 == (-inf, -1]
        self.assertEqual(scale(Interval.at_least(1), -1), Interval.at_most(-1))


class ZeroFactorTests(unittest.TestCase):
    def test_scale_zero_closed(self):
        self.assertEqual(scale(Interval(1, 2), 0), Interval.point(0))

    def test_scale_zero_open_interval_is_the_point_zero(self):
        self.assertEqual(scale(Interval.open(1, 2), 0), Interval.point(0))

    def test_scale_zero_unbounded_interval_is_the_point_zero(self):
        self.assertEqual(scale(Interval.at_least(1), 0), Interval.point(0))
        self.assertEqual(scale(Interval.less_than(-3), 0), Interval.point(0))


class DerivedOperationTests(unittest.TestCase):
    def test_neg_and_sub_closed(self):
        self.assertEqual(neg(Interval(1, 2)), Interval(-2, -1))
        self.assertEqual(sub(Interval(5, 10), Interval(1, 2)), Interval(3, 9))

    def test_sub_half_open(self):
        # [5, 10] - [1, 2) == (3, 9]
        self.assertEqual(
            sub(Interval(5, 10), Interval(1, 2, True, False)),
            Interval(3, 9, False, True),
        )

    def test_div_scalar_negative(self):
        # [2, 4) / -2 == (-2, -1]
        self.assertEqual(
            div_scalar(Interval(2, 4, True, False), -2),
            Interval(-2, -1, False, True),
        )

    def test_affine_negative_slope(self):
        # -2 * [0, 10) + 5 == (-15, 5]
        self.assertEqual(
            affine(Interval(0, 10, True, False), -2, 5),
            Interval(-15, 5, False, True),
        )


class UnchangedBehaviourTests(unittest.TestCase):
    def test_positive_factor_and_add_unchanged(self):
        self.assertEqual(
            scale(Interval(1, 2, True, False), 3), Interval(3, 6, True, False)
        )
        self.assertEqual(
            scale(Interval.greater_than(2), 0.5), Interval.greater_than(1)
        )
        self.assertEqual(
            add(Interval(1, 2, True, False), Interval(10, 20)),
            Interval(11, 22, True, False),
        )

    def test_reversed_bounds_are_still_rejected(self):
        with self.assertRaises(ValueError):
            Interval(2, 1)
        with self.assertRaises(ValueError):
            Interval(math.inf, 0, False, False)
        with self.assertRaises(ValueError):
            parse("[5, 1]")


if __name__ == "__main__":
    unittest.main()
