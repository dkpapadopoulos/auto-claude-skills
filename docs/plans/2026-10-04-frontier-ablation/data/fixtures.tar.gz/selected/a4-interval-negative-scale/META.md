# a4-interval-negative-scale

Category a (small bug fix with a regression trap). Domain: numeric interval arithmetic.

Hidden test file: `hidden_tests/test_scale_image.py`. Changed file: `intervals/arith.py` (`scale`).

| Hidden test | Required by |
|---|---|
| `NegativeFactorTests.test_scale_negative_closed` | TASK.md: "`scale(a, k)` has to be the set `{k * x : x in a}` for **every** finite `k` and **every** valid interval `a`" (also the reported failure: "everything else that ends up multiplying by a negative number: `scale(a, -3)`") |
| `NegativeFactorTests.test_scale_negative_moves_open_upper_bound_to_lower` | TASK.md: "`[1, 2)` scaled by `-1` is `(-2, -1]`" |
| `NegativeFactorTests.test_scale_negative_moves_open_lower_bound_to_upper` | TASK.md: "`(1, 2]` scaled by `-2` is `[-4, -2)`" |
| `NegativeFactorTests.test_scale_negative_membership_matches_image` | TASK.md: "a bound is included in the result exactly when the value it comes from was included in the input"; `Interval.contains` docstring |
| `NegativeFactorTests.test_scale_negative_unbounded` | TASK.md: "Unbounded intervals work too: `[1, +inf)` scaled by `-1` is `(-inf, -1]`" |
| `ZeroFactorTests.test_scale_zero_closed` | TASK.md: "The image of any interval under multiplication by zero is the single point `[0, 0]`" |
| `ZeroFactorTests.test_scale_zero_open_interval_is_the_point_zero` | TASK.md: "That must hold whatever `a` is — closed, open such as `(1, 2)`, or unbounded such as `[1, +inf)` — and must not raise" |
| `ZeroFactorTests.test_scale_zero_unbounded_interval_is_the_point_zero` | same sentence ("or unbounded such as `[1, +inf)`") |
| `DerivedOperationTests.test_neg_and_sub_closed` | TASK.md: "I expected `[3, 9]`. `neg(Interval(1, 2))` fails the same way (expected `[-2, -1]`)" |
| `DerivedOperationTests.test_sub_half_open` | TASK.md: "`sub([5, 10], [1, 2))` is `(3, 9]`" |
| `DerivedOperationTests.test_div_scalar_negative` | TASK.md: "`div_scalar([2, 4), -2)` is `(-2, -1]`" |
| `DerivedOperationTests.test_affine_negative_slope` | TASK.md: "`affine([0, 10), -2, 5)` is `(-15, 5]`" |
| `UnchangedBehaviourTests.test_positive_factor_and_add_unchanged` | TASK.md: "Positive factor. Unchanged from today: `[1, 2)` scaled by `3` is `[3, 6)`"; README examples for `add` / `scale`; `add` docstring |
| `UnchangedBehaviourTests.test_reversed_bounds_are_still_rejected` | TASK.md: "`Interval(2, 1)` and `parse("[5, 1]")` must keep raising `ValueError`"; `Interval` docstring ("bounds are never silently reordered") |

**Trap:** the obvious fix reorders the two products for a negative factor but leaves the open/closed flags where they were, and still multiplies the bounds for a zero factor — so half-open results have the wrong bound excluded, `[1, +inf) * -1` raises (closed infinite bound), and `(1, 2) * 0` / `[1, +inf) * 0` raise (empty interval / NaN). The visible tests only exercise closed, bounded intervals with negative factors, so they pass.

`wrong_fix/` implements exactly that; a second tempting wrong fix (making `Interval.__post_init__` swap reversed bounds) is caught by `test_reversed_bounds_are_still_rejected` and by the flag tests.
