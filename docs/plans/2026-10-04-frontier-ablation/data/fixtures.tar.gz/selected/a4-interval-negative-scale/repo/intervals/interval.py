"""Real-number intervals whose bounds are independently open or closed."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Interval:
    """A non-empty, connected set of real numbers.

    ``lo_closed`` / ``hi_closed`` say whether the bound itself belongs to the
    set: ``Interval(1, 2, True, False)`` is ``[1, 2)`` -- it contains 1 but
    not 2.  Both flags default to ``True`` (a closed interval).

    The constructor enforces these invariants and raises ``ValueError`` when
    one is violated:

    * neither bound is NaN;
    * ``lo <= hi`` -- bounds are never silently reordered, a reversed pair is
      a caller error;
    * an infinite bound is always open (infinity is not a real number);
    * ``lo == hi`` is only allowed for the single point ``[x, x]``.  The
      empty set is not representable, so ``(x, x)``, ``[x, x)`` and
      ``(x, x]`` are rejected.
    """

    lo: float
    hi: float
    lo_closed: bool = True
    hi_closed: bool = True

    def __post_init__(self) -> None:
        if math.isnan(self.lo) or math.isnan(self.hi):
            raise ValueError("interval bounds must not be NaN")
        if self.lo > self.hi:
            raise ValueError(
                f"lower bound {self.lo} is greater than upper bound {self.hi}"
            )
        if (math.isinf(self.lo) and self.lo_closed) or (
            math.isinf(self.hi) and self.hi_closed
        ):
            raise ValueError("an infinite bound must be open")
        if self.lo == self.hi and not (self.lo_closed and self.hi_closed):
            raise ValueError("a single-point interval must be closed on both sides")

    # -- constructors ------------------------------------------------------

    @classmethod
    def point(cls, x: float) -> "Interval":
        """The single point ``[x, x]``."""
        return cls(x, x, True, True)

    @classmethod
    def open(cls, lo: float, hi: float) -> "Interval":
        """The open interval ``(lo, hi)``."""
        return cls(lo, hi, False, False)

    @classmethod
    def at_least(cls, lo: float) -> "Interval":
        """``[lo, +inf)``."""
        return cls(lo, math.inf, True, False)

    @classmethod
    def greater_than(cls, lo: float) -> "Interval":
        """``(lo, +inf)``."""
        return cls(lo, math.inf, False, False)

    @classmethod
    def at_most(cls, hi: float) -> "Interval":
        """``(-inf, hi]``."""
        return cls(-math.inf, hi, False, True)

    @classmethod
    def less_than(cls, hi: float) -> "Interval":
        """``(-inf, hi)``."""
        return cls(-math.inf, hi, False, False)

    # -- queries -----------------------------------------------------------

    @property
    def is_point(self) -> bool:
        return self.lo == self.hi

    @property
    def is_bounded(self) -> bool:
        return not (math.isinf(self.lo) or math.isinf(self.hi))

    @property
    def width(self) -> float:
        """``hi - lo``; ``inf`` for an unbounded interval."""
        return self.hi - self.lo

    def contains(self, x: float) -> bool:
        """Whether the real number *x* is a member of the interval."""
        if x < self.lo or x > self.hi:
            return False
        if x == self.lo and not self.lo_closed:
            return False
        if x == self.hi and not self.hi_closed:
            return False
        return True

    # -- set operations ----------------------------------------------------

    def intersection(self, other: "Interval") -> Optional["Interval"]:
        """The common part of two intervals, or ``None`` if they are disjoint."""
        if self.lo > other.lo:
            lo, lo_closed = self.lo, self.lo_closed
        elif self.lo < other.lo:
            lo, lo_closed = other.lo, other.lo_closed
        else:
            lo, lo_closed = self.lo, self.lo_closed and other.lo_closed

        if self.hi < other.hi:
            hi, hi_closed = self.hi, self.hi_closed
        elif self.hi > other.hi:
            hi, hi_closed = other.hi, other.hi_closed
        else:
            hi, hi_closed = self.hi, self.hi_closed and other.hi_closed

        if lo > hi or (lo == hi and not (lo_closed and hi_closed)):
            return None
        return Interval(lo, hi, lo_closed, hi_closed)

    def hull(self, other: "Interval") -> "Interval":
        """The smallest interval containing both *self* and *other*."""
        if self.lo < other.lo:
            lo, lo_closed = self.lo, self.lo_closed
        elif self.lo > other.lo:
            lo, lo_closed = other.lo, other.lo_closed
        else:
            lo, lo_closed = self.lo, self.lo_closed or other.lo_closed

        if self.hi > other.hi:
            hi, hi_closed = self.hi, self.hi_closed
        elif self.hi < other.hi:
            hi, hi_closed = other.hi, other.hi_closed
        else:
            hi, hi_closed = self.hi, self.hi_closed or other.hi_closed

        return Interval(lo, hi, lo_closed, hi_closed)
