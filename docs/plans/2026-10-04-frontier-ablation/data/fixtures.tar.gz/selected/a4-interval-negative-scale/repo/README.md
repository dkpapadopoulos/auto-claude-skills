# intervals

Small, dependency-free library for exact arithmetic on real intervals.

## Model

An `Interval` is a non-empty connected set of reals. Each bound is
independently *closed* (the bound belongs to the set, written `[` / `]`) or
*open* (it does not, written `(` / `)`).

    Interval(1, 2)                 # [1, 2]
    Interval(1, 2, True, False)    # [1, 2)
    Interval.at_least(1)           # [1, +inf)
    Interval.point(3)              # [3, 3]

`Interval` validates its arguments and raises `ValueError` for NaN bounds,
reversed bounds (`lo > hi`), a closed infinite bound, and for the empty set
(`lo == hi` with either side open). It never reorders or repairs what it is
given.

## Arithmetic

`intervals.arith` provides `add`, `sub`, `neg`, `shift`, `scale`,
`div_scalar` and `affine`.

Every operation returns the **exact image** of its operands: the result is
precisely the set of values the expression can take, bounds included. A bound
of the result is closed if and only if that value is really attained.

    add([1, 2), [10, 20])   ->  [11, 22)
    shift((0, 1], 5)        ->  (5, 6]
    scale([1, 2), 3)        ->  [3, 6)

`neg`, `sub`, `div_scalar` and `affine` are defined in terms of `add`, `shift`
and `scale`.

## Notation

`parse("[1, 2)")` and `format_interval(...)` convert to and from text.

## Tests

    python3 -m unittest discover tests
