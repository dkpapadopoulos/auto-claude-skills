import unittest

from intervals import Interval, format_interval, parse


class NotationTests(unittest.TestCase):
    def test_parse_half_open(self):
        self.assertEqual(parse("[1, 2)"), Interval(1, 2, True, False))

    def test_parse_unbounded(self):
        self.assertEqual(parse("(-inf, 0]"), Interval.at_most(0))

    def test_parse_malformed(self):
        with self.assertRaises(ValueError):
            parse("1..2")

    def test_format_round_trip(self):
        for text in ("[1, 2)", "(-inf, 0]", "[3, 3]", "(0.5, +inf)"):
            self.assertEqual(format_interval(parse(text)), text)


if __name__ == "__main__":
    unittest.main()
