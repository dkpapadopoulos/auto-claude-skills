"""Text notation for intervals: ``[1, 2)``, ``(-inf, 0]``, ``[3, 3]``."""

from __future__ import annotations

import math
import re

from .interval import Interval

_PATTERN = re.compile(r"^\s*([\[(])\s*([^,\s]+)\s*,\s*([^,\s]+)\s*([\])])\s*$")


def _number(token: str) -> float:
    if token in ("inf", "+inf"):
        return math.inf
    if token == "-inf":
        return -math.inf
    try:
        value = float(token)
    except ValueError:
        raise ValueError(f"not a number: {token!r}") from None
    if math.isnan(value) or math.isinf(value):
        raise ValueError(f"not a number: {token!r}")
    return value


def parse(text: str) -> Interval:
    """Parse ``"[lo, hi)"`` style notation.

    Square brackets mean the bound is included, round brackets that it is
    excluded.  ``inf``, ``+inf`` and ``-inf`` are accepted as bounds.  Raises
    ``ValueError`` for malformed text and for anything ``Interval`` itself
    rejects (reversed bounds such as ``"[5, 1]"``, a closed infinite bound,
    an empty interval such as ``"(2, 2)"``).
    """
    match = _PATTERN.match(text)
    if match is None:
        raise ValueError(f"not an interval: {text!r}")
    opener, lo_token, hi_token, closer = match.groups()
    return Interval(
        _number(lo_token),
        _number(hi_token),
        opener == "[",
        closer == "]",
    )


def _format_number(value: float) -> str:
    if math.isinf(value):
        return "+inf" if value > 0 else "-inf"
    if value == int(value):
        return str(int(value))
    return repr(float(value))


def format_interval(interval: Interval) -> str:
    """The inverse of :func:`parse`: ``Interval(1, 2, True, False)`` -> ``"[1, 2)"``."""
    opener = "[" if interval.lo_closed else "("
    closer = "]" if interval.hi_closed else ")"
    return (
        f"{opener}{_format_number(interval.lo)}, "
        f"{_format_number(interval.hi)}{closer}"
    )
