import unittest

from intervals import Interval, add, div_scalar, neg, scale, shift, sub


class AddShiftTests(unittest.TestCase):
    def test_add_closed(self):
        self.assertEqual(add(Interval(1, 2), Interval(10, 20)), Interval(11, 22))

    def test_add_open_bound_propagates(self):
        self.assertEqual(
            add(Interval(1, 2, True, False), Interval(10, 20)),
            Interval(11, 22, True, False),
        )

    def test_shift(self):
        self.assertEqual(
            shift(Interval(0, 1, False, True), 5), Interval(5, 6, False, True)
        )


class ScaleTests(unittest.TestCase):
    def test_scale_positive(self):
        self.assertEqual(
            scale(Interval(1, 2, True, False), 3), Interval(3, 6, True, False)
        )

    def test_scale_rejects_infinite_factor(self):
        with self.assertRaises(ValueError):
            scale(Interval(1, 2), float("inf"))

    def test_neg_closed(self):
        self.assertEqual(neg(Interval(1, 2)), Interval(-2, -1))

    def test_sub_closed(self):
        self.assertEqual(sub(Interval(5, 10), Interval(1, 2)), Interval(3, 9))


class DivScalarTests(unittest.TestCase):
    def test_div_scalar_positive(self):
        self.assertEqual(div_scalar(Interval(2, 4), 2), Interval(1, 2))

    def test_div_scalar_by_zero(self):
        with self.assertRaises(ZeroDivisionError):
            div_scalar(Interval(2, 4), 0)


if __name__ == "__main__":
    unittest.main()
