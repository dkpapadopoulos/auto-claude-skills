import math
import unittest

from intervals import Interval


class IntervalValidationTests(unittest.TestCase):
    def test_nan_bound_rejected(self):
        with self.assertRaises(ValueError):
            Interval(math.nan, 1)

    def test_closed_infinite_bound_rejected(self):
        with self.assertRaises(ValueError):
            Interval(0, math.inf)

    def test_empty_interval_rejected(self):
        with self.assertRaises(ValueError):
            Interval(2, 2, True, False)

    def test_point_is_allowed(self):
        self.assertTrue(Interval.point(2).is_point)


class IntervalQueryTests(unittest.TestCase):
    def test_contains_respects_open_bound(self):
        iv = Interval(1, 2, True, False)
        self.assertTrue(iv.contains(1))
        self.assertTrue(iv.contains(1.5))
        self.assertFalse(iv.contains(2))

    def test_width(self):
        self.assertEqual(Interval(1, 4).width, 3)
        self.assertEqual(Interval.at_least(1).width, math.inf)

    def test_intersection(self):
        a = Interval(0, 5)
        b = Interval(5, 9, False, True)
        self.assertIsNone(a.intersection(b))
        self.assertEqual(
            Interval(0, 5).intersection(Interval(3, 9)), Interval(3, 5)
        )

    def test_hull(self):
        self.assertEqual(
            Interval(0, 1, False, True).hull(Interval(4, 6, True, False)),
            Interval(0, 6, False, False),
        )


if __name__ == "__main__":
    unittest.main()
