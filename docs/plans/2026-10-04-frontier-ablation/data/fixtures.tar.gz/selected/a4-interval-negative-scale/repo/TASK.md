# `sub` / `neg` raise "lower bound is greater than upper bound"

## What happens

Subtracting one interval from another blows up:

    >>> from intervals import Interval, sub
    >>> sub(Interval(5, 10), Interval(1, 2))
    ValueError: lower bound -1 is greater than upper bound -2

I expected `[3, 9]`. `neg(Interval(1, 2))` fails the same way (expected
`[-2, -1]`), and so does everything else that ends up multiplying by a
negative number: `scale(a, -3)`, `div_scalar(a, -2)`, `affine(a, -2, 5)`.

`tests/test_arith.py` has two tests for this, `test_neg_closed` and
`test_sub_closed`; both fail at the moment.

## What "fixed" means

The README and the `intervals.arith` docstring promise that every operation
returns the exact image of its input, so `scale(a, k)` has to be the set
`{k * x : x in a}` for **every** finite `k` and **every** valid interval `a`,
with the right bounds included or excluded. Please make that true in general,
not only for the example above:

* **Negative factor.** The result is the mirrored, stretched interval, and a
  bound is included in the result exactly when the value it comes from was
  included in the input. `[1, 2)` scaled by `-1` is `(-2, -1]`; `(1, 2]`
  scaled by `-2` is `[-4, -2)`. Unbounded intervals work too: `[1, +inf)`
  scaled by `-1` is `(-inf, -1]`.
* **Zero factor.** The image of any interval under multiplication by zero is
  the single point `[0, 0]`. That must hold whatever `a` is — closed, open
  such as `(1, 2)`, or unbounded such as `[1, +inf)` — and must not raise.
* **Positive factor.** Unchanged from today: `[1, 2)` scaled by `3` is
  `[3, 6)`.
* **Everything built on `scale`.** `neg`, `sub`, `div_scalar` and `affine`
  must return the exact image as well. For example
  `sub([5, 10], [1, 2))` is `(3, 9]`, `div_scalar([2, 4), -2)` is `(-2, -1]`
  and `affine([0, 10), -2, 5)` is `(-15, 5]`.
* **`Interval` validation is not part of the problem.** `Interval(2, 1)` and
  `parse("[5, 1]")` must keep raising `ValueError`, as documented; reversed
  bounds passed in by a caller are still an error.

No API changes, please — same function names and signatures.
