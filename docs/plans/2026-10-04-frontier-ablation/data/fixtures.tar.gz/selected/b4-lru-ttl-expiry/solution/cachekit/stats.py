"""Counters kept by a cache."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass
class CacheStats:
    """Running totals for one cache.

    * ``hits`` -- ``get`` calls that found a value
    * ``misses`` -- ``get`` calls that did not
    * ``evictions`` -- entries pushed out because the cache was full
    * ``expirations`` -- entries dropped because their TTL ran out

    ``snapshot()`` has one key per counter, named like the attribute.
    """

    hits: int = 0
    misses: int = 0
    evictions: int = 0
    expirations: int = 0

    def record_hit(self) -> None:
        self.hits += 1

    def record_miss(self) -> None:
        self.misses += 1

    def record_eviction(self) -> None:
        self.evictions += 1

    def record_expiration(self) -> None:
        self.expirations += 1

    @property
    def requests(self) -> int:
        return self.hits + self.misses

    @property
    def hit_rate(self) -> float:
        """Fraction of ``get`` calls that hit; ``0.0`` before any request."""
        if self.requests == 0:
            return 0.0
        return self.hits / self.requests

    def snapshot(self) -> Dict[str, int]:
        """A plain-dict copy of every counter, safe to log or serialise."""
        return {
            "hits": self.hits,
            "misses": self.misses,
            "evictions": self.evictions,
            "expirations": self.expirations,
        }

    def reset(self) -> None:
        """Set every counter back to zero."""
        self.hits = 0
        self.misses = 0
        self.evictions = 0
        self.expirations = 0
