"""A capacity-bounded least-recently-used cache with optional per-entry TTL.

Recency
    ``get`` (on a hit) and ``put`` make a key the most recently used one.
    ``peek``, ``in``, ``age``, ``ttl_remaining`` and ``keys`` never change
    recency.

Statistics
    Only ``get`` counts hits and misses.  See :class:`cachekit.stats.CacheStats`.

Expiry
    An entry stored at time ``t`` with a TTL of ``d`` seconds is expired once
    ``clock.now() >= t + d``.  An expired entry behaves as absent for every
    operation.  Expired entries are dropped when the cache next looks at them
    (or all at once by ``purge_expired``); each drop is counted in
    ``stats.expirations`` and reported to the listener.

Eviction listener
    ``on_evict(key, value, reason)`` is called once for every entry the cache
    removes *on its own initiative*, after the entry is gone from the cache.
    ``reason`` is ``"capacity"`` (the entry was the least recently used one
    when room was needed) or ``"expired"`` (its TTL ran out).  Explicit
    removals by the caller -- ``delete()`` and ``clear()`` -- do not notify
    the listener and are not counted in the statistics.

Time
    The cache reads time only through the injected clock's ``now()``.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Hashable, List, Optional

from .recency import RecencyList
from .stats import CacheStats

REASON_CAPACITY = "capacity"
REASON_EXPIRED = "expired"

EvictListener = Callable[[Hashable, Any, str], None]


def _check_ttl(ttl: Optional[float]) -> None:
    if ttl is not None and not ttl > 0:
        raise ValueError("ttl must be positive")


class _Entry:
    __slots__ = ("value", "stored_at", "expires_at")

    def __init__(self, value: Any, stored_at: float, expires_at: Optional[float]) -> None:
        self.value = value
        self.stored_at = stored_at
        self.expires_at = expires_at

    def expired(self, now: float) -> bool:
        return self.expires_at is not None and now >= self.expires_at


class LRUCache:
    """Maps keys to values, keeping at most ``capacity`` entries."""

    def __init__(
        self,
        capacity: int,
        clock: Any,
        on_evict: Optional[EvictListener] = None,
        default_ttl: Optional[float] = None,
    ) -> None:
        if isinstance(capacity, bool) or not isinstance(capacity, int) or capacity < 1:
            raise ValueError("capacity must be a positive integer")
        _check_ttl(default_ttl)
        self._capacity = capacity
        self._clock = clock
        self._on_evict = on_evict
        self._default_ttl = default_ttl
        self._entries: Dict[Hashable, _Entry] = {}
        self._order = RecencyList()
        self._stats = CacheStats()

    @property
    def capacity(self) -> int:
        return self._capacity

    @property
    def stats(self) -> CacheStats:
        return self._stats

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, key: Hashable) -> bool:
        return self._live(key) is not None

    def get(self, key: Hashable, default: Any = None) -> Any:
        """Return the value for *key*, or *default* if it is not cached.

        Counts a hit or a miss; a hit makes the key the most recently used.
        Never extends the entry's TTL.
        """
        entry = self._live(key)
        if entry is None:
            self._stats.record_miss()
            return default
        self._order.touch(key)
        self._stats.record_hit()
        return entry.value

    def peek(self, key: Hashable, default: Any = None) -> Any:
        """Like :meth:`get` but without touching recency or statistics."""
        entry = self._live(key)
        if entry is None:
            return default
        return entry.value

    def put(self, key: Hashable, value: Any, ttl: Optional[float] = None) -> None:
        """Store *value* under *key* and make it the most recently used.

        *ttl* is the entry's lifetime in seconds; ``None`` means the cache's
        ``default_ttl`` (and no expiry at all if that is ``None`` too).

        Overwriting a live key never evicts anything and restarts its expiry.
        Storing a new key in a full cache first evicts the least recently
        used entry.
        """
        _check_ttl(ttl)
        if ttl is None:
            ttl = self._default_ttl
        now = self._clock.now()
        expires_at = None if ttl is None else now + ttl

        entry = self._live(key)
        if entry is not None:
            entry.value = value
            entry.stored_at = now
            entry.expires_at = expires_at
            self._order.touch(key)
            return
        if len(self._entries) >= self._capacity:
            self._evict_oldest()
        self._entries[key] = _Entry(value, now, expires_at)
        self._order.add(key)

    def delete(self, key: Hashable) -> bool:
        """Remove *key*.  Returns whether it was cached (and still live)."""
        if self._live(key) is None:
            return False
        del self._entries[key]
        self._order.remove(key)
        return True

    def clear(self) -> None:
        """Remove everything.  Statistics are kept; the listener is not called."""
        self._entries.clear()
        self._order.clear()

    def keys(self) -> List[Hashable]:
        """Cached keys, most recently used first."""
        return list(self._order)

    def age(self, key: Hashable) -> float:
        """Seconds since *key* was last stored with ``put``.

        Raises ``KeyError`` if the key is not cached.
        """
        entry = self._live(key)
        if entry is None:
            raise KeyError(key)
        return self._clock.now() - entry.stored_at

    def ttl_remaining(self, key: Hashable) -> Optional[float]:
        """Seconds until *key* expires, or ``None`` if it never does.

        Raises ``KeyError`` if the key is not cached.
        """
        entry = self._live(key)
        if entry is None:
            raise KeyError(key)
        if entry.expires_at is None:
            return None
        return entry.expires_at - self._clock.now()

    def purge_expired(self) -> int:
        """Drop every expired entry; return how many were dropped."""
        now = self._clock.now()
        expired = [key for key, entry in self._entries.items() if entry.expired(now)]
        for key in expired:
            self._expire(key)
        return len(expired)

    # -- internals ---------------------------------------------------------

    def _live(self, key: Hashable) -> Optional[_Entry]:
        """The entry for *key* if it is cached and not expired, else None.

        An expired entry is dropped on the way.
        """
        entry = self._entries.get(key)
        if entry is None:
            return None
        if entry.expired(self._clock.now()):
            self._expire(key)
            return None
        return entry

    def _expire(self, key: Hashable) -> None:
        entry = self._entries.pop(key)
        self._order.remove(key)
        self._stats.record_expiration()
        if self._on_evict is not None:
            self._on_evict(key, entry.value, REASON_EXPIRED)

    def _evict_oldest(self) -> None:
        key = self._order.oldest()
        entry = self._entries.pop(key)
        self._order.remove(key)
        self._stats.record_eviction()
        if self._on_evict is not None:
            self._on_evict(key, entry.value, REASON_CAPACITY)
