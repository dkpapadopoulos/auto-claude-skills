"""Recency ordering for cache keys.

``RecencyList`` keeps a set of keys ordered from most recently used to least
recently used.  Every operation is O(1) except iteration.
"""

from __future__ import annotations

from typing import Dict, Hashable, Iterator, Optional


class _Node:
    __slots__ = ("key", "newer", "older")

    def __init__(self, key: Optional[Hashable]) -> None:
        self.key = key
        self.newer: Optional["_Node"] = None
        self.older: Optional["_Node"] = None


class RecencyList:
    """Keys in most-recently-used-first order."""

    def __init__(self) -> None:
        # Sentinels: _front.older is the most recent key, _back.newer the
        # least recent one.
        self._front = _Node(None)
        self._back = _Node(None)
        self._front.older = self._back
        self._back.newer = self._front
        self._nodes: Dict[Hashable, _Node] = {}

    def __len__(self) -> int:
        return len(self._nodes)

    def __contains__(self, key: Hashable) -> bool:
        return key in self._nodes

    def __iter__(self) -> Iterator[Hashable]:
        """Yield keys from most to least recently used."""
        node = self._front.older
        while node is not self._back:
            assert node is not None
            yield node.key
            node = node.older

    def add(self, key: Hashable) -> None:
        """Insert a new key as the most recently used one.

        Raises ``ValueError`` if the key is already tracked; use
        :meth:`touch` for that.
        """
        if key in self._nodes:
            raise ValueError(f"key already tracked: {key!r}")
        node = _Node(key)
        self._nodes[key] = node
        self._link_front(node)

    def touch(self, key: Hashable) -> None:
        """Mark an existing key as the most recently used one.

        Raises ``KeyError`` if the key is not tracked.
        """
        node = self._nodes[key]
        self._unlink(node)
        self._link_front(node)

    def remove(self, key: Hashable) -> None:
        """Stop tracking a key.  Raises ``KeyError`` if it is not tracked."""
        node = self._nodes.pop(key)
        self._unlink(node)

    def oldest(self) -> Hashable:
        """The least recently used key.  Raises ``LookupError`` when empty."""
        node = self._back.newer
        if node is self._front or node is None:
            raise LookupError("recency list is empty")
        return node.key

    def clear(self) -> None:
        self._nodes.clear()
        self._front.older = self._back
        self._back.newer = self._front

    # -- internals ---------------------------------------------------------

    def _link_front(self, node: _Node) -> None:
        first = self._front.older
        assert first is not None
        node.newer = self._front
        node.older = first
        self._front.older = node
        first.newer = node

    @staticmethod
    def _unlink(node: _Node) -> None:
        assert node.newer is not None and node.older is not None
        node.newer.older = node.older
        node.older.newer = node.newer
        node.newer = node.older = None
