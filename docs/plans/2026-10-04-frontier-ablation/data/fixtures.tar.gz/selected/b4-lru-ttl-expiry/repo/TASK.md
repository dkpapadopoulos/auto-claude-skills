# Add per-entry TTL (expiry) to `LRUCache`

`cachekit.LRUCache` only bounds the number of entries. We also need entries
that go stale after a while (session tokens, rendered fragments). Please add
time-to-live support.

Time must come **only** from the injected clock (`clock.now()`), exactly like
`age()` does today — no `time.time()` / `time.monotonic()` anywhere.

`tests/test_ttl_basic.py` contains a few starter tests for this; they fail
until the feature exists. The tests in `tests/test_lru.py` must keep passing.

## API

```python
LRUCache(capacity, clock, on_evict=None, default_ttl=None)
cache.put(key, value, ttl=None)
cache.ttl_remaining(key)      # -> float | None
cache.purge_expired()         # -> int
cache.stats.expirations       # new counter on CacheStats
```

## Behaviour

1. **Which TTL applies.** A TTL is a number of seconds (int or float).
   `put(key, value, ttl=X)` uses `X`. With `ttl=None` the cache's
   `default_ttl` is used; if that is `None` too, the entry never expires.

2. **Validation.** A `ttl` passed to `put`, or a `default_ttl` passed to the
   constructor, that is zero or negative raises `ValueError` with the message
   `ttl must be positive`. A rejected `put` leaves the cache exactly as it
   was: nothing stored, nothing evicted or dropped, no counter changed, the
   listener not called.

3. **When an entry is expired.** An entry stored at clock time `t` with TTL
   `d` is live while `clock.now() < t + d` and expired as soon as
   `clock.now() >= t + d` (the boundary instant counts as expired).

4. **What restarts the timer.** Only `put`. `get` refreshes recency as it
   does today but never extends an entry's life. `put` on a key that is still
   live replaces the value and starts a fresh expiry from the time of that
   `put`, using that call's `ttl` (or the default, or "never" — rule 1); the
   TTL the entry had before is forgotten.

5. **Expired means absent.** For every operation an expired entry behaves as
   if it were not in the cache: `get` returns the default and counts a miss;
   `peek` returns the default; `key in cache` is `False`; `len(cache)` and
   `keys()` do not include it; `age(key)` and `ttl_remaining(key)` raise
   `KeyError`; `delete(key)` returns `False`; and `put(key, ...)` treats the
   key as new.

6. **Dropping expired entries.** Physically removing an expired entry is
   called *dropping* it, whichever call happens to do it. Each expired entry
   is dropped exactly once, and at that moment `stats.expirations` goes up by
   one (`stats.evictions` does not) and, if a listener is set,
   `on_evict(key, value, "expired")` is called. The cache may drop lazily,
   with these guarantees:
   * `get(key)` and `put(key, ...)` on an expired key have dropped it by the
     time they return;
   * a `put` that needs room drops expired entries first (rule 7);
   * `purge_expired()` drops every expired entry still held and returns how
     many it dropped in that call — so calling it again without moving the
     clock returns `0`.

7. **Capacity.** An expired entry must never cost a live entry its place.
   When `put` stores a new key and the cache is full, it first drops every
   expired entry; only if the cache is still full after that does it evict
   the least recently used entry, as today (reason `"capacity"`, counted in
   `stats.evictions`). Live entries are evicted by recency regardless of
   whether or when they would expire.

8. **`ttl_remaining(key)`** returns the seconds left before a live entry
   expires (its expiry time minus `clock.now()`), `None` for a live entry
   that never expires, and raises `KeyError` if the key is absent or expired.
   It does not change recency and does not count as a hit or a miss.

9. **Stats.** `CacheStats` gains an `expirations` counter that starts at 0,
   appears in `snapshot()` under the key `"expirations"` (next to the
   existing keys) and is zeroed by `reset()`.

10. **Everything else is unchanged.** `delete()` of a live key and `clear()`
    still never notify the listener or change any counter (`clear()` simply
    discards whatever is still held), and a cache that never sees a TTL
    behaves exactly as it does today.
