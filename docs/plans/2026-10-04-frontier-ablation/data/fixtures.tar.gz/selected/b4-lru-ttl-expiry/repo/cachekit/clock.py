"""Time sources.

The cache never reads the system time itself.  Whoever builds a cache hands it
a *clock*: any object with a ``now()`` method returning seconds as a number
that never goes backwards.  Production code wraps a monotonic timer; tests use
:class:`ManualClock` and move time by hand.
"""

from __future__ import annotations


class ManualClock:
    """A clock that only moves when told to."""

    def __init__(self, start: float = 0.0) -> None:
        self._now = float(start)

    def now(self) -> float:
        """Current time in seconds."""
        return self._now

    def advance(self, seconds: float) -> float:
        """Move time forward by *seconds* and return the new time.

        Raises ``ValueError`` for a negative step: time never goes backwards.
        """
        if seconds < 0:
            raise ValueError("cannot move a clock backwards")
        self._now += seconds
        return self._now
