import unittest

from cachekit import LRUCache, ManualClock


class LRUBehaviourTests(unittest.TestCase):
    def setUp(self):
        self.clock = ManualClock()
        self.events = []
        self.cache = LRUCache(
            2, self.clock, on_evict=lambda k, v, r: self.events.append((k, v, r))
        )

    def test_get_and_default(self):
        self.cache.put("a", 1)
        self.assertEqual(self.cache.get("a"), 1)
        self.assertEqual(self.cache.get("zzz", "fallback"), "fallback")

    def test_least_recently_used_is_evicted(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.cache.get("a")
        self.cache.put("c", 3)
        self.assertEqual(self.cache.keys(), ["c", "a"])
        self.assertEqual(self.events, [("b", 2, "capacity")])
        self.assertEqual(self.cache.stats.evictions, 1)

    def test_overwrite_does_not_evict(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.cache.put("a", 10)
        self.assertEqual(len(self.cache), 2)
        self.assertEqual(self.cache.keys(), ["a", "b"])
        self.assertEqual(self.events, [])

    def test_peek_and_contains_do_not_touch_recency_or_stats(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.assertEqual(self.cache.peek("a"), 1)
        self.assertIn("a", self.cache)
        self.assertEqual(self.cache.keys(), ["b", "a"])
        self.assertEqual(self.cache.stats.requests, 0)

    def test_delete_and_clear_do_not_notify(self):
        self.cache.put("a", 1)
        self.cache.put("b", 2)
        self.assertTrue(self.cache.delete("a"))
        self.assertFalse(self.cache.delete("a"))
        self.cache.clear()
        self.assertEqual(len(self.cache), 0)
        self.assertEqual(self.events, [])

    def test_age_uses_the_injected_clock(self):
        self.cache.put("a", 1)
        self.clock.advance(7)
        self.assertEqual(self.cache.age("a"), 7)
        self.cache.put("a", 2)
        self.assertEqual(self.cache.age("a"), 0)
        with self.assertRaises(KeyError):
            self.cache.age("missing")

    def test_capacity_must_be_positive_integer(self):
        for bad in (0, -1, 1.5, True):
            with self.assertRaises(ValueError):
                LRUCache(bad, self.clock)


class StatsTests(unittest.TestCase):
    def test_hit_rate_and_snapshot(self):
        cache = LRUCache(2, ManualClock())
        self.assertEqual(cache.stats.hit_rate, 0.0)
        cache.put("a", 1)
        cache.get("a")
        cache.get("b")
        snap = cache.stats.snapshot()
        self.assertEqual(snap["hits"], 1)
        self.assertEqual(snap["misses"], 1)
        self.assertEqual(snap["evictions"], 0)
        self.assertEqual(cache.stats.hit_rate, 0.5)
        cache.stats.reset()
        self.assertEqual(cache.stats.requests, 0)


if __name__ == "__main__":
    unittest.main()
