"""A capacity-bounded least-recently-used cache.

Recency
    ``get`` (on a hit) and ``put`` make a key the most recently used one.
    ``peek``, ``in``, ``age`` and ``keys`` never change recency.

Statistics
    Only ``get`` counts hits and misses.  See :class:`cachekit.stats.CacheStats`.

Eviction listener
    ``on_evict(key, value, reason)`` is called once for every entry the cache
    removes *on its own initiative*, after the entry is gone from the cache.
    ``reason`` is a short string; today the only one is ``"capacity"`` (the
    entry was the least recently used one when room was needed).  Explicit
    removals by the caller -- ``delete()`` and ``clear()`` -- do not notify
    the listener and are not counted in the statistics.

Time
    The cache reads time only through the injected clock's ``now()``.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Hashable, List, Optional

from .recency import RecencyList
from .stats import CacheStats

REASON_CAPACITY = "capacity"

EvictListener = Callable[[Hashable, Any, str], None]


class _Entry:
    __slots__ = ("value", "stored_at")

    def __init__(self, value: Any, stored_at: float) -> None:
        self.value = value
        self.stored_at = stored_at


class LRUCache:
    """Maps keys to values, keeping at most ``capacity`` entries."""

    def __init__(
        self,
        capacity: int,
        clock: Any,
        on_evict: Optional[EvictListener] = None,
    ) -> None:
        if isinstance(capacity, bool) or not isinstance(capacity, int) or capacity < 1:
            raise ValueError("capacity must be a positive integer")
        self._capacity = capacity
        self._clock = clock
        self._on_evict = on_evict
        self._entries: Dict[Hashable, _Entry] = {}
        self._order = RecencyList()
        self._stats = CacheStats()

    @property
    def capacity(self) -> int:
        return self._capacity

    @property
    def stats(self) -> CacheStats:
        return self._stats

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, key: Hashable) -> bool:
        return key in self._entries

    def get(self, key: Hashable, default: Any = None) -> Any:
        """Return the value for *key*, or *default* if it is not cached.

        Counts a hit or a miss; a hit makes the key the most recently used.
        """
        entry = self._entries.get(key)
        if entry is None:
            self._stats.record_miss()
            return default
        self._order.touch(key)
        self._stats.record_hit()
        return entry.value

    def peek(self, key: Hashable, default: Any = None) -> Any:
        """Like :meth:`get` but without touching recency or statistics."""
        entry = self._entries.get(key)
        if entry is None:
            return default
        return entry.value

    def put(self, key: Hashable, value: Any) -> None:
        """Store *value* under *key* and make it the most recently used.

        Overwriting an existing key never evicts anything.  Storing a new key
        in a full cache first evicts the least recently used entry.
        """
        now = self._clock.now()
        entry = self._entries.get(key)
        if entry is not None:
            entry.value = value
            entry.stored_at = now
            self._order.touch(key)
            return
        if len(self._entries) >= self._capacity:
            self._evict_oldest()
        self._entries[key] = _Entry(value, now)
        self._order.add(key)

    def delete(self, key: Hashable) -> bool:
        """Remove *key*.  Returns whether it was cached."""
        if key not in self._entries:
            return False
        del self._entries[key]
        self._order.remove(key)
        return True

    def clear(self) -> None:
        """Remove everything.  Statistics are kept; the listener is not called."""
        self._entries.clear()
        self._order.clear()

    def keys(self) -> List[Hashable]:
        """Cached keys, most recently used first."""
        return list(self._order)

    def age(self, key: Hashable) -> float:
        """Seconds since *key* was last stored with ``put``.

        Raises ``KeyError`` if the key is not cached.
        """
        entry = self._entries[key]
        return self._clock.now() - entry.stored_at

    # -- internals ---------------------------------------------------------

    def _evict_oldest(self) -> None:
        key = self._order.oldest()
        entry = self._entries.pop(key)
        self._order.remove(key)
        self._stats.record_eviction()
        if self._on_evict is not None:
            self._on_evict(key, entry.value, REASON_CAPACITY)
