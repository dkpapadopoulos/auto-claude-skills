"""Starter tests for the TTL feature described in TASK.md."""

import unittest

from cachekit import LRUCache, ManualClock


class TTLBasicTests(unittest.TestCase):
    def setUp(self):
        self.clock = ManualClock()
        self.cache = LRUCache(4, self.clock)

    def test_entry_expires_after_its_ttl(self):
        self.cache.put("a", 1, ttl=10)
        self.clock.advance(5)
        self.assertEqual(self.cache.get("a"), 1)
        self.clock.advance(20)
        self.assertIsNone(self.cache.get("a"))
        self.assertNotIn("a", self.cache)

    def test_entry_without_ttl_never_expires(self):
        self.cache.put("a", 1)
        self.clock.advance(10_000)
        self.assertEqual(self.cache.get("a"), 1)

    def test_non_positive_ttl_is_rejected(self):
        with self.assertRaises(ValueError):
            self.cache.put("a", 1, ttl=0)

    def test_ttl_remaining(self):
        self.cache.put("a", 1, ttl=10)
        self.clock.advance(4)
        self.assertEqual(self.cache.ttl_remaining("a"), 6)

    def test_purge_expired_reports_how_many_it_dropped(self):
        self.cache.put("a", 1, ttl=5)
        self.cache.put("b", 2, ttl=5)
        self.cache.put("c", 3)
        self.clock.advance(6)
        self.assertEqual(self.cache.purge_expired(), 2)
        self.assertEqual(self.cache.stats.expirations, 2)
        self.assertEqual(self.cache.get("c"), 3)


if __name__ == "__main__":
    unittest.main()
