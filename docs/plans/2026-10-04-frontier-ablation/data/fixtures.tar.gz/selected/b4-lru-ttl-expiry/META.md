# b4-lru-ttl-expiry

Category b (feature addition with stated edge cases). Domain: LRU + TTL caching with an injected clock (no wall-clock time; all tests drive `ManualClock`).

Hidden test file: `hidden_tests/test_ttl_contract.py`. Changed files: `cachekit/cache.py`, `cachekit/stats.py`. Fitting the feature in needs `cache.py` (entry record, eviction path, listener contract), `recency.py` (an expired key must leave the recency list too, and `keys()` iterates it) and `stats.py` (new counter in `snapshot()` / `reset()`); `clock.py` defines the only permitted time source.

| Hidden test | Required by (TASK.md, "Behaviour" rule) |
|---|---|
| `ExpiryTimingTests.test_boundary_instant_counts_as_expired` | Rule 3: "live while `clock.now() < t + d` and expired as soon as `clock.now() >= t + d` (the boundary instant counts as expired)" |
| `ExpiryTimingTests.test_only_put_restarts_the_timer` | Rule 4: "`get` refreshes recency as it does today but never extends an entry's life. `put` on a key that is still live replaces the value and starts a fresh expiry from the time of that `put`"; Rule 8 for the `ttl_remaining` value |
| `ExpiryTimingTests.test_default_ttl_per_put_override_and_forgetting_the_old_ttl` | Rule 1: "With `ttl=None` the cache's `default_ttl` is used; if that is `None` too, the entry never expires"; Rule 4: "using that call's `ttl` (or the default, or "never" — rule 1); the TTL the entry had before is forgotten"; Rule 5: "`put(key, ...)` treats the key as new" |
| `ExpiredMeansAbsentTests.test_len_and_keys_exclude_expired_entries` | Rule 5: "`len(cache)` and `keys()` do not include it" |
| `ExpiredMeansAbsentTests.test_key_lookups_treat_expired_entry_as_absent` | Rule 5: "`peek` returns the default; `key in cache` is `False`; ... `age(key)` and `ttl_remaining(key)` raise `KeyError`; `delete(key)` returns `False`"; Rule 6: "Physically removing an expired entry is called *dropping* it, whichever call happens to do it. Each expired entry is dropped exactly once, and at that moment `stats.expirations` goes up by one (`stats.evictions` does not) and ... `on_evict(key, value, "expired")` is called" + "`purge_expired()` drops every expired entry still held" |
| `ExpiredMeansAbsentTests.test_get_of_expired_key_is_a_miss_and_drops_it_once` | Rule 5: "`get` returns the default and counts a miss"; Rule 6: "`get(key)` and `put(key, ...)` on an expired key have dropped it by the time they return" and "dropped exactly once" |
| `ExpiredMeansAbsentTests.test_put_on_expired_key_is_a_fresh_insert` | Rule 5: "`put(key, ...)` treats the key as new"; Rule 6: "`get(key)` and `put(key, ...)` on an expired key have dropped it by the time they return"; Rule 1 (no ttl, no default -> never expires); existing `age` docstring |
| `CapacityTests.test_expired_entry_goes_before_a_live_least_recently_used_one` | Rule 7: "An expired entry must never cost a live entry its place. When `put` stores a new key and the cache is full, it first drops every expired entry; only if the cache is still full after that does it evict the least recently used entry" |
| `CapacityTests.test_put_that_needs_room_drops_every_expired_entry` | Rule 7: "it first drops every expired entry"; Rule 6 (each drop counted and reported, `purge_expired()` then returns 0) |
| `CapacityTests.test_live_entries_with_a_ttl_are_still_evicted_by_recency` | Rule 7: "as today (reason `"capacity"`, counted in `stats.evictions`). Live entries are evicted by recency regardless of whether or when they would expire" |
| `PurgeAndStatsTests.test_purge_expired_counts_and_is_idempotent` | Rule 6: "`purge_expired()` drops every expired entry still held and returns how many it dropped in that call — so calling it again without moving the clock returns `0`" |
| `PurgeAndStatsTests.test_expirations_counter_in_snapshot_and_reset` | Rule 9: "an `expirations` counter that starts at 0, appears in `snapshot()` under the key `"expirations"` (next to the existing keys) and is zeroed by `reset()`" |
| `ValidationAndRemainingTests.test_non_positive_ttl_is_rejected_and_leaves_the_cache_untouched` | Rule 2: "zero or negative raises `ValueError` with the message `ttl must be positive`. A rejected `put` leaves the cache exactly as it was: nothing stored, nothing evicted or dropped, no counter changed, the listener not called" |
| `ValidationAndRemainingTests.test_ttl_remaining_contract` | Rule 8: "returns the seconds left ... `None` for a live entry that never expires, and raises `KeyError` if the key is absent or expired. It does not change recency and does not count as a hit or a miss" |

Assertions on `stats.expirations` / listener events are only made at points where rule 6 guarantees the drop has happened (after `get`/`put` on that key, after a `put` that needed room, or after `purge_expired()`), so both lazy and eager implementations pass.

**Trap:** lazy-only expiry — checking the TTL just where a key is looked up. `len()` / `keys()` then still report expired entries, and a full cache evicts a live least-recently-used entry (reason "capacity") while an expired one keeps its slot.

`wrong_fix/` implements exactly that (TTL bookkeeping, validation, `ttl_remaining`, `purge_expired` and the stats counter are all correct); it passes every visible test and fails `test_len_and_keys_exclude_expired_entries`, `test_expired_entry_goes_before_a_live_least_recently_used_one` and `test_put_that_needs_room_drops_every_expired_entry`.
