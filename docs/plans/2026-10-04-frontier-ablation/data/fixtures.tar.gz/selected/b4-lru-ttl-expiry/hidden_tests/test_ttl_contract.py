import unittest

from cachekit import LRUCache, ManualClock


def make(capacity, **kwargs):
    """A cache on a manual clock plus the list its listener appends to."""
    clock = ManualClock()
    events = []
    cache = LRUCache(
        capacity,
        clock,
        on_evict=lambda key, value, reason: events.append((key, value, reason)),
        **kwargs,
    )
    return cache, clock, events


class ExpiryTimingTests(unittest.TestCase):
    def test_boundary_instant_counts_as_expired(self):
        cache, clock, _ = make(4)
        cache.put("a", 1, ttl=10)
        clock.advance(9.5)
        self.assertEqual(cache.get("a"), 1)
        clock.advance(0.5)  # now == stored time + ttl
        self.assertEqual(cache.get("a", "gone"), "gone")

    def test_only_put_restarts_the_timer(self):
        cache, clock, _ = make(4)
        cache.put("a", 1, ttl=10)
        cache.put("b", 1, ttl=10)
        clock.advance(6)
        self.assertEqual(cache.get("a"), 1)  # a hit must not extend a's life
        cache.put("b", 2, ttl=10)            # an overwrite starts b afresh
        clock.advance(6)                     # t = 12
        self.assertIsNone(cache.get("a"))
        self.assertEqual(cache.get("b"), 2)
        self.assertEqual(cache.ttl_remaining("b"), 4)

    def test_default_ttl_per_put_override_and_forgetting_the_old_ttl(self):
        cache, clock, _ = make(4, default_ttl=10)
        cache.put("a", 1)          # default: expires at 10
        cache.put("b", 2, ttl=3)   # expires at 3
        cache.put("c", 3, ttl=30)  # expires at 30
        clock.advance(3)
        self.assertNotIn("b", cache)
        self.assertIn("a", cache)
        cache.put("b", 20)         # no ttl given -> default again: expires at 13
        self.assertEqual(cache.ttl_remaining("b"), 10)
        clock.advance(7)           # t = 10
        self.assertNotIn("a", cache)
        self.assertIn("b", cache)
        self.assertEqual(cache.ttl_remaining("c"), 20)

        plain, plain_clock, _ = make(4)  # no default_ttl
        plain.put("k", 1, ttl=5)
        plain_clock.advance(1)
        plain.put("k", 2)          # no ttl, no default -> never expires
        self.assertIsNone(plain.ttl_remaining("k"))
        plain_clock.advance(1000)
        self.assertEqual(plain.get("k"), 2)


class ExpiredMeansAbsentTests(unittest.TestCase):
    def test_len_and_keys_exclude_expired_entries(self):
        cache, clock, _ = make(4)
        cache.put("a", 1, ttl=5)
        cache.put("b", 2)
        cache.put("c", 3, ttl=5)
        clock.advance(5)
        self.assertEqual(len(cache), 1)
        self.assertEqual(cache.keys(), ["b"])

    def test_key_lookups_treat_expired_entry_as_absent(self):
        cache, clock, events = make(4)
        cache.put("a", 1, ttl=5)
        clock.advance(5)
        self.assertNotIn("a", cache)
        self.assertEqual(cache.peek("a", "gone"), "gone")
        with self.assertRaises(KeyError):
            cache.age("a")
        with self.assertRaises(KeyError):
            cache.ttl_remaining("a")
        self.assertFalse(cache.delete("a"))
        # However lazily the entry was dropped, it was dropped exactly once.
        cache.purge_expired()
        self.assertEqual(cache.stats.expirations, 1)
        self.assertEqual(cache.stats.evictions, 0)
        self.assertEqual(events, [("a", 1, "expired")])

    def test_get_of_expired_key_is_a_miss_and_drops_it_once(self):
        cache, clock, events = make(4)
        cache.put("a", 1, ttl=5)
        clock.advance(5)
        self.assertEqual(cache.get("a", "gone"), "gone")
        self.assertEqual(cache.stats.misses, 1)
        self.assertEqual(cache.stats.hits, 0)
        self.assertEqual(cache.stats.expirations, 1)
        self.assertEqual(cache.stats.evictions, 0)
        self.assertEqual(events, [("a", 1, "expired")])
        self.assertEqual(cache.get("a", "gone"), "gone")
        self.assertEqual(cache.stats.misses, 2)
        self.assertEqual(cache.purge_expired(), 0)
        self.assertEqual(cache.stats.expirations, 1)
        self.assertEqual(events, [("a", 1, "expired")])

    def test_put_on_expired_key_is_a_fresh_insert(self):
        cache, clock, events = make(2)
        cache.put("a", 1, ttl=5)
        cache.put("b", 2)
        clock.advance(5)
        cache.put("a", 100)
        self.assertEqual(events, [("a", 1, "expired")])
        self.assertEqual(cache.stats.expirations, 1)
        self.assertEqual(cache.stats.evictions, 0)
        self.assertEqual(cache.get("a"), 100)
        self.assertEqual(cache.get("b"), 2)
        self.assertIsNone(cache.ttl_remaining("a"))
        self.assertEqual(cache.age("a"), 0)


class CapacityTests(unittest.TestCase):
    def test_expired_entry_goes_before_a_live_least_recently_used_one(self):
        cache, clock, events = make(2)
        cache.put("a", 1, ttl=10)
        cache.put("b", 2)
        cache.get("a")        # "b" is now the least recently used entry
        clock.advance(10)     # ... but "a" is the one that has expired
        cache.put("c", 3)
        self.assertEqual(cache.get("b"), 2)
        self.assertEqual(cache.get("c"), 3)
        self.assertEqual(events, [("a", 1, "expired")])
        self.assertEqual(cache.stats.expirations, 1)
        self.assertEqual(cache.stats.evictions, 0)

    def test_put_that_needs_room_drops_every_expired_entry(self):
        cache, clock, events = make(3)
        cache.put("a", 1, ttl=5)
        cache.put("b", 2, ttl=5)
        cache.put("c", 3)
        clock.advance(5)
        cache.put("d", 4)
        self.assertEqual(
            sorted(events), [("a", 1, "expired"), ("b", 2, "expired")]
        )
        self.assertEqual(cache.stats.expirations, 2)
        self.assertEqual(cache.stats.evictions, 0)
        self.assertEqual(cache.purge_expired(), 0)
        self.assertEqual(cache.keys(), ["d", "c"])

    def test_live_entries_with_a_ttl_are_still_evicted_by_recency(self):
        cache, clock, events = make(2)
        cache.put("a", 1, ttl=100)
        cache.put("b", 2, ttl=5)
        clock.advance(1)
        cache.get("b")        # "a" is least recently used, though it expires last
        cache.put("c", 3)
        self.assertEqual(events, [("a", 1, "capacity")])
        self.assertEqual(cache.stats.evictions, 1)
        self.assertEqual(cache.stats.expirations, 0)
        self.assertEqual(cache.keys(), ["c", "b"])


class PurgeAndStatsTests(unittest.TestCase):
    def test_purge_expired_counts_and_is_idempotent(self):
        cache, clock, events = make(4)
        cache.put("a", 1, ttl=5)
        cache.put("b", 2, ttl=50)
        cache.put("c", 3)
        clock.advance(5)
        self.assertEqual(cache.purge_expired(), 1)
        self.assertEqual(cache.purge_expired(), 0)
        self.assertEqual(events, [("a", 1, "expired")])
        self.assertEqual(cache.keys(), ["c", "b"])
        clock.advance(45)
        self.assertEqual(cache.purge_expired(), 1)
        self.assertEqual(cache.stats.expirations, 2)
        self.assertEqual(cache.keys(), ["c"])

    def test_expirations_counter_in_snapshot_and_reset(self):
        cache, clock, _ = make(4)
        self.assertEqual(cache.stats.expirations, 0)
        self.assertEqual(cache.stats.snapshot()["expirations"], 0)
        cache.put("a", 1, ttl=5)
        cache.put("b", 2, ttl=5)
        clock.advance(5)
        cache.purge_expired()
        snapshot = cache.stats.snapshot()
        self.assertEqual(snapshot["expirations"], 2)
        for existing in ("hits", "misses", "evictions"):
            self.assertIn(existing, snapshot)
        cache.stats.reset()
        self.assertEqual(cache.stats.expirations, 0)
        self.assertEqual(cache.stats.snapshot()["expirations"], 0)


class ValidationAndRemainingTests(unittest.TestCase):
    def test_non_positive_ttl_is_rejected_and_leaves_the_cache_untouched(self):
        for bad in (0, -1, -0.5):
            with self.assertRaises(ValueError) as ctx:
                LRUCache(2, ManualClock(), default_ttl=bad)
            self.assertEqual(str(ctx.exception), "ttl must be positive")
            with self.assertRaises(ValueError) as ctx:
                LRUCache(2, ManualClock()).put("a", 1, ttl=bad)
            self.assertEqual(str(ctx.exception), "ttl must be positive")

        cache, clock, events = make(2)
        cache.put("a", 1, ttl=10)
        cache.put("b", 2)
        with self.assertRaises(ValueError):
            cache.put("c", 3, ttl=0)   # new key, full cache
        with self.assertRaises(ValueError):
            cache.put("a", 99, ttl=-1)  # existing key
        self.assertEqual(events, [])
        self.assertEqual(cache.stats.evictions, 0)
        self.assertEqual(cache.stats.expirations, 0)
        self.assertEqual(cache.keys(), ["b", "a"])
        self.assertEqual(cache.peek("a"), 1)
        self.assertEqual(cache.ttl_remaining("a"), 10)

    def test_ttl_remaining_contract(self):
        cache, clock, _ = make(4)
        cache.put("a", 1, ttl=10)
        cache.put("b", 2)
        clock.advance(4)
        self.assertEqual(cache.ttl_remaining("a"), 6)
        self.assertIsNone(cache.ttl_remaining("b"))
        with self.assertRaises(KeyError):
            cache.ttl_remaining("missing")
        # neither recency nor hit/miss statistics are affected
        self.assertEqual(cache.keys(), ["b", "a"])
        self.assertEqual(cache.stats.requests, 0)


if __name__ == "__main__":
    unittest.main()
