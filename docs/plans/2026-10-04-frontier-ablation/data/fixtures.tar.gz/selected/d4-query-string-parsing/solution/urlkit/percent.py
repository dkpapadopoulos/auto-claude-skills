"""Percent-encoding and decoding (RFC 3986, section 2.1)."""

from __future__ import annotations

import string

from .errors import UrlError

UNRESERVED = frozenset(string.ascii_letters + string.digits + "-._~")

_HEX = "0123456789ABCDEF"
_HEX_DIGITS = frozenset(string.hexdigits)


def quote(text: str, safe: str = "") -> str:
    """Percent-encode ``text``.

    Unreserved characters (``A-Z a-z 0-9 - . _ ~``) and any character listed
    in ``safe`` are copied as they are.  Every other character is encoded as
    UTF-8 and each byte is written as ``%XX`` with upper-case hex digits.  A
    space becomes ``%20`` (never ``+``) and a plus sign becomes ``%2B``.
    """
    pieces = []
    for char in text:
        if char in UNRESERVED or char in safe:
            pieces.append(char)
            continue
        for byte in char.encode("utf-8"):
            pieces.append("%" + _HEX[byte >> 4] + _HEX[byte & 0x0F])
    return "".join(pieces)


def unquote(text: str, plus_as_space: bool = False) -> str:
    """Decode the percent-escapes in ``text``.

    ``%XX`` (hex digits in either case) stands for one byte; the decoded
    bytes are read as UTF-8.  All other characters are copied.

    With ``plus_as_space=True`` - the mode used for query strings - a
    literal ``+`` in ``text`` stands for a space.  An escaped plus (``%2B``)
    is a literal ``+`` in both modes.

    Raises ``UrlError`` when a ``%`` is not followed by exactly two
    hexadecimal digits, or when the decoded bytes are not valid UTF-8.
    """
    if plus_as_space:
        # Must happen before decoding: afterwards a literal "+" can no longer
        # be told apart from one that was written as %2B.
        text = text.replace("+", " ")
    raw = bytearray()
    index = 0
    while index < len(text):
        char = text[index]
        if char == "%":
            digits = text[index + 1:index + 3]
            if len(digits) != 2 or any(d not in _HEX_DIGITS for d in digits):
                raise UrlError(f"malformed percent-escape at offset {index}: {text!r}")
            raw.append(int(digits, 16))
            index += 3
        else:
            raw.extend(char.encode("utf-8"))
            index += 1
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise UrlError(f"percent-escapes are not valid UTF-8: {text!r}") from exc
