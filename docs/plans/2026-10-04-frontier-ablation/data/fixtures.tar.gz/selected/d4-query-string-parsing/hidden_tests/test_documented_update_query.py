import unittest

from urlkit.url import split_url, update_query


def params_of(url):
    return split_url(url).params()


class EmptyStringSetsTests(unittest.TestCase):
    def test_empty_string_sets_an_existing_parameter_to_empty(self):
        result = update_query("http://example.com/p?a=1&b=2", {"a": ""})
        self.assertEqual(result, "http://example.com/p?a=&b=2")

    def test_empty_string_adds_a_new_parameter_with_empty_value(self):
        result = update_query("http://example.com/p?a=1#f", {"debug": ""})
        self.assertEqual(params_of(result), [("a", "1"), ("debug", "")])
        self.assertEqual(split_url(result).fragment, "f")

    def test_none_still_removes_while_empty_string_sets(self):
        result = update_query(
            "http://example.com/p?a=1&b=2&a=3&c=4", {"a": "", "c": None}
        )
        self.assertEqual(params_of(result), [("a", ""), ("b", "2")])


class UntouchedParametersTests(unittest.TestCase):
    def test_untouched_value_with_equals_signs_keeps_its_value(self):
        result = update_query(
            "https://api.example.com/v1?sig=YWJj==&page=1", {"page": "2"}
        )
        self.assertEqual(params_of(result), [("sig", "YWJj=="), ("page", "2")])

    def test_plus_signs_in_a_new_value_survive(self):
        result = update_query("https://example.com/search?lang=en", {"q": "c++ tips"})
        self.assertEqual(params_of(result), [("lang", "en"), ("q", "c++ tips")])


if __name__ == "__main__":
    unittest.main()
