import unittest

from urlkit.errors import UrlError
from urlkit.percent import quote, unquote
from urlkit.query import build_query, parse_query


class EscapedPlusTests(unittest.TestCase):
    def test_escaped_plus_is_a_plus_in_both_modes(self):
        self.assertEqual(unquote("a+b%2Bc"), "a+b+c")
        self.assertEqual(unquote("a+b%2Bc", plus_as_space=True), "a b+c")
        self.assertEqual(unquote("%2b", plus_as_space=True), "+")

    def test_query_value_with_escaped_plus(self):
        self.assertEqual(
            parse_query("expr=1%2B1&q=c%2B%2B+tips"),
            [("expr", "1+1"), ("q", "c++ tips")],
        )

    def test_build_then_parse_returns_the_same_pairs(self):
        pairs = [
            ("q", "1+1=2"),
            ("name", "Zoë & co"),
            ("discount", "100%"),
            ("a b", "x+y"),
            ("empty", ""),
            ("q", "again"),
        ]
        self.assertEqual(parse_query(build_query(pairs)), pairs)


class MalformedEscapeTests(unittest.TestCase):
    def test_non_hex_escape_raises_url_error(self):
        with self.assertRaises(UrlError):
            unquote("%zz")
        with self.assertRaises(UrlError):
            parse_query("a=1&b=%G1")

    def test_percent_at_the_very_end_raises_url_error(self):
        with self.assertRaises(UrlError):
            unquote("100%")
        with self.assertRaises(UrlError):
            parse_query("discount=100%")

    def test_escape_with_a_single_hex_digit_raises_url_error(self):
        with self.assertRaises(UrlError):
            unquote("abc%4")
        with self.assertRaises(UrlError):
            parse_query("a=%4")

    def test_invalid_utf8_raises_url_error(self):
        with self.assertRaises(UrlError):
            unquote("%ff")
        with self.assertRaises(UrlError):
            parse_query("name=%C3")

    def test_quote_then_unquote_returns_the_original(self):
        for text in ("100% sure", "a+b", "Zoë/ß?", "~-._", ""):
            with self.subTest(text=text):
                self.assertEqual(unquote(quote(text)), text)


class FirstEqualsSignTests(unittest.TestCase):
    def test_later_equals_signs_belong_to_the_value(self):
        self.assertEqual(
            parse_query("token=YWJj==&page=1"),
            [("token", "YWJj=="), ("page", "1")],
        )
        self.assertEqual(parse_query("filter=a=b&x"), [("filter", "a=b"), ("x", "")])


if __name__ == "__main__":
    unittest.main()
