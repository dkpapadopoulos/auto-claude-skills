import unittest

from urlkit.errors import UrlError
from urlkit.url import Url, normalize, split_url, update_query


class SplitUrlTests(unittest.TestCase):
    def test_all_parts(self):
        self.assertEqual(
            split_url("https://Example.com:8443/a/b?x=1&y=2#top"),
            Url("https", "Example.com", 8443, "/a/b", "x=1&y=2", "top"),
        )

    def test_missing_parts_are_empty(self):
        self.assertEqual(split_url("http://example.com"), Url("http", "example.com"))

    def test_question_mark_after_hash_belongs_to_fragment(self):
        parts = split_url("http://example.com/p#section?x=1")
        self.assertEqual(parts.query, "")
        self.assertEqual(parts.fragment, "section?x=1")

    def test_geturl_round_trip(self):
        url = "http://[::1]:8080/a%20b?x=1#f"
        self.assertEqual(split_url(url).geturl(), url)

    def test_decoded_path_keeps_plus(self):
        self.assertEqual(split_url("http://example.com/a%20b+c").decoded_path(), "/a b+c")

    def test_rejects_relative_and_malformed_urls(self):
        for bad in ("example.com/path", "://example.com", "http:///path",
                    "http://user@example.com/", "http://example.com:http/",
                    "http://example.com:70000/", "http://example.com:/"):
            with self.subTest(url=bad):
                with self.assertRaises(UrlError):
                    split_url(bad)


class NormalizeTests(unittest.TestCase):
    def test_case_default_port_and_empty_path(self):
        self.assertEqual(normalize("HTTP://Example.COM:80"), "http://example.com/")

    def test_other_parts_are_untouched(self):
        self.assertEqual(
            normalize("https://example.com:8443/A?Q=1#F"),
            "https://example.com:8443/A?Q=1#F",
        )


class UpdateQueryTests(unittest.TestCase):
    def test_replaces_in_place_and_appends_new(self):
        self.assertEqual(
            update_query("http://example.com/p?a=1&b=2#f", {"a": "9", "c": "3"}),
            "http://example.com/p?a=9&b=2&c=3#f",
        )

    def test_none_removes_every_appearance(self):
        self.assertEqual(
            update_query("http://example.com/p?t=1&a=1&t=2", {"t": None, "zz": None}),
            "http://example.com/p?a=1",
        )

    def test_later_appearances_are_dropped_when_setting(self):
        self.assertEqual(
            update_query("http://example.com/p?t=1&a=1&t=2", {"t": "new"}),
            "http://example.com/p?t=new&a=1",
        )

    def test_no_question_mark_when_nothing_is_left(self):
        self.assertEqual(
            update_query("http://example.com/p?a=1", {"a": None}),
            "http://example.com/p",
        )


if __name__ == "__main__":
    unittest.main()
