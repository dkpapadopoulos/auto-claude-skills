"""Splitting, normalising and editing absolute URLs."""

from __future__ import annotations

import string
from dataclasses import dataclass, replace
from typing import List, Mapping, Optional, Tuple

from .errors import UrlError
from .percent import unquote
from .query import Pair, build_query, parse_query

DEFAULT_PORTS = {"http": 80, "https": 443, "ws": 80, "wss": 443, "ftp": 21}

_SCHEME_FIRST = frozenset(string.ascii_letters)
_SCHEME_REST = frozenset(string.ascii_letters + string.digits + "+-.")


@dataclass(frozen=True)
class Url:
    """The parts of an absolute URL exactly as written - nothing is decoded.

    ``port`` is ``None`` when the URL does not name one.  ``path``, ``query``
    and ``fragment`` are empty strings when absent; ``query`` and
    ``fragment`` do not include their leading ``?`` / ``#``.
    """

    scheme: str
    host: str
    port: Optional[int] = None
    path: str = ""
    query: str = ""
    fragment: str = ""

    def geturl(self) -> str:
        """Put the parts back together."""
        url = f"{self.scheme}://{self.host}"
        if self.port is not None:
            url += f":{self.port}"
        url += self.path
        if self.query:
            url += "?" + self.query
        if self.fragment:
            url += "#" + self.fragment
        return url

    def params(self) -> List[Pair]:
        """The decoded query parameters, as ``parse_query`` returns them."""
        return parse_query(self.query)

    def decoded_path(self) -> str:
        """The path with percent-escapes decoded; ``+`` in a path is a plus."""
        return unquote(self.path)


def _split_authority(authority: str) -> Tuple[str, Optional[int]]:
    if not authority:
        raise UrlError("URL has no host")
    if "@" in authority:
        raise UrlError("user information in URLs is not supported")
    if authority.startswith("["):
        # Bracketed IPv6 literal: the brackets stay part of the host.
        close = authority.find("]")
        if close < 0:
            raise UrlError(f"unterminated IPv6 literal: {authority!r}")
        host, tail = authority[:close + 1], authority[close + 1:]
        if tail and not tail.startswith(":"):
            raise UrlError(f"unexpected text after IPv6 literal: {authority!r}")
        port_text = tail[1:] if tail else None
    else:
        host, colon, rest = authority.partition(":")
        port_text = rest if colon else None
    if not host:
        raise UrlError("URL has no host")
    if port_text is None:
        return host, None
    if not port_text.isascii() or not port_text.isdigit():
        raise UrlError(f"port is not a number: {port_text!r}")
    port = int(port_text)
    if not 1 <= port <= 65535:
        raise UrlError(f"port out of range: {port}")
    return host, port


def split_url(url: str) -> Url:
    """Split an absolute ``scheme://host[:port][/path][?query][#fragment]`` URL.

    The fragment starts at the first ``#``; everything after it, including
    any ``?``, belongs to the fragment.  The query starts at the first ``?``
    before the fragment.  Raises ``UrlError`` when the scheme or host is
    missing or malformed, when the URL carries user information, or when the
    port is not a number between 1 and 65535.
    """
    scheme, separator, rest = url.partition("://")
    if (
        not separator
        or not scheme
        or scheme[0] not in _SCHEME_FIRST
        or any(char not in _SCHEME_REST for char in scheme)
    ):
        raise UrlError(f"not an absolute URL: {url!r}")
    rest, _, fragment = rest.partition("#")
    rest, _, query = rest.partition("?")
    slash = rest.find("/")
    if slash < 0:
        authority, path = rest, ""
    else:
        authority, path = rest[:slash], rest[slash:]
    host, port = _split_authority(authority)
    return Url(scheme, host, port, path, query, fragment)


def normalize(url: str) -> str:
    """Return ``url`` in canonical form.

    Scheme and host are lower-cased, a port equal to the scheme's default is
    dropped, and an empty path becomes ``/``.  Path, query and fragment are
    otherwise left exactly as written.
    """
    parts = split_url(url)
    scheme = parts.scheme.lower()
    port = parts.port
    if port is not None and DEFAULT_PORTS.get(scheme) == port:
        port = None
    return replace(
        parts,
        scheme=scheme,
        host=parts.host.lower(),
        port=port,
        path=parts.path or "/",
    ).geturl()


def update_query(url: str, changes: Mapping[str, Optional[str]]) -> str:
    """Return ``url`` with its query parameters changed.

    ``changes`` maps a parameter name to its new value:

    * a string - including the empty string - sets the parameter.  If the
      name already appears in the URL, its first appearance takes the new
      value in place and later appearances are dropped; otherwise the
      parameter is appended after the existing ones, in mapping order.
    * ``None`` removes every appearance of the parameter.  Removing a
      parameter that is not present is not an error.

    Parameters not named in ``changes`` keep their values and their order.
    The query is rewritten with ``build_query``; when no parameter is left
    the result has no ``?``.  Everything else in the URL is unchanged.
    """
    parts = split_url(url)
    kept: List[Pair] = []
    placed = set()
    for key, value in parse_query(parts.query):
        if key not in changes:
            kept.append((key, value))
            continue
        new_value = changes[key]
        if not new_value or key in placed:
            continue
        placed.add(key)
        kept.append((key, new_value))
    for key, new_value in changes.items():
        if new_value and key not in placed:
            kept.append((key, new_value))
    return replace(parts, query=build_query(kept)).geturl()
