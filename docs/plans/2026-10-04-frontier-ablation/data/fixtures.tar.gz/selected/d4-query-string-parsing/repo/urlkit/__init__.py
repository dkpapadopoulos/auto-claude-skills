"""urlkit - strict URL and query-string handling.

See README.md at the repository root for the documented behaviour.
"""

from .errors import UrlError
from .percent import quote, unquote
from .query import build_query, first_value, group_params, parse_query
from .url import Url, normalize, split_url, update_query

__all__ = [
    "Url",
    "UrlError",
    "build_query",
    "first_value",
    "group_params",
    "normalize",
    "parse_query",
    "quote",
    "split_url",
    "unquote",
    "update_query",
]

__version__ = "1.0.0rc1"
