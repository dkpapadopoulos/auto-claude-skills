# urlkit

Strict, dependency-free URL and query-string handling for the gateway
services. We do not use `urllib.parse` here because the gateway needs two
things it does not give us: malformed input must be *rejected* rather than
passed through, and query parameters must keep their exact order and
repetitions.

```python
from urlkit import parse_query, split_url, update_query

split_url("https://example.com/search?q=red+shoes&page=2").params()
# [("q", "red shoes"), ("page", "2")]

update_query("https://example.com/search?q=red+shoes&page=2", {"page": "3"})
# "https://example.com/search?q=red%20shoes&page=3"
```

## Errors

Malformed input is always reported as `urlkit.UrlError` (a subclass of
`ValueError`). It is the only exception type callers have to catch for bad
URL text, bad query strings or bad percent-escapes.

## Percent-encoding (`urlkit.percent`)

`quote(text, safe="")`

* Unreserved characters - `A-Z a-z 0-9 - . _ ~` - and any character listed in
  `safe` are copied unchanged.
* Every other character is encoded as UTF-8, each byte written as `%XX` with
  upper-case hex digits.
* A space is written `%20`, never `+`. A plus sign is written `%2B`.

`unquote(text, plus_as_space=False)`

* `%XX` (hex digits in either case) stands for one byte. The decoded bytes are
  read as UTF-8, so `%C3%A9` is `é`. Other characters are copied.
* `plus_as_space=True` is the mode used for query strings: a literal `+` in
  the input stands for a space.
* An escaped plus, `%2B`, is a literal `+` **in both modes**. So
  `unquote("a+b%2Bc", plus_as_space=True)` is `"a b+c"`, and
  `unquote("a+b%2Bc")` is `"a+b+c"`.
* `UrlError` is raised when a `%` is not followed by exactly two hexadecimal
  digits (`"%zz"`, `"%4"`, a `%` at the very end), and when the decoded bytes
  are not valid UTF-8 (`"%ff"`).

`unquote(quote(s)) == s` for every string `s`.

## Query strings (`urlkit.query`)

`parse_query(query)` takes the text after the `?` and returns a list of
decoded `(key, value)` tuples.

* Parameters are separated by `&`. Empty segments (`a=1&&b=2`, a trailing `&`)
  are ignored.
* The **first** `=` in a segment separates key from value; any further `=`
  is part of the value. `token=YWJj==` is `("token", "YWJj==")`.
* A segment without `=` is a key with the empty string as its value.
* Keys and values are decoded with `unquote(..., plus_as_space=True)`.
* Order is preserved and repeated keys are all kept.
* A malformed percent-escape raises `UrlError`.

`build_query(pairs)` is the inverse: keys and values are escaped with `quote`
(no extra safe characters) and written as `key=value` joined by `&`. Every
pair is written with its `=`, also when the value is empty (`("a", "")` is
`a=`). Order and repeats are kept, so
`parse_query(build_query(pairs)) == list(pairs)` for any strings.

`group_params(pairs)` gives a `{key: [values...]}` dict with keys in first-seen
order; `first_value(pairs, key, default=None)` gives the first value of a key.

## URLs (`urlkit.url`)

`split_url(url)` splits an absolute
`scheme://host[:port][/path][?query][#fragment]` URL into a `Url` with the
fields `scheme`, `host`, `port`, `path`, `query`, `fragment`.

* Parts are stored exactly as written - nothing is decoded or case-folded.
* `port` is an `int`, or `None` when the URL names no port. `path`, `query`
  and `fragment` are `""` when absent.
* The fragment starts at the first `#`; everything after it, including any
  `?`, belongs to the fragment.
* `UrlError` is raised when the scheme or host is missing, when the URL
  contains user information (`user@host`), or when the port is not a number
  from 1 to 65535.

`Url.geturl()` puts the parts back together, `Url.params()` is
`parse_query(url.query)`, and `Url.decoded_path()` is the path with escapes
decoded (a `+` in a path is a plus sign, not a space).

`normalize(url)` lower-cases scheme and host, drops a port equal to the
scheme's default (`http`/`ws` 80, `https`/`wss` 443, `ftp` 21) and turns an
empty path into `/`. Path, query and fragment are otherwise untouched.

`update_query(url, changes)` returns the URL with its query parameters
changed. `changes` maps a parameter name to its new value:

* **a string sets the parameter - any string, including the empty string
  `""`**, which gives a parameter with an empty value (`name=`). If the name
  already appears in the URL, its first appearance takes the new value in
  place and any later appearances are dropped. If it does not appear, the
  parameter is appended after the existing ones, in the mapping's order.
* **`None` removes** every appearance of the parameter. Removing a parameter
  that is not present is not an error.

Parameters not named in `changes` keep their values and their relative order.
The query is rewritten with `build_query`; when no parameter is left, the
result has no `?`. Scheme, host, port, path and fragment are unchanged.

## Running the tests

    python3 -m unittest discover -s tests
