import unittest

from urlkit.query import build_query, first_value, group_params, parse_query


class ParseQueryTests(unittest.TestCase):
    def test_simple_pairs_in_order(self):
        self.assertEqual(parse_query("b=2&a=1"), [("b", "2"), ("a", "1")])

    def test_repeated_keys_are_kept(self):
        self.assertEqual(
            parse_query("tag=x&tag=y&page=1"),
            [("tag", "x"), ("tag", "y"), ("page", "1")],
        )

    def test_empty_segments_are_ignored(self):
        self.assertEqual(parse_query("a=1&&b=2&"), [("a", "1"), ("b", "2")])
        self.assertEqual(parse_query(""), [])

    def test_segment_without_equals_has_empty_value(self):
        self.assertEqual(parse_query("debug&a=1"), [("debug", ""), ("a", "1")])

    def test_values_are_decoded(self):
        self.assertEqual(
            parse_query("q=red+shoes&city=K%C3%B6ln"),
            [("q", "red shoes"), ("city", "Köln")],
        )


class BuildQueryTests(unittest.TestCase):
    def test_pairs_are_escaped_and_joined(self):
        self.assertEqual(
            build_query([("q", "red shoes"), ("tag", "a&b"), ("tag", "c")]),
            "q=red%20shoes&tag=a%26b&tag=c",
        )

    def test_empty_value_keeps_its_equals_sign(self):
        self.assertEqual(build_query([("a", ""), ("b", "1")]), "a=&b=1")


class HelperTests(unittest.TestCase):
    def test_group_params(self):
        grouped = group_params([("tag", "x"), ("page", "1"), ("tag", "y")])
        self.assertEqual(grouped, {"tag": ["x", "y"], "page": ["1"]})
        self.assertEqual(list(grouped), ["tag", "page"])

    def test_first_value(self):
        pairs = [("tag", "x"), ("tag", "y")]
        self.assertEqual(first_value(pairs, "tag"), "x")
        self.assertIsNone(first_value(pairs, "page"))
        self.assertEqual(first_value(pairs, "page", "1"), "1")


if __name__ == "__main__":
    unittest.main()
