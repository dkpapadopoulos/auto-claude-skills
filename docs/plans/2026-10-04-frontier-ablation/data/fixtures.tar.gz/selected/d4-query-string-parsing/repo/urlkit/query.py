"""Query strings as ordered lists of ``(key, value)`` pairs."""

from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Tuple

from .percent import quote, unquote

Pair = Tuple[str, str]


def parse_query(query: str) -> List[Pair]:
    """Split a raw query string into decoded ``(key, value)`` pairs.

    ``query`` is the text after the ``?`` (what ``Url.query`` holds).

    * Parameters are separated by ``&``; empty segments (``a=1&&b=2``, a
      trailing ``&``) are ignored.
    * The first ``=`` in a segment separates key from value.  Any further
      ``=`` is part of the value.
    * A segment without ``=`` is a key whose value is the empty string.
    * Keys and values are decoded with ``unquote(..., plus_as_space=True)``.
    * Order is preserved and repeated keys are all kept.

    Raises ``UrlError`` for a malformed percent-escape.
    """
    pairs: List[Pair] = []
    for segment in query.split("&"):
        if not segment:
            continue
        fields = segment.split("=")
        key = fields[0]
        value = fields[1] if len(fields) > 1 else ""
        pairs.append((
            unquote(key, plus_as_space=True),
            unquote(value, plus_as_space=True),
        ))
    return pairs


def build_query(pairs: Iterable[Pair]) -> str:
    """Serialise ``(key, value)`` pairs into a query string (no leading ``?``).

    Keys and values are escaped with ``quote`` (no extra safe characters) and
    written as ``key=value`` joined by ``&``.  Every pair is written with its
    ``=``, also when the value is empty.  Order and repeated keys are kept,
    so ``parse_query(build_query(pairs)) == list(pairs)`` for any strings.
    """
    return "&".join(f"{quote(key)}={quote(value)}" for key, value in pairs)


def group_params(pairs: Iterable[Pair]) -> Dict[str, List[str]]:
    """Collect the values of each key, keys in first-seen order."""
    grouped: Dict[str, List[str]] = {}
    for key, value in pairs:
        grouped.setdefault(key, []).append(value)
    return grouped


def first_value(pairs: Iterable[Pair], key: str, default: Optional[str] = None) -> Optional[str]:
    """The value of the first pair named ``key``, or ``default`` if absent."""
    for name, value in pairs:
        if name == key:
            return value
    return default
