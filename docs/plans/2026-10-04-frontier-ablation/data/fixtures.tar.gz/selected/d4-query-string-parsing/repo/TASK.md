# Pre-release review of `urlkit`

`urlkit` 1.0 is scheduled to be released on Thursday, and the gateway will
switch its redirect and signing code over to it right after. Once that
happens every behaviour is something a caller depends on, so I would like it
reviewed properly before the tag.

Please go through the package, compare it with its documented behaviour, and
fix every defect you find.

* The documentation is the specification: `README.md` and the docstrings in
  `urlkit/`. Where the code and the documentation disagree, the code is what
  needs to change.
* Keep the public API stable - same modules, names, signatures and return
  types as today.
* Standard library only. Please keep the parsing in our own code rather than
  delegating to `urllib.parse`; the README explains why we do not use it.

The current tests pass:

    python3 -m unittest discover -s tests

They mostly exercise the everyday cases, though, so please do not take a
green run as a sign that there is nothing to find. I have deliberately not
listed suspicions here - I want an independent read of the whole package.
Add tests for anything you fix.
