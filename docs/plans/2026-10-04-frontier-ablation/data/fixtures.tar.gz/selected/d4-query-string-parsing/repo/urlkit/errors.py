"""The one exception type urlkit raises for bad input."""


class UrlError(ValueError):
    """Raised for text that is not a well-formed URL, query string or escape.

    Callers are told (README, "Errors") that this is the only exception they
    need to catch for malformed input.
    """
