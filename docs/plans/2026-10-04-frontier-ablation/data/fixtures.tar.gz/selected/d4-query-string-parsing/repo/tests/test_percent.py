import unittest

from urlkit.percent import quote, unquote


class QuoteTests(unittest.TestCase):
    def test_unreserved_characters_are_copied(self):
        self.assertEqual(quote("Az09-._~"), "Az09-._~")

    def test_space_and_reserved_characters_are_escaped(self):
        self.assertEqual(quote("a b&c=d"), "a%20b%26c%3Dd")

    def test_non_ascii_is_escaped_as_utf8(self):
        self.assertEqual(quote("café"), "caf%C3%A9")

    def test_safe_characters_are_copied(self):
        self.assertEqual(quote("/a b/c", safe="/"), "/a%20b/c")


class UnquoteTests(unittest.TestCase):
    def test_escapes_are_decoded_as_utf8(self):
        self.assertEqual(unquote("caf%C3%A9%20au%20lait"), "café au lait")

    def test_hex_digits_may_be_lower_case(self):
        self.assertEqual(unquote("%c3%a9"), "é")

    def test_plus_is_literal_by_default(self):
        self.assertEqual(unquote("a+b"), "a+b")

    def test_plus_is_a_space_in_query_mode(self):
        self.assertEqual(unquote("a+b", plus_as_space=True), "a b")


if __name__ == "__main__":
    unittest.main()
