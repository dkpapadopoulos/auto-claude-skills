# d4-query-string-parsing

Category d (release hardening). Domain: URL / query-string parsing. The
package implements its own percent-decoding, query splitting and URL
splitting; it does not wrap `urllib.parse`, and TASK.md asks that it stay
that way.

TASK.md asks for a review against the documented behaviour and names
`README.md` plus the docstrings as the specification; every row below quotes
the documentation inside `repo/` that requires the assertion.

## Planted defects

| # | Kind | Where | Defect | Documented behaviour it violates |
|---|---|---|---|---|
| 1 | wrong order of operations | `urlkit/percent.py::unquote` | `+` is turned into a space *after* percent-decoding, so `%2B` also becomes a space | README: "An escaped plus, `%2B`, is a literal `+` **in both modes**" |
| 2 | unhandled documented error case | `urlkit/percent.py::unquote` | escapes are not validated: `%zz` / trailing `%` / invalid UTF-8 leak a bare `ValueError` / `UnicodeDecodeError`, and a one-digit escape (`%4`) is silently decoded | README: "`UrlError` is raised when a `%` is not followed by exactly two hexadecimal digits (`"%zz"`, `"%4"`, a `%` at the very end), and when the decoded bytes are not valid UTF-8 (`"%ff"`)" |
| 3 | truncation (wrong split) | `urlkit/query.py::parse_query` | `segment.split("=")` keeps only the text between the first and second `=` | README: "The **first** `=` in a segment separates key from value; any further `=` is part of the value" |
| 4 | wrong comparison (truthiness instead of `is None`) | `urlkit/url.py::update_query` | `""` is treated like `None`, so setting an empty value removes or never adds the parameter | README: "a string sets the parameter - any string, including the empty string `""`" / "`None` removes" |

## Hidden tests -> requirement

| Hidden test | Defect | Documentation sentence that requires it |
|---|---|---|
| `test_documented_decoding.EscapedPlusTests.test_escaped_plus_is_a_plus_in_both_modes` | 1 | README: "`unquote("a+b%2Bc", plus_as_space=True)` is `"a b+c"`, and `unquote("a+b%2Bc")` is `"a+b+c"`"; "`%XX` (hex digits in either case)" |
| `...EscapedPlusTests.test_query_value_with_escaped_plus` | 1 | README `parse_query`: "Keys and values are decoded with `unquote(..., plus_as_space=True)`" + the `%2B` rule |
| `...EscapedPlusTests.test_build_then_parse_returns_the_same_pairs` | 1 | README: "`parse_query(build_query(pairs)) == list(pairs)` for any strings" |
| `...MalformedEscapeTests.test_non_hex_escape_raises_url_error` | 2 | README: "`UrlError` is raised when a `%` is not followed by exactly two hexadecimal digits (`"%zz"`, ...)"; `parse_query`: "A malformed percent-escape raises `UrlError`" |
| `...MalformedEscapeTests.test_percent_at_the_very_end_raises_url_error` | 2 | Same sentence: "a `%` at the very end" |
| `...MalformedEscapeTests.test_escape_with_a_single_hex_digit_raises_url_error` | 2 | Same sentence: "exactly two hexadecimal digits (..., `"%4"`, ...)" |
| `...MalformedEscapeTests.test_invalid_utf8_raises_url_error` | 2 | README: "and when the decoded bytes are not valid UTF-8 (`"%ff"`)" |
| `...MalformedEscapeTests.test_quote_then_unquote_returns_the_original` | guard | README: "`unquote(quote(s)) == s` for every string `s`" (already true; guards against a fix that breaks literal `%` / `+` handling) |
| `...FirstEqualsSignTests.test_later_equals_signs_belong_to_the_value` | 3 | README: "`token=YWJj==` is `("token", "YWJj==")`"; "A segment without `=` is a key with the empty string as its value" |
| `test_documented_update_query.EmptyStringSetsTests.test_empty_string_sets_an_existing_parameter_to_empty` | 4 | README: "a string sets the parameter - any string, including the empty string `""`, which gives a parameter with an empty value (`name=`) ... its first appearance takes the new value in place"; `build_query`: "Every pair is written with its `=`, also when the value is empty" |
| `...EmptyStringSetsTests.test_empty_string_adds_a_new_parameter_with_empty_value` | 4 | README: "If it does not appear, the parameter is appended after the existing ones"; "Scheme, host, port, path and fragment are unchanged" |
| `...EmptyStringSetsTests.test_none_still_removes_while_empty_string_sets` | 4 | README: "its first appearance takes the new value in place and any later appearances are dropped"; "`None` removes every appearance of the parameter" |
| `...UntouchedParametersTests.test_untouched_value_with_equals_signs_keeps_its_value` | 3 | README: "Parameters not named in `changes` keep their values and their relative order" + the first-`=` rule |
| `...UntouchedParametersTests.test_plus_signs_in_a_new_value_survive` | 1 | README: `update_query` "is rewritten with `build_query`"; `quote`: "A plus sign is written `%2B`"; `Url.params()` "is `parse_query(url.query)`" + the `%2B` rule |

## Trap

`wrong_fix/` is the review that fixes what a first read shows: it wraps the
`int(..., 16)` call and the UTF-8 decode in `try/except` -> `UrlError`
(defect 2, mostly) and switches `parse_query` to `partition("=")` (defect 3).
Visible tests stay green, but the `try/except` does not catch a one-digit
escape (`int("4", 16)` succeeds), `%2B` still decodes to a space (1) and
`update_query` still treats `""` as "remove" (4), so 8 of 14 hidden tests
fail.
