"""Integer-minute interval primitives for room availability.

Ranges are half-open: a booking ending at 60 does not occupy minute 60.
The empty range is valid and carries no occupancy.
"""
from dataclasses import dataclass


@dataclass(frozen=True, order=True)
class Range:
    start: int
    end: int

    def __post_init__(self):
        if type(self.start) is not int or type(self.end) is not int:
            raise TypeError("range endpoints must be integers")
        if self.end < self.start:
            raise ValueError("range end precedes start")

    @property
    def duration(self):
        return self.end - self.start

    def contains(self, minute):
        return self.start <= minute < self.end

    def overlaps(self, other):
        return max(self.start, other.start) < min(self.end, other.end)

    def intersection(self, other):
        start = max(self.start, other.start)
        end = min(self.end, other.end)
        return Range(start, end) if start < end else None

    def shifted(self, minutes):
        return Range(self.start + minutes, self.end + minutes)


def materialize(ranges):
    """Consume an iterable once and require Range objects."""
    result = list(ranges)
    if any(not isinstance(item, Range) for item in result):
        raise TypeError("expected Range values")
    return result


def coalesce(ranges):
    """Return a sorted union, removing empty and joining touching ranges."""
    ordered = sorted(item for item in materialize(ranges) if item.duration)
    merged = []
    for item in ordered:
        if merged and item.start <= merged[-1].end:
            previous = merged[-1]
            merged[-1] = Range(previous.start, max(previous.end, item.end))
        else:
            merged.append(item)
    return tuple(merged)


def total_duration(ranges):
    """Count covered minutes only once even if input ranges overlap."""
    return sum(item.duration for item in coalesce(ranges))


def clip(ranges, bounds):
    """Return the union restricted to a single bounding range."""
    result = []
    for item in coalesce(ranges):
        overlap = item.intersection(bounds)
        if overlap is not None:
            result.append(overlap)
    return tuple(result)


def covering_range(ranges):
    """Return outer bounds or None when there are no occupied minutes."""
    items = coalesce(ranges)
    if not items:
        return None
    return Range(items[0].start, items[-1].end)


def contains_all(container, candidates):
    """Check containment in a union without expanding minute by minute."""
    available = coalesce(container)
    for candidate in coalesce(candidates):
        if not any(item.start <= candidate.start and candidate.end <= item.end
                   for item in available):
            return False
    return True
