# Find bookable room time

The scheduling screen needs the gaps within a set of opening windows.

Implement `free_slots(windows, blocked, min_duration=1)` in `booking.calendar`, returning a tuple of `Range` objects for the available time.

Treat both inputs as unions of half-open ranges, joining overlaps and touching ranges and ignoring zero-length ranges; return maximal nonempty available spans sorted by start.

Subtract every blocked minute, including blocks partly or wholly outside the windows, without creating availability outside a window; touching endpoints alone do not block time.

After subtraction, retain spans whose duration is at least `min_duration`, including equality, without splitting longer spans.

Require `min_duration` to be an integer greater than zero (booleans are not integers here); otherwise raise `ValueError("min_duration must be a positive integer")`.

Accept one-shot iterables, do not mutate input collections, return an empty tuple if no availability remains, and validate the values in both iterables even when one is empty using the existing `TypeError("expected Range values")` contract.
