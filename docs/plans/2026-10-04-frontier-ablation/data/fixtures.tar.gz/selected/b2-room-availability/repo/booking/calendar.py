"""Room-booking reports built on the common interval primitives."""
from .ranges import Range, materialize, coalesce, clip, total_duration


class Calendar:
    """A detached collection of named reservations for one room."""

    def __init__(self):
        self._reservations = {}

    def add(self, reference, ranges):
        """Replace a reference atomically after validating all its ranges."""
        candidate = coalesce(ranges)
        self._reservations[reference] = candidate

    def cancel(self, reference):
        return self._reservations.pop(reference, None) is not None

    def references(self):
        return tuple(sorted(self._reservations))

    def occupied(self):
        spans = []
        for reservation in self._reservations.values():
            spans.extend(reservation)
        return coalesce(spans)

    def occupancy(self, bounds):
        return total_duration(clip(self.occupied(), bounds))

    def conflicts(self, candidate):
        """List references with a positive-duration intersection."""
        result = []
        for reference, spans in self._reservations.items():
            if any(candidate.overlaps(span) for span in spans):
                result.append(reference)
        return tuple(sorted(result))


def utilization(windows, reservations):
    """Return occupied / available minutes, or zero for empty windows."""
    windows = coalesce(windows)
    reservations = coalesce(reservations)
    available = total_duration(windows)
    if available == 0:
        return 0.0
    used = sum(total_duration(clip(reservations, window)) for window in windows)
    return used / available


def describe(ranges):
    """Return human-readable minute labels in chronological order."""
    return [f"{item.start}..{item.end} ({item.duration} min)"
            for item in coalesce(ranges)]


def free_slots(windows, blocked, min_duration=1):
    """Find maximal available spans after subtracting blocked time."""
    raise NotImplementedError("availability subtraction is not implemented")
