from booking.ranges import Range
from booking.calendar import free_slots
import unittest

class Examples(unittest.TestCase):
    def test_lunch(self):
        self.assertEqual(free_slots([Range(0, 100)], [Range(30, 40)]),
                         (Range(0, 30), Range(40, 100)))
