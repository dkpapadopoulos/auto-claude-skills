from booking.ranges import Range
from booking.calendar import free_slots
import unittest

class Contract(unittest.TestCase):
    def test_windows_form_union(self):
        self.assertEqual(free_slots([Range(5, 15), Range(0, 10), Range(15, 20)], []), (Range(0, 20),))

    def test_overlapping_blockers(self):
        self.assertEqual(free_slots([Range(0, 30)], [Range(10, 20), Range(5, 15), Range(20, 25)]), (Range(0, 5), Range(25, 30)))

    def test_external_and_touching(self):
        self.assertEqual(free_slots([Range(0, 10), Range(20, 30)], [Range(-5, 0), Range(7, 23), Range(30, 40)]), (Range(0, 7), Range(23, 30)))

    def test_empty_ranges(self):
        self.assertEqual(free_slots([Range(0, 0), Range(0, 10)], [Range(4, 4)]), (Range(0, 10),))

    def test_minimum_inclusive(self):
        self.assertEqual(free_slots([Range(0, 20)], [Range(4, 10), Range(15, 17)], 4), (Range(0, 4), Range(10, 15)))

    def test_invalid_minimum(self):
        for value in [0, -1, True, 1.0, "1"]:
            with self.subTest(value=value):
                with self.assertRaisesRegex(ValueError, "^min_duration must be a positive integer$"):
                    free_slots([], [], value)

    def test_iterables_and_no_mutation(self):
        windows = [Range(20, 30), Range(0, 10)]
        blocked = [Range(2, 4)]
        self.assertEqual(free_slots(iter(windows), iter(blocked)), (Range(0, 2), Range(4, 10), Range(20, 30)))
        self.assertEqual(windows, [Range(20, 30), Range(0, 10)])
        self.assertEqual(blocked, [Range(2, 4)])
        self.assertEqual(free_slots([Range(0, 10)], [Range(-1, 11)]), ())

    def test_validate_empty_side(self):
        for windows, blocked in [([], ["bad"]), (["bad"], [])]:
            with self.assertRaisesRegex(TypeError, "^expected Range values$"):
                free_slots(windows, blocked)
