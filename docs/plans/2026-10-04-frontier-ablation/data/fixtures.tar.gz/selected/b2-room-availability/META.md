# Contract coverage

| Hidden test | Required sentence |
| --- | --- |
| `test_windows_form_union` | Treat both inputs as unions of half-open ranges, joining overlaps and touching ranges and ignoring zero-length ranges; return maximal nonempty available spans sorted by start. |
| `test_overlapping_blockers` | Treat both inputs as unions of half-open ranges, joining overlaps and touching ranges and ignoring zero-length ranges; return maximal nonempty available spans sorted by start. |
| `test_external_and_touching` | Subtract every blocked minute, including blocks partly or wholly outside the windows, without creating availability outside a window; touching endpoints alone do not block time. |
| `test_empty_ranges` | Treat both inputs as unions of half-open ranges, joining overlaps and touching ranges and ignoring zero-length ranges; return maximal nonempty available spans sorted by start. |
| `test_minimum_inclusive` | After subtraction, retain spans whose duration is at least `min_duration`, including equality, without splitting longer spans. |
| `test_invalid_minimum` | Require `min_duration` to be an integer greater than zero (booleans are not integers here); otherwise raise `ValueError("min_duration must be a positive integer")`. |
| `test_iterables_and_no_mutation` | Accept one-shot iterables, do not mutate input collections, return an empty tuple if no availability remains, and validate the values in both iterables even when one is empty using the existing `TypeError("expected Range values")` contract. |
| `test_validate_empty_side` | Accept one-shot iterables, do not mutate input collections, return an empty tuple if no availability remains, and validate the values in both iterables even when one is empty using the existing `TypeError("expected Range values")` contract. |

Trap: Subtracting from individual opening windows misses their required union.
