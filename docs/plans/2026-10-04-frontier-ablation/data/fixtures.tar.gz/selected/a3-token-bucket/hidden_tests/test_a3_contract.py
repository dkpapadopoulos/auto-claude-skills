import unittest
from limiter import TokenBucket, KeyedLimiter

class ContractTests(unittest.TestCase):
    def test_fractional(self):
        b=TokenBucket(2,1)
        b.consume(0,2)
        self.assertAlmostEqual(b.available(0.25),0.25)

    def test_partition(self):
        a,b=TokenBucket(3,2),TokenBucket(3,2)
        a.consume(0,3)
        b.consume(0,3)
        for now in [0.125,0.25,0.375]: b.available(now)
        self.assertAlmostEqual(a.available(0.5),b.available(0.5))
        self.assertAlmostEqual(b.available(0.5),1)

    def test_saturation(self):
        b=TokenBucket(1,1)
        self.assertEqual(b.available(10.75),1)
        self.assertTrue(b.consume(10.75))
        self.assertFalse(b.consume(11.0))
        self.assertAlmostEqual(b.available(11.0),0.25)

    def test_watermark(self):
        b=TokenBucket(1,1)
        b.available(0.75)
        with self.assertRaises(ValueError): b.available(0.5)
        self.assertEqual(b.available(0.75),1)

    def test_denial_delay(self):
        b=TokenBucket(2,2)
        b.consume(0,2)
        d=b.request(0.25,1.5)
        self.assertFalse(d.allowed)
        self.assertAlmostEqual(d.remaining,0.5)
        self.assertAlmostEqual(d.retry_after,0.5)
        self.assertAlmostEqual(b.available(0.25),0.5)

    def test_costs(self):
        b=TokenBucket(2,1)
        d=b.request(0,0.5)
        self.assertTrue(d.allowed)
        self.assertEqual(d.remaining,1.5)
        self.assertEqual(d.retry_after,0)
        self.assertTrue(b.request(0,0).allowed)
        for cost in [-1,3,float("nan")]:
            with self.assertRaises(ValueError): b.request(10,cost)
        self.assertEqual(b.available(0),1.5)

    def test_invalid_time(self):
        b=TokenBucket(2,1)
        b.consume(0)
        for now in [-1,float("nan"),float("inf")]:
            with self.assertRaises(ValueError): b.available(now)
        self.assertEqual(b.available(0),1)

    def test_keys(self):
        k=KeyedLimiter(1,1)
        self.assertTrue(k.request("a",0).allowed)
        self.assertFalse(k.request("a",0).allowed)
        self.assertTrue(k.request("b",0).allowed)
        self.assertAlmostEqual(k.request("a",0.5).remaining,0.5)

    def test_snapshot(self):
        b=TokenBucket(1,1)
        self.assertIs(b.consume(0),True)
        s=b.snapshot(0.5)
        self.assertAlmostEqual(s["tokens"],0.5)
        self.assertEqual(s["at"],0.5)

if __name__ == "__main__":
    unittest.main()
