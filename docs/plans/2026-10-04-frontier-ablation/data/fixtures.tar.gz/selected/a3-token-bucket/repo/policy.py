"""Validated configuration and result objects for deterministic rate limits.

The caller supplies monotonic timestamps. No wall clock is consulted by
this package, which also makes replaying a stream of requests possible.
"""
from dataclasses import dataclass
import math


def finite_number(value, name):
    """Accept a finite real-valued number, excluding booleans."""
    if isinstance(value, bool):
        raise ValueError(f"{name} must be finite")
    try:
        number = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be finite") from exc
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    return number


@dataclass(frozen=True)
class Policy:
    """Positive token capacity and positive tokens-per-second refill rate."""
    capacity: float
    rate: float

    def __post_init__(self):
        capacity = finite_number(self.capacity, "capacity")
        rate = finite_number(self.rate, "rate")
        if capacity <= 0 or rate <= 0:
            raise ValueError("capacity and rate must be positive")
        object.__setattr__(self, "capacity", capacity)
        object.__setattr__(self, "rate", rate)

    def cost(self, value):
        """Validate a cost in the inclusive interval [0, capacity]."""
        value = finite_number(value, "cost")
        if not 0 <= value <= self.capacity:
            raise ValueError("cost outside capacity")
        return value

    def seconds_for(self, tokens):
        """Convert a nonnegative token deficit into a duration."""
        tokens = finite_number(tokens, "tokens")
        if tokens < 0:
            raise ValueError("negative token deficit")
        return tokens / self.rate


@dataclass(frozen=True)
class Decision:
    """Snapshot after a request, with retry delay measured in seconds."""
    allowed: bool
    remaining: float
    retry_after: float

    def as_dict(self):
        """Return a detached representation for logging or serialization."""
        return {
            "allowed": self.allowed,
            "remaining": self.remaining,
            "retry_after": self.retry_after,
        }


def timestamp(value):
    """Validate an explicit monotonic timestamp."""
    return finite_number(value, "timestamp")
