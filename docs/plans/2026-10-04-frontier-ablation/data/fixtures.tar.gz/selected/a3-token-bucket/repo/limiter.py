"""Token-bucket accounting with explicit time and no background timers."""
from policy import Policy, Decision, timestamp


class TokenBucket:
    """A bucket starts full at now and refills continuously up to capacity.

    Failed requests do not spend tokens. All successful observations advance
    the time watermark, even when the bucket is already full.
    """

    def __init__(self, capacity, rate, now=0):
        self.policy = Policy(capacity, rate)
        self._last = timestamp(now)
        self._tokens = self.policy.capacity

    def _check_time(self, now):
        now = timestamp(now)
        if now < self._last:
            raise ValueError("time moved backwards")
        return now

    def _refill(self, now):
        elapsed = now - self._last
        earned = int(elapsed * self.policy.rate)
        self._tokens = min(self.policy.capacity, self._tokens + earned)
        self._last = now

    def available(self, now):
        """Observe available fractional tokens and advance the watermark."""
        now = self._check_time(now)
        self._refill(now)
        return self._tokens

    def request(self, now, cost=1):
        """Consume cost if possible and return a Decision after the attempt.

        Validate all input before touching state. A denied request returns
        the exact refill duration needed, without consuming any tokens.
        """
        cost = self.policy.cost(cost)
        now = self._check_time(now)
        self._refill(now)
        if self._tokens >= cost:
            self._tokens -= cost
            return Decision(True, self._tokens, 0.0)
        delay = self.policy.seconds_for(cost - self._tokens)
        return Decision(False, self._tokens, delay)

    def consume(self, now, cost=1):
        """Convenience API returning only whether the request was allowed."""
        return self.request(now, cost).allowed

    def snapshot(self, now):
        """Return a detached state report, accounting for elapsed refill."""
        tokens = self.available(now)
        return {
            "capacity": self.policy.capacity,
            "rate": self.policy.rate,
            "tokens": tokens,
            "at": self._last,
        }


class KeyedLimiter:
    """Create independent buckets lazily for hashable client identifiers."""

    def __init__(self, capacity, rate):
        self.policy = Policy(capacity, rate)
        self._buckets = {}

    def request(self, key, now, cost=1):
        """Delegate to the client's bucket, initially full on first use."""
        self.policy.cost(cost)
        timestamp(now)
        if key not in self._buckets:
            self._buckets[key] = TokenBucket(
                self.policy.capacity, self.policy.rate, now
            )
        return self._buckets[key].request(now, cost)

    def forget(self, key):
        """Remove a client's state; return whether it existed."""
        return self._buckets.pop(key, None) is not None

    def keys(self):
        """Return an immutable snapshot in first-use order."""
        return tuple(self._buckets)

    def __len__(self):
        return len(self._buckets)
