# Frequent polling prevents the token bucket from refilling
After draining a one-token bucket refilling at one token/second, requests at 0.25, 0.50, 0.75 and 1.00 seconds are all denied.
The final request should succeed. Fix refill accounting without changing the APIs.

`TokenBucket(capacity, rate, now=0)` starts full and earns `rate * elapsed` tokens continuously, including fractional tokens, capped at capacity.
`available(now)` returns the current fractional token balance; dividing an elapsed interval into observations must not change that balance.
Every successful observation or request advances the monotonic time watermark to now, even at full capacity; unused refill while full cannot be banked for later.
`request(now, cost=1)` consumes cost only when enough tokens exist, returning `Decision(allowed, remaining, retry_after)`; a denied request preserves the balance and reports `(cost - remaining) / rate` seconds until affordable, while an allowed request reports zero delay.
Costs may be fractional or zero, but must be finite and within [0, capacity]; invalid costs raise ValueError before any state change.
Timestamps must be finite and nondecreasing; invalid or backwards times raise ValueError without changing the bucket state.
`KeyedLimiter(capacity, rate).request(key, now, cost=1)` uses independent buckets, each initially full on first use.
`consume(now, cost=1)` returns the decision's boolean allowed value, and `snapshot(now)` reports the same balance as available with its timestamp in `at`.
