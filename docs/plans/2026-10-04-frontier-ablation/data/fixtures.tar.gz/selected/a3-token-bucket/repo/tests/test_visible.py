import unittest
from limiter import TokenBucket, KeyedLimiter

class ContractTests(unittest.TestCase):
    def test_reported_polling(self):
        b = TokenBucket(1,1)
        self.assertTrue(b.consume(0))
        for now in [0.25,0.5,0.75]:
            self.assertFalse(b.consume(now))
        self.assertTrue(b.consume(1))

    def test_capacity(self):
        b=TokenBucket(2,1)
        self.assertEqual(b.available(10), 2)

if __name__ == "__main__":
    unittest.main()
