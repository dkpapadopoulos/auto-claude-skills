# Traceability

Trap: Preserving whole-token timestamps banks idle time and loses fractional observations.

| Hidden test | Exact TASK.md sentence |
|---|---|
| test_fractional | `TokenBucket(capacity, rate, now=0)` starts full and earns `rate * elapsed` tokens continuously, including fractional tokens, capped at capacity. |
| test_partition | `available(now)` returns the current fractional token balance; dividing an elapsed interval into observations must not change that balance. |
| test_saturation | Every successful observation or request advances the monotonic time watermark to now, even at full capacity; unused refill while full cannot be banked for later. |
| test_watermark | Timestamps must be finite and nondecreasing; invalid or backwards times raise ValueError without changing the bucket state. |
| test_denial_delay | `request(now, cost=1)` consumes cost only when enough tokens exist, returning `Decision(allowed, remaining, retry_after)`; a denied request preserves the balance and reports `(cost - remaining) / rate` seconds until affordable, while an allowed request reports zero delay. |
| test_costs | Costs may be fractional or zero, but must be finite and within [0, capacity]; invalid costs raise ValueError before any state change. |
| test_invalid_time | Timestamps must be finite and nondecreasing; invalid or backwards times raise ValueError without changing the bucket state. |
| test_keys | `KeyedLimiter(capacity, rate).request(key, now, cost=1)` uses independent buckets, each initially full on first use. |
| test_snapshot | `consume(now, cost=1)` returns the decision's boolean allowed value, and `snapshot(now)` reports the same balance as available with its timestamp in `at`. |
