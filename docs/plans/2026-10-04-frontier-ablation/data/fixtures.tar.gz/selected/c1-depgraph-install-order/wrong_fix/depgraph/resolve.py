"""Ordering queries over a :class:`~depgraph.graph.DependencyGraph`."""

import heapq

from .errors import CycleError, UnknownPackageError
from .graph import canonical_name


def _selection(graph, targets):
    """Canonical names of ``targets`` and of everything they need.

    ``targets=None`` selects every declared package.
    """
    if targets is None:
        stack = list(graph.packages())
    else:
        stack = [canonical_name(target) for target in targets]
    selected = set()
    while stack:
        key = stack.pop()
        if key in selected:
            continue
        if not graph.is_declared(key):
            raise UnknownPackageError(key)
        selected.add(key)
        stack.extend(graph.requires_of(key))
    return selected


class _Frontier:
    """Bookkeeping shared by the ordering functions.

    Each selected package waits for a number of requirements.  Placing a
    package releases the packages that were waiting only for it.
    """

    def __init__(self, graph, selected):
        self._graph = graph
        self._waiting = {key: len(graph.requires_of(key)) for key in selected}
        # Work out who is waiting for whom from the requirement lists.
        self._waiters = {key: [] for key in selected}
        for key in selected:
            for requirement in graph.requires_of(key):
                self._waiters[requirement].append(key)

    def start(self):
        """Selected packages that require nothing, sorted."""
        return sorted(key for key, count in self._waiting.items() if count == 0)

    def place(self, key):
        """Mark ``key`` as placed and return the packages this makes ready."""
        del self._waiting[key]
        released = []
        for dependent in sorted(self._waiters[key]):
            if dependent not in self._waiting:
                continue  # not part of this selection
            self._waiting[dependent] -= 1
            if self._waiting[dependent] == 0:
                released.append(dependent)
        return released

    def finish(self):
        """Raise :class:`CycleError` if some packages could never be placed."""
        if self._waiting:
            raise CycleError(self._waiting)


def install_order(graph, targets=None):
    """Return the packages to install, every requirement before its dependents.

    ``targets`` is an iterable of package names; the result contains them and
    everything they need, directly or transitively.  ``None`` means every
    declared package.

    The order is deterministic: at each step, of all the packages whose
    requirements have already been listed, the alphabetically first one (by
    canonical name) comes next.

    Raises :class:`UnknownPackageError` if a target, or anything a target
    needs, has not been declared, and :class:`CycleError` if the selected
    packages contain a dependency cycle.
    """
    frontier = _Frontier(graph, _selection(graph, targets))
    ready = frontier.start()  # a sorted list is already a valid heap
    order = []
    while ready:
        key = heapq.heappop(ready)
        order.append(key)
        for released in frontier.place(key):
            heapq.heappush(ready, released)
    frontier.finish()
    return order


def install_layers(graph, targets=None):
    """Return the selected packages grouped into layers that can run in parallel.

    The first layer holds the packages that require nothing.  Every other
    package sits in the earliest layer that comes after all of its
    requirements.  Names inside a layer are sorted alphabetically.

    ``targets`` and the errors raised are the same as for :func:`install_order`.
    """
    frontier = _Frontier(graph, _selection(graph, targets))
    layer = frontier.start()
    layers = []
    while layer:
        layers.append(layer)
        released = []
        for key in layer:
            released.extend(frontier.place(key))
        layer = sorted(released)
    frontier.finish()
    return layers


def rebuild_set(graph, changed):
    """Return what has to be rebuilt after the ``changed`` packages change.

    That is the changed packages themselves plus every package that requires
    one of them, directly or transitively.  The result is listed in the order
    :func:`install_order` gives for the whole graph, so it can be rebuilt
    front to back.

    Raises :class:`UnknownPackageError` if a changed package is not declared.
    The whole graph must be orderable, so the errors of :func:`install_order`
    apply as well.
    """
    affected = set()
    stack = [canonical_name(name) for name in changed]
    while stack:
        key = stack.pop()
        if key in affected:
            continue
        if not graph.is_declared(key):
            raise UnknownPackageError(key)
        affected.add(key)
        stack.extend(graph.dependents_of(key))
    return [key for key in install_order(graph) if key in affected]
