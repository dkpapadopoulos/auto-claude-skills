import itertools
import unittest

from depgraph import (
    CycleError,
    DuplicatePackageError,
    UnknownPackageError,
    install_layers,
    install_order,
    load_graph,
)

PLATFORM = """\
# platform services
gateway: auth, api, tls
api: storage, cache, auth
auth: storage, tls
worker: api, queue
storage:
cache:
queue: storage
tls:
"""

# A small graph whose lines are tried in every possible order.
SMALL_LINES = ["app: web, jobs", "web: core, tls", "jobs: core", "core:", "tls:"]
SMALL_ORDER = ["core", "jobs", "tls", "web", "app"]
SMALL_LAYERS = [["core", "tls"], ["jobs", "web"], ["app"]]


def every_arrangement(lines):
    for arrangement in itertools.permutations(lines):
        yield "\n".join(arrangement) + "\n"


class PlatformManifestOrderingTest(unittest.TestCase):
    def test_install_order_of_reported_manifest(self):
        graph = load_graph(PLATFORM)
        self.assertEqual(
            install_order(graph),
            ["cache", "storage", "queue", "tls", "auth", "api", "gateway", "worker"],
        )

    def test_install_layers_of_reported_manifest(self):
        graph = load_graph(PLATFORM)
        self.assertEqual(
            install_layers(graph),
            [["cache", "storage", "tls"], ["auth", "queue"], ["api"], ["gateway", "worker"]],
        )

    def test_install_order_for_one_target_of_reported_manifest(self):
        graph = load_graph(PLATFORM)
        self.assertEqual(
            install_order(graph, ["api"]), ["cache", "storage", "tls", "auth", "api"]
        )


class LineOrderDoesNotMatterTest(unittest.TestCase):
    def test_install_order_same_for_every_line_order(self):
        wrong = []
        for text in every_arrangement(SMALL_LINES):
            try:
                result = install_order(load_graph(text))
            except CycleError as error:
                result = repr(error)
            if result != SMALL_ORDER:
                wrong.append((text, result))
        self.assertEqual(wrong, [], f"{len(wrong)} of 120 line orders gave another result")

    def test_install_layers_same_for_every_line_order(self):
        wrong = []
        for text in every_arrangement(SMALL_LINES):
            try:
                result = install_layers(load_graph(text))
            except CycleError as error:
                result = repr(error)
            if result != SMALL_LAYERS:
                wrong.append((text, result))
        self.assertEqual(wrong, [], f"{len(wrong)} of 120 line orders gave another result")

    def test_spellings_match_when_dependent_is_listed_first(self):
        graph = load_graph("Web_App: Data.Store\ndata-store:\n")
        self.assertEqual(install_order(graph), ["data-store", "web-app"])


class ErrorsStillReportedTest(unittest.TestCase):
    def test_real_cycle_reported_when_dependents_are_listed_first(self):
        graph = load_graph("top: c\nc: b\nb: a\na: base, c\nbase:\nfree:\n")
        with self.assertRaises(CycleError) as caught:
            install_order(graph)
        self.assertEqual(caught.exception.packages, ("a", "b", "c", "top"))
        with self.assertRaises(CycleError):
            install_layers(graph)

    def test_undeclared_requirement_reported_when_dependent_is_listed_first(self):
        graph = load_graph("app: web, Missing_Lib\nweb:\n")
        with self.assertRaises(UnknownPackageError) as caught:
            install_order(graph)
        self.assertEqual(caught.exception.name, "missing-lib")

    def test_second_declaration_rejected_after_being_required_first(self):
        with self.assertRaises(DuplicatePackageError) as caught:
            load_graph("app: lib\nlib:\nLib: other\nother:\n")
        self.assertEqual(caught.exception.name, "lib")


if __name__ == "__main__":
    unittest.main()
