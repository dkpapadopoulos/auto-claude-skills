import itertools
import unittest

from depgraph import CycleError, DependencyGraph, install_order, load_graph, rebuild_set

PLATFORM = """\
# platform services
gateway: auth, api, tls
api: storage, cache, auth
auth: storage, tls
worker: api, queue
storage:
cache:
queue: storage
tls:
"""

SMALL_LINES = ["app: web, jobs", "web: core, tls", "jobs: core", "core:", "tls:"]


class DependentsTest(unittest.TestCase):
    def test_dependents_of_reported_manifest(self):
        graph = load_graph(PLATFORM)
        self.assertEqual(graph.dependents_of("storage"), ("api", "auth", "queue"))

    def test_dependents_same_for_every_line_order(self):
        expected = {"core": ("jobs", "web"), "tls": ("web",), "app": ()}
        wrong = []
        for arrangement in itertools.permutations(SMALL_LINES):
            text = "\n".join(arrangement) + "\n"
            graph = load_graph(text)
            result = {name: graph.dependents_of(name) for name in expected}
            if result != expected:
                wrong.append((text, result))
        self.assertEqual(wrong, [], f"{len(wrong)} of 120 line orders gave another result")

    def test_graph_built_in_code_with_dependent_added_first(self):
        graph = DependencyGraph()
        graph.add_package("app", ["lib", "util"])
        graph.add_package("util", ["lib"])
        graph.add_package("lib")
        self.assertEqual(graph.dependents_of("lib"), ("app", "util"))
        self.assertEqual(install_order(graph), ["lib", "util", "app"])
        self.assertEqual(rebuild_set(graph, ["util"]), ["util", "app"])


class RebuildSetTest(unittest.TestCase):
    def test_rebuild_set_of_reported_manifest(self):
        graph = load_graph(PLATFORM)
        self.assertEqual(rebuild_set(graph, ["auth"]), ["auth", "api", "gateway", "worker"])
        self.assertEqual(
            rebuild_set(graph, ["storage"]),
            ["storage", "queue", "auth", "api", "gateway", "worker"],
        )

    def test_rebuild_set_same_for_every_line_order(self):
        expected = {"core": ["core", "jobs", "web", "app"], "tls": ["tls", "web", "app"]}
        wrong = []
        for arrangement in itertools.permutations(SMALL_LINES):
            text = "\n".join(arrangement) + "\n"
            graph = load_graph(text)
            try:
                result = {name: rebuild_set(graph, [name]) for name in expected}
            except CycleError as error:
                result = repr(error)
            if result != expected:
                wrong.append((text, result))
        self.assertEqual(wrong, [], f"{len(wrong)} of 120 line orders gave another result")


if __name__ == "__main__":
    unittest.main()
