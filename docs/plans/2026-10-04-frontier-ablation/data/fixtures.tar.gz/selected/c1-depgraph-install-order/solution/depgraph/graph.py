"""In-memory dependency graph.

Package names are stored in canonical form (see :func:`canonical_name`), so
``Data_Store``, ``data.store`` and ``data-store`` all name one package.

A package can be named as a requirement before it has been declared.  The
graph keeps a provisional record for such a name; the record turns into a
full package when the declaration arrives.  A name that is required but never
declared stays provisional and is listed by :meth:`DependencyGraph.undeclared`.
"""

import re

from .errors import DuplicatePackageError, UnknownPackageError

_SEPARATORS = re.compile(r"[-_.]+")


def canonical_name(name):
    """Return the canonical spelling of a package name.

    Surrounding whitespace is dropped, letters are lower-cased and every run
    of ``-``, ``_`` and ``.`` becomes a single ``-``.

    >>> canonical_name(" Data_Store ")
    'data-store'
    """
    if not isinstance(name, str):
        raise TypeError("package name must be a string")
    text = name.strip()
    if not text:
        raise ValueError("package name must not be empty")
    return _SEPARATORS.sub("-", text).lower()


class _Node:
    """Everything the graph knows about one package name."""

    __slots__ = ("key", "declared", "requires", "dependents")

    def __init__(self, key, declared):
        self.key = key
        self.declared = declared
        # Canonical names this package requires, in declaration order.
        self.requires = []
        # Canonical names of the packages that require this one.
        self.dependents = set()


class DependencyGraph:
    """A set of declared packages and the requirements between them."""

    def __init__(self):
        self._nodes = {}

    # -- building ---------------------------------------------------------

    def add_package(self, name, requires=()):
        """Declare ``name`` together with the packages it requires.

        Requirements may name packages that are declared later, or never.
        Listing the same requirement twice has no additional effect.

        Raises :class:`DuplicatePackageError` if ``name`` has already been
        declared (being named as a requirement is not a declaration).
        """
        key = canonical_name(name)
        existing = self._nodes.get(key)
        if existing is not None and existing.declared:
            raise DuplicatePackageError(key)
        if existing is None:
            node = _Node(key, declared=True)
            self._nodes[key] = node
        else:
            # The name was already required by an earlier declaration: keep
            # its record, and with it the dependents collected so far.
            node = existing
            node.declared = True
        for requirement in requires:
            required_key = canonical_name(requirement)
            if required_key in node.requires:
                continue
            node.requires.append(required_key)
            self._lookup_or_reserve(required_key).dependents.add(key)

    def _lookup_or_reserve(self, key):
        node = self._nodes.get(key)
        if node is None:
            node = _Node(key, declared=False)
            self._nodes[key] = node
        return node

    # -- queries ----------------------------------------------------------

    def is_declared(self, name):
        """True if ``name`` has been declared with :meth:`add_package`."""
        node = self._nodes.get(canonical_name(name))
        return node is not None and node.declared

    def __contains__(self, name):
        return self.is_declared(name)

    def __len__(self):
        return len(self.packages())

    def packages(self):
        """Canonical names of all declared packages, sorted."""
        return tuple(sorted(key for key, node in self._nodes.items() if node.declared))

    def undeclared(self):
        """Canonical names that are required but were never declared, sorted."""
        return tuple(sorted(key for key, node in self._nodes.items() if not node.declared))

    def requires_of(self, name):
        """Direct requirements of ``name``, in the order they were declared.

        Raises :class:`UnknownPackageError` if ``name`` is not declared.
        """
        return tuple(self._declared(name).requires)

    def dependents_of(self, name):
        """Declared packages that directly require ``name``, sorted.

        Raises :class:`UnknownPackageError` if ``name`` is not declared.
        """
        return tuple(sorted(self._declared(name).dependents))

    def _declared(self, name):
        key = canonical_name(name)
        node = self._nodes.get(key)
        if node is None or not node.declared:
            raise UnknownPackageError(key)
        return node
