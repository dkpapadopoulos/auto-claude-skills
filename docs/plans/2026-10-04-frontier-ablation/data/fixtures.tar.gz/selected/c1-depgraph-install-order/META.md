# c1-depgraph-install-order

Category c (debugging with a misleading symptom). Domain: dependency-graph resolution.

## Trap

The symptom is a `CycleError` raised in `depgraph/resolve.py`, but the defect is in `depgraph/graph.py`: `DependencyGraph.add_package` replaces the provisional record of a package that was required before it was declared, throwing away the dependents collected so far. Rebuilding the reverse edges inside `resolve._Frontier` (wrong_fix) makes `install_order`/`install_layers` pass the visible tests but leaves `dependents_of` and `rebuild_set` wrong.

## Hidden tests -> requirement

| Hidden test | Required by |
|---|---|
| `test_declaration_order.PlatformManifestOrderingTest.test_install_order_of_reported_manifest` | TASK.md: "`install_order(graph)` returns `["cache", "storage", "queue", "tls", "auth", "api", "gateway", "worker"]`" |
| `test_declaration_order.PlatformManifestOrderingTest.test_install_layers_of_reported_manifest` | TASK.md: "`install_layers(graph)` returns `[["cache", "storage", "tls"], ["auth", "queue"], ["api"], ["gateway", "worker"]]`" |
| `test_declaration_order.PlatformManifestOrderingTest.test_install_order_for_one_target_of_reported_manifest` | TASK.md: "`install_order(graph, ["api"])` returns `["cache", "storage", "tls", "auth", "api"]`" |
| `test_declaration_order.LineOrderDoesNotMatterTest.test_install_order_same_for_every_line_order` | TASK.md: "The order of the lines in a manifest is not significant. `install_order`, `install_layers`, `rebuild_set` and `DependencyGraph.dependents_of` must give the same answer whichever way round the lines of a manifest are written, ..." Expected value from README "Ordering rules" (alphabetically first ready package next). |
| `test_declaration_order.LineOrderDoesNotMatterTest.test_install_layers_same_for_every_line_order` | Same TASK.md sentence. Expected value from README "Ordering rules" (`install_layers`). |
| `test_declaration_order.LineOrderDoesNotMatterTest.test_spellings_match_when_dependent_is_listed_first` | TASK.md: "Names still match across spellings (`Web_App` requiring `Data.Store` is satisfied by a `data-store` line), and results use canonical names." |
| `test_declaration_order.ErrorsStillReportedTest.test_real_cycle_reported_when_dependents_are_listed_first` | TASK.md: "A real cycle is still reported with `CycleError`, and its `packages` attribute still names exactly the packages on the cycle plus the selected packages that depend on it, wherever the lines are." (`packages` is a sorted tuple: README "Cycles".) |
| `test_declaration_order.ErrorsStillReportedTest.test_undeclared_requirement_reported_when_dependent_is_listed_first` | TASK.md: "A requirement that is never declared still raises `UnknownPackageError` with the canonical name in `name`." |
| `test_declaration_order.ErrorsStillReportedTest.test_second_declaration_rejected_after_being_required_first` | TASK.md: "Declaring a package twice still raises `DuplicatePackageError`, including when the package was named as a requirement before its first declaration." (`name` is canonical: `errors.DuplicatePackageError` docstring.) |
| `test_reverse_lookups.DependentsTest.test_dependents_of_reported_manifest` | TASK.md: "`graph.dependents_of("storage")` returns `("api", "auth", "queue")`" |
| `test_reverse_lookups.DependentsTest.test_dependents_same_for_every_line_order` | TASK.md: "The order of the lines in a manifest is not significant. `install_order`, `install_layers`, `rebuild_set` and `DependencyGraph.dependents_of` must give the same answer whichever way round the lines of a manifest are written, ..." Expected value from the `dependents_of` docstring (declared packages that directly require the name, sorted). |
| `test_reverse_lookups.DependentsTest.test_graph_built_in_code_with_dependent_added_first` | TASK.md: "... and the same holds for a graph built in code with `DependencyGraph.add_package` calls in any order." |
| `test_reverse_lookups.RebuildSetTest.test_rebuild_set_of_reported_manifest` | TASK.md: "`rebuild_set(graph, ["auth"])` returns `["auth", "api", "gateway", "worker"]`" and "`rebuild_set(graph, ["storage"])` returns `["storage", "queue", "auth", "api", "gateway", "worker"]`" |
| `test_reverse_lookups.RebuildSetTest.test_rebuild_set_same_for_every_line_order` | Same TASK.md line-order sentence. Expected value from README: `rebuild_set` is "the changed packages and everything that depends on them, in install order". |

## Expected results

| Configuration | `repo/tests` (20) | `hidden_tests` (14) |
|---|---|---|
| untouched `repo/` | 1 fails (`test_platform_manifest_installs`) | 11 fail |
| `repo/` + `solution/` | all pass | all pass |
| `repo/` + `wrong_fix/` | all pass | 5 fail (all of `test_reverse_lookups`'s dependents/rebuild tests) |
