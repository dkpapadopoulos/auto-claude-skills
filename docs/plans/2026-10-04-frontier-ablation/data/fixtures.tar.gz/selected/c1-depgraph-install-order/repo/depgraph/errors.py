"""Exceptions raised by the depgraph package."""


class DependencyError(Exception):
    """Base class for every error raised by this package."""


class ManifestError(DependencyError):
    """A manifest line could not be understood.

    ``line`` is the 1-based number of the offending line.
    """

    def __init__(self, line, reason):
        super().__init__(f"line {line}: {reason}")
        self.line = line
        self.reason = reason


class DuplicatePackageError(DependencyError):
    """The same package was declared twice.

    ``name`` is the canonical name of the package.
    """

    def __init__(self, name):
        super().__init__(f"package declared more than once: {name}")
        self.name = name


class UnknownPackageError(DependencyError):
    """A package was asked for, or required, but never declared.

    ``name`` is the canonical name of the package.
    """

    def __init__(self, name):
        super().__init__(f"package is not declared: {name}")
        self.name = name


class CycleError(DependencyError):
    """The requested packages cannot be ordered because of a cycle.

    ``packages`` is a sorted tuple of the canonical names that could not be
    ordered: every package that is part of a cycle, plus every requested
    package that depends on one (directly or transitively).
    """

    def __init__(self, packages):
        self.packages = tuple(sorted(packages))
        super().__init__("dependency cycle among: " + ", ".join(self.packages))
