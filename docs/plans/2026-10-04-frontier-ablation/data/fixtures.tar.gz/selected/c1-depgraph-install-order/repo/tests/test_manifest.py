import unittest

from depgraph import (
    DuplicatePackageError,
    ManifestError,
    canonical_name,
    load_graph,
    parse_manifest,
)


class ParseManifestTest(unittest.TestCase):
    def test_entries_in_file_order(self):
        text = "lib:\napp: lib\n"
        self.assertEqual(parse_manifest(text), [("lib", []), ("app", ["lib"])])

    def test_commas_and_spaces_separate_requirements(self):
        text = "app: a, b c ,d\n"
        self.assertEqual(parse_manifest(text), [("app", ["a", "b", "c", "d"])])

    def test_comments_and_blank_lines(self):
        text = "# header\n\nlib   # nothing needed\napp: lib # needs lib\n"
        self.assertEqual(parse_manifest(text), [("lib", []), ("app", ["lib"])])

    def test_missing_name_reports_line(self):
        with self.assertRaises(ManifestError) as caught:
            parse_manifest("lib:\n: app\n")
        self.assertEqual(caught.exception.line, 2)

    def test_invalid_name_reports_line(self):
        with self.assertRaises(ManifestError) as caught:
            parse_manifest("lib:\n\napp: li/b\n")
        self.assertEqual(caught.exception.line, 3)


class LoadGraphTest(unittest.TestCase):
    def test_packages_are_canonical_and_sorted(self):
        graph = load_graph("Zeta_Tool:\nalpha.lib:\n")
        self.assertEqual(graph.packages(), ("alpha-lib", "zeta-tool"))

    def test_requires_of_keeps_declaration_order(self):
        graph = load_graph("b:\na:\napp: b, a\n")
        self.assertEqual(graph.requires_of("app"), ("b", "a"))

    def test_repeated_requirement_counts_once(self):
        graph = load_graph("lib:\napp: lib, LIB\n")
        self.assertEqual(graph.requires_of("app"), ("lib",))

    def test_duplicate_declaration(self):
        with self.assertRaises(DuplicatePackageError) as caught:
            load_graph("lib:\napp: lib\nLib:\n")
        self.assertEqual(caught.exception.name, "lib")

    def test_undeclared_requirement_is_remembered(self):
        graph = load_graph("app: lib\n")
        self.assertEqual(graph.undeclared(), ("lib",))
        self.assertFalse(graph.is_declared("lib"))

    def test_canonical_name(self):
        self.assertEqual(canonical_name(" Data__Store.v2 "), "data-store-v2")


if __name__ == "__main__":
    unittest.main()
