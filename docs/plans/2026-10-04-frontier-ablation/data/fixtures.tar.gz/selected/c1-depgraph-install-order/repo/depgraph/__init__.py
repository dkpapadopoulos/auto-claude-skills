"""depgraph - small dependency-graph toolkit used by the deploy tooling.

Typical use::

    from depgraph import load_graph, install_order

    graph = load_graph(open("services.deps").read())
    for package in install_order(graph):
        deploy(package)
"""

from .errors import (
    CycleError,
    DependencyError,
    DuplicatePackageError,
    ManifestError,
    UnknownPackageError,
)
from .graph import DependencyGraph, canonical_name
from .manifest import load_graph, parse_manifest
from .resolve import install_layers, install_order, rebuild_set

__all__ = [
    "CycleError",
    "DependencyError",
    "DependencyGraph",
    "DuplicatePackageError",
    "ManifestError",
    "UnknownPackageError",
    "canonical_name",
    "install_layers",
    "install_order",
    "load_graph",
    "parse_manifest",
    "rebuild_set",
]
