# `install_order` reports a dependency cycle for the platform manifest, which has none

## What happens

The deploy job for the platform services started failing this morning with

```
depgraph.errors.CycleError: dependency cycle among: api, auth, gateway, worker
```

This is the manifest it reads (`PLATFORM` in `tests/test_resolve.py`):

```
# platform services
gateway: auth, api, tls
api: storage, cache, auth
auth: storage, tls
worker: api, queue
storage:
cache:
queue: storage
tls:
```

I have gone through it by hand twice. There is no cycle in there: `gateway`
needs `auth`, `api` and `tls`; `api` needs `storage`, `cache` and `auth`; `auth`
needs `storage` and `tls`; `worker` needs `api` and `queue`; `queue` needs
`storage`; nothing points back up.

To reproduce:

```
python3 -m unittest tests.test_resolve.PlatformManifestTest
```

`test_platform_manifest_installs` fails with the `CycleError` above. Every other
test passes.

## What I expect

For the manifest above:

* `install_order(graph)` returns
  `["cache", "storage", "queue", "tls", "auth", "api", "gateway", "worker"]`
* `install_layers(graph)` returns
  `[["cache", "storage", "tls"], ["auth", "queue"], ["api"], ["gateway", "worker"]]`
* `install_order(graph, ["api"])` returns `["cache", "storage", "tls", "auth", "api"]`
* `graph.dependents_of("storage")` returns `("api", "auth", "queue")`
* `rebuild_set(graph, ["auth"])` returns `["auth", "api", "gateway", "worker"]`
* `rebuild_set(graph, ["storage"])` returns
  `["storage", "queue", "auth", "api", "gateway", "worker"]`

More generally, please make sure the library does what the README promises once
this is fixed:

* The order of the lines in a manifest is not significant. `install_order`,
  `install_layers`, `rebuild_set` and `DependencyGraph.dependents_of` must give
  the same answer whichever way round the lines of a manifest are written, and
  the same holds for a graph built in code with `DependencyGraph.add_package`
  calls in any order.
* Names still match across spellings (`Web_App` requiring `Data.Store` is
  satisfied by a `data-store` line), and results use canonical names.
* A real cycle is still reported with `CycleError`, and its `packages`
  attribute still names exactly the packages on the cycle plus the selected
  packages that depend on it, wherever the lines are.
* A requirement that is never declared still raises `UnknownPackageError` with
  the canonical name in `name`.
* Declaring a package twice still raises `DuplicatePackageError`, including
  when the package was named as a requirement before its first declaration.

Please don't change the public function signatures or the manifest format; the
deploy tooling calls them as they are.
