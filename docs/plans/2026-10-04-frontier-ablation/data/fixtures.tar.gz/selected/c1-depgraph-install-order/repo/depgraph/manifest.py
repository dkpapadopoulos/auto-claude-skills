"""Reading dependency manifests.

A manifest is plain text with one package declaration per line::

    # comments start with a hash and run to the end of the line
    gateway: auth, api      # a name, a colon, then what it requires
    auth: storage tls       # requirements are separated by commas and/or spaces
    storage:                # a package that requires nothing
    tls                     # ... the colon is optional in that case

Blank lines are ignored.  The order of the lines is not significant: a package
may be required on a line above the one that declares it.
"""

import re

from .errors import ManifestError
from .graph import DependencyGraph

_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
_SPLIT = re.compile(r"[,\s]+")


def _check_name(number, token):
    if not _NAME.match(token):
        raise ManifestError(number, f"invalid package name {token!r}")
    return token


def parse_manifest(text):
    """Parse manifest text into ``[(name, [requirement, ...]), ...]``.

    Entries are returned in the order they appear and names are returned as
    written (they are canonicalised when they enter a graph).

    Raises :class:`ManifestError` carrying the 1-based line number when a line
    has no package name, or when a name contains characters other than
    letters, digits, ``.``, ``_`` and ``-``.
    """
    entries = []
    for number, raw in enumerate(text.splitlines(), start=1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        head, colon, tail = line.partition(":")
        head = head.strip()
        if not head:
            raise ManifestError(number, "missing package name")
        if not colon and len(head.split()) > 1:
            raise ManifestError(number, "expected 'name: requirements'")
        name = _check_name(number, head)
        requirements = [
            _check_name(number, token) for token in _SPLIT.split(tail.strip()) if token
        ]
        entries.append((name, requirements))
    return entries


def load_graph(text):
    """Build a :class:`DependencyGraph` from manifest text.

    Raises :class:`ManifestError` for malformed lines and
    :class:`DuplicatePackageError` when a package is declared on two lines.
    Requirements that are never declared do not fail here; they are reported
    when an ordering that needs them is requested.
    """
    graph = DependencyGraph()
    for name, requirements in parse_manifest(text):
        graph.add_package(name, requirements)
    return graph
