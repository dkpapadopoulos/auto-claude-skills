# depgraph

A small dependency-graph toolkit. The deploy tooling uses it to decide in which
order services are installed and what has to be rebuilt after a change.

## Manifest format

One package declaration per line:

```
# comments start with a hash and run to the end of the line
gateway: auth, api      # a name, a colon, then what it requires
auth: storage tls       # requirements are separated by commas and/or spaces
storage:                # a package that requires nothing
tls                     # ... the colon is optional in that case
```

* Blank lines are ignored.
* **The order of the lines is not significant.** A package may be required on a
  line above the one that declares it. Two manifests with the same lines in a
  different order describe the same graph and give the same answers.
* Names are canonicalised: letters are lower-cased and runs of `-`, `_` and `.`
  become a single `-`. `Data_Store`, `data.store` and `data-store` are the same
  package. Every function returns canonical names.
* Declaring the same package on two lines is an error (`DuplicatePackageError`).
  Being named as a requirement is not a declaration.
* A requirement that is never declared is reported with `UnknownPackageError`
  (its `name` attribute holds the canonical name) by any ordering query that
  needs the package.

## API

| Function | Result |
|---|---|
| `load_graph(text)` | a `DependencyGraph` built from manifest text |
| `DependencyGraph.add_package(name, requires=())` | declare a package in code; same rules as a manifest line |
| `DependencyGraph.requires_of(name)` | direct requirements, in declaration order |
| `DependencyGraph.dependents_of(name)` | declared packages that directly require `name`, sorted |
| `install_order(graph, targets=None)` | list with every requirement before its dependents |
| `install_layers(graph, targets=None)` | list of layers that can be installed in parallel |
| `rebuild_set(graph, changed)` | the changed packages and everything that depends on them, in install order |

`targets=None` means "every declared package"; otherwise the result covers the
targets and everything they need, directly or transitively.

### Ordering rules

* `install_order` is deterministic: at each step, of all the packages whose
  requirements have already been listed, the alphabetically first one comes
  next.
* `install_layers`: the first layer holds the packages that require nothing;
  every other package sits in the earliest layer that comes after all of its
  requirements. Names inside a layer are sorted.
* `rebuild_set` lists its packages in the order `install_order(graph)` gives
  them.

### Cycles

If the selected packages contain a dependency cycle the ordering functions raise
`CycleError`. Its `packages` attribute is a sorted tuple naming every package
that is part of a cycle plus every selected package that depends on one.

## Running the tests

```
python3 -m unittest discover -s tests
```
