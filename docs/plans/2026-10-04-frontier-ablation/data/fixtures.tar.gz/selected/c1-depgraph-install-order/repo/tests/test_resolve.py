import unittest

from depgraph import (
    CycleError,
    UnknownPackageError,
    install_layers,
    install_order,
    load_graph,
    rebuild_set,
)

WEBSHOP = """\
db:
log:
models: db
views: models, log
app: views, log
"""

PLATFORM = """\
# platform services
gateway: auth, api, tls
api: storage, cache, auth
auth: storage, tls
worker: api, queue
storage:
cache:
queue: storage
tls:
"""


class InstallOrderTest(unittest.TestCase):
    def test_requirements_come_first(self):
        graph = load_graph(WEBSHOP)
        self.assertEqual(install_order(graph), ["db", "log", "models", "views", "app"])

    def test_alphabetical_among_ready_packages(self):
        graph = load_graph("zlib:\nbzip:\narchive: zlib, bzip\naaa:\n")
        self.assertEqual(install_order(graph), ["aaa", "bzip", "zlib", "archive"])

    def test_targets_limit_the_result(self):
        graph = load_graph(WEBSHOP)
        self.assertEqual(install_order(graph, ["models"]), ["db", "models"])

    def test_unknown_target(self):
        graph = load_graph(WEBSHOP)
        with self.assertRaises(UnknownPackageError) as caught:
            install_order(graph, ["Billing"])
        self.assertEqual(caught.exception.name, "billing")

    def test_cycle_is_reported(self):
        graph = load_graph("base:\na: base, c\nb: a\nc: b\ntop: c\n")
        with self.assertRaises(CycleError) as caught:
            install_order(graph)
        self.assertEqual(caught.exception.packages, ("a", "b", "c", "top"))


class InstallLayersTest(unittest.TestCase):
    def test_layers(self):
        graph = load_graph(WEBSHOP)
        self.assertEqual(
            install_layers(graph), [["db", "log"], ["models"], ["views"], ["app"]]
        )


class RebuildSetTest(unittest.TestCase):
    def test_everything_above_the_change(self):
        graph = load_graph(WEBSHOP)
        self.assertEqual(rebuild_set(graph, ["models"]), ["models", "views", "app"])

    def test_direct_dependents(self):
        graph = load_graph(WEBSHOP)
        self.assertEqual(graph.dependents_of("log"), ("app", "views"))


class PlatformManifestTest(unittest.TestCase):
    def test_platform_manifest_installs(self):
        graph = load_graph(PLATFORM)
        self.assertEqual(
            install_order(graph),
            ["cache", "storage", "queue", "tls", "auth", "api", "gateway", "worker"],
        )


if __name__ == "__main__":
    unittest.main()
