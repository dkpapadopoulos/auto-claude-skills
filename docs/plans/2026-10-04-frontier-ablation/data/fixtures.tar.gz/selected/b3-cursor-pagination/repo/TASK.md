# Add continuation pages to the activity feed

The feed catalogue currently exports all entries; the UI needs forward pagination that survives inserts and removals between requests.

Implement `page(catalogue, limit=20, cursor=None, category=None)` in `feed.paging`, returning a `Page` whose `items` is a tuple of detached `Entry` values and whose `next_cursor` is a string or `None`.

Select entries matching `category` (or all entries for `None`), sort ascending by `(stamp, id)` using Python integer/string ordering, and return at most `limit` items without changing the catalogue.

A continuation resumes strictly after the last returned `(stamp, id)` even if that entry has since been removed; entries inserted at or before that key are excluded, and newer matching keys remain eligible.

Set `next_cursor` only when another matching entry remains after this page; empty and final pages have `None`, including a final page exactly `limit` long.

Use the versioned token codec in `feed.cursor`; cursors are reusable, contain the last returned key rather than an offset, and are bound to the category value, but not to the page limit.

Reject malformed tokens or a token used with a different category with `ValueError("invalid cursor")`, including when the catalogue is empty; `cursor=None` alone starts a new traversal.

Require `limit` to be an integer from 1 through 100, excluding booleans, otherwise raise `ValueError("limit must be an integer from 1 to 100")`.

Require `category` to be `None` or a string (including the empty string), otherwise raise `TypeError("category must be a string or None")`.

Returned payloads must not share mutable data with the catalogue or other page calls; retain the existing catalogue operations and their documented validation and ownership behavior.
