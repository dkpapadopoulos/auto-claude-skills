"""Version-one continuation token serialization.

The wire object contains a version, a category filter, and an exclusive
lower key. This codec is deliberately independent of catalogue contents:
a removed record is still a valid position in the ordering.
Tokens are opaque navigation state, not credentials or signatures.
"""
import base64
import binascii
import json


VERSION = 1


def encode(key, category):
    """Serialize a validated (stamp, id) and category as a URL-safe token."""
    document = {"v": VERSION, "category": category, "after": list(key)}
    raw = json.dumps(document, ensure_ascii=True, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(raw).decode("ascii")


def decode(token):
    """Return (key, category), mapping all invalid input to one public error."""
    try:
        if not isinstance(token, str) or not token:
            raise ValueError
        raw = base64.b64decode(token.encode("ascii"), altchars=b"-_", validate=True)
        document = json.loads(raw)
        if not isinstance(document, dict):
            raise ValueError
        if set(document) != {"v", "category", "after"}:
            raise ValueError
        if type(document["v"]) is not int or document["v"] != VERSION:
            raise ValueError
        category = document["category"]
        if category is not None and not isinstance(category, str):
            raise ValueError
        key = document["after"]
        if not isinstance(key, list) or len(key) != 2:
            raise ValueError
        if type(key[0]) is not int or not isinstance(key[1], str) or not key[1]:
            raise ValueError
        return tuple(key), category
    except (ValueError, TypeError, UnicodeError, binascii.Error) as exc:
        raise ValueError("invalid cursor") from exc
