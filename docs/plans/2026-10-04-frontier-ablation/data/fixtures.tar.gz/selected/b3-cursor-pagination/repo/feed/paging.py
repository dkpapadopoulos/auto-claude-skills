"""Presentation-facing feed operations.

Full exports are kept for batch clients. Interactive clients use a Page
so that the presence of a continuation is explicit, including empty feeds.
"""
from dataclasses import dataclass
from .catalogue import Entry
from .cursor import encode, decode


@dataclass(frozen=True)
class Page:
    """A forward page with detached records and an optional continuation."""

    items: tuple[Entry, ...]
    next_cursor: str | None


def export_category(catalogue, category=None):
    """Export all matching entries in stable chronological order."""
    return tuple(sorted(catalogue.snapshot(category), key=lambda entry: entry.key))


def category_counts(catalogue):
    """Provide filter-menu counts without loading payloads into the UI."""
    return {name: catalogue.count(name) for name in catalogue.categories()}


def page(catalogue, limit=20, cursor=None, category=None):
    """Return a bounded forward page in the catalogue's total key order."""
    raise NotImplementedError("continuation pages are not implemented")
