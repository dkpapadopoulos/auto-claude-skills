"""Activity feed storage and navigation."""
