"""Owned activity records with stable identifiers.

A stamp is an integer logical sequence, not a wall-clock timestamp. More
than one entry can share a stamp. Identifiers are unique within a catalogue.
Updates replace a record without changing any other record.
"""
from copy import deepcopy
from dataclasses import dataclass


@dataclass(frozen=True)
class Entry:
    """One activity; payload is a dictionary owned by its current caller."""

    id: str
    stamp: int
    category: str
    payload: dict

    def __post_init__(self):
        if not isinstance(self.id, str) or not self.id:
            raise ValueError("id must be a nonempty string")
        if type(self.stamp) is not int:
            raise TypeError("stamp must be an integer")
        if not isinstance(self.category, str):
            raise TypeError("entry category must be a string")
        if not isinstance(self.payload, dict):
            raise TypeError("payload must be a dictionary")

    @property
    def key(self):
        """The public total ordering key, independent of insertion order."""
        return self.stamp, self.id

    def detached(self):
        """Copy mutable payload data without changing record identity."""
        return Entry(self.id, self.stamp, self.category, deepcopy(self.payload))


class Catalogue:
    """In-memory records; readers and writers never share payload ownership."""

    def __init__(self, entries=()):
        self._entries = {}
        for entry in entries:
            self.upsert(entry)

    def upsert(self, entry):
        """Insert or replace by id, accepting only Entry instances."""
        if not isinstance(entry, Entry):
            raise TypeError("expected Entry")
        self._entries[entry.id] = entry.detached()

    def remove(self, identifier):
        """Return whether an entry existed; repeated removal is harmless."""
        return self._entries.pop(identifier, None) is not None

    def get(self, identifier):
        """Return a detached record; missing identifiers raise KeyError."""
        return self._entries[identifier].detached()

    def snapshot(self, category=None):
        """Return detached entries in insertion order, optionally filtered."""
        return tuple(entry.detached() for entry in self._entries.values()
                     if category is None or entry.category == category)

    def categories(self):
        """Return distinct category labels in lexical order."""
        return tuple(sorted({entry.category for entry in self._entries.values()}))

    def count(self, category=None):
        """Count records, not distinct stamps."""
        return sum(category is None or entry.category == category
                   for entry in self._entries.values())

    def export(self):
        """Return detached dictionaries in total key order for diagnostics."""
        return [{"id": entry.id, "stamp": entry.stamp,
                 "category": entry.category, "payload": entry.payload}
                for entry in sorted(self.snapshot(), key=lambda entry: entry.key)]
