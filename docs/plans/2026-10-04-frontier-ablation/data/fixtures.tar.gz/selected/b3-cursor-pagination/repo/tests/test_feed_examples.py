import unittest
from feed.catalogue import Catalogue, Entry
from feed.paging import page


class Examples(unittest.TestCase):
    def test_two_pages(self):
        catalogue = Catalogue(Entry(str(n), n, "news", {}) for n in range(3))
        first = page(catalogue, 2)
        self.assertEqual([e.id for e in first.items], ["0", "1"])
        self.assertIsInstance(first.next_cursor, str)
        last = page(catalogue, 2, first.next_cursor)
        self.assertEqual([e.id for e in last.items], ["2"])
        self.assertIsNone(last.next_cursor)
