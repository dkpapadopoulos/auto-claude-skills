import unittest
from feed.catalogue import Catalogue, Entry
from feed.paging import page


def entry(identifier, stamp, category="news"):
    return Entry(identifier, stamp, category, {"tags": [identifier]})


class Contract(unittest.TestCase):
    def test_tied_stamps_use_identifier(self):
        c = Catalogue([entry("z", 1), entry("a", 1), entry("m", 1), entry("b", 2)])
        first = page(c, 1)
        self.assertEqual([e.id for e in first.items], ["a"])
        second = page(c, 2, first.next_cursor)
        self.assertEqual([e.id for e in second.items], ["m", "z"])
        self.assertEqual([e.id for e in page(c, 2, second.next_cursor).items], ["b"])

    def test_deleted_anchor_and_insertions(self):
        c = Catalogue([entry("a", 10), entry("c", 30), entry("e", 50)])
        token = page(c, 1).next_cursor
        c.remove("a")
        c.upsert(entry("old", 5))
        c.upsert(entry("b", 20))
        self.assertEqual([e.id for e in page(c, 10, token).items], ["b", "c", "e"])

    def test_filter_before_limit_and_continuation(self):
        c = Catalogue([entry("a", 1, "other"), entry("b", 2), entry("c", 3, "other")])
        result = page(c, 1, category="news")
        self.assertEqual([e.id for e in result.items], ["b"])
        self.assertIsNone(result.next_cursor)
        self.assertEqual(page(c, category="absent").items, ())

    def test_final_and_empty_pages(self):
        self.assertEqual(page(Catalogue()).items, ())
        self.assertIsNone(page(Catalogue()).next_cursor)
        c = Catalogue([entry("a", 1), entry("b", 2)])
        self.assertIsNone(page(c, 2).next_cursor)
        token = page(c, 1).next_cursor
        c.remove("b")
        self.assertEqual(page(c, 2, token).items, ())
        self.assertIsNone(page(c, 2, token).next_cursor)

    def test_reusable_cursor_with_new_limit(self):
        c = Catalogue(entry(str(n), n) for n in range(6))
        token = page(c, 1).next_cursor
        self.assertEqual([e.id for e in page(c, 3, token).items], ["1", "2", "3"])
        self.assertEqual([e.id for e in page(c, 2, token).items], ["1", "2"])

    def test_filter_binding_including_empty_string(self):
        c = Catalogue([entry("a", 1, ""), entry("b", 2, ""), entry("c", 3)])
        token = page(c, 1, category="").next_cursor
        self.assertEqual([e.id for e in page(c, 1, token, "").items], ["b"])
        for category in (None, "news"):
            with self.subTest(category=category):
                with self.assertRaisesRegex(ValueError, "^invalid cursor$"):
                    page(c, 1, token, category)

    def test_malformed_cursor_even_on_empty(self):
        for token in ("", "?", "e30=", "bnVsbA==", 7, b"abc"):
            with self.subTest(token=token):
                with self.assertRaisesRegex(ValueError, "^invalid cursor$"):
                    page(Catalogue(), cursor=token)

    def test_limit_validation_and_boundaries(self):
        for limit in (True, False, 0, -1, 101, 1.0, "2", None):
            with self.subTest(limit=limit):
                with self.assertRaisesRegex(ValueError, "^limit must be an integer from 1 to 100$"):
                    page(Catalogue(), limit)
        c = Catalogue(entry(str(n), n) for n in range(101))
        self.assertEqual(len(page(c, 100).items), 100)
        self.assertEqual(len(page(c).items), 20)

    def test_category_validation(self):
        for category in (False, 0, [], {}):
            with self.subTest(category=category):
                with self.assertRaisesRegex(TypeError, "^category must be a string or None$"):
                    page(Catalogue(), category=category)

    def test_payload_ownership_and_no_reordering(self):
        c = Catalogue([entry("b", 2), entry("a", 1)])
        before = c.snapshot()
        first = page(c, 1)
        self.assertIsInstance(first.items, tuple)
        first.items[0].payload["tags"].append("changed")
        self.assertEqual(page(c, 1).items[0].payload, {"tags": ["a"]})
        self.assertEqual(c.snapshot(), before)
