"""Presentation-facing feed operations.

Full exports are kept for batch clients. Interactive clients use a Page
so that the presence of a continuation is explicit, including empty feeds.
"""
from dataclasses import dataclass
from .catalogue import Entry
from .cursor import encode, decode


@dataclass(frozen=True)
class Page:
    """A forward page with detached records and an optional continuation."""

    items: tuple[Entry, ...]
    next_cursor: str | None


def export_category(catalogue, category=None):
    """Export all matching entries in stable chronological order."""
    return tuple(sorted(catalogue.snapshot(category), key=lambda entry: entry.key))


def category_counts(catalogue):
    """Provide filter-menu counts without loading payloads into the UI."""
    return {name: catalogue.count(name) for name in catalogue.categories()}


def page(catalogue, limit=20, cursor=None, category=None):
    """Return a bounded forward page in the catalogue's total key order."""
    if type(limit) is not int or not 1 <= limit <= 100:
        raise ValueError("limit must be an integer from 1 to 100")
    if category is not None and not isinstance(category, str):
        raise TypeError("category must be a string or None")
    after = None
    if cursor is not None:
        after, token_category = decode(cursor)
        if token_category != category:
            raise ValueError("invalid cursor")
    entries = export_category(catalogue, category)
    if after is not None:
        entries = tuple(entry for entry in entries if entry.key > after)
    selected = entries[:limit]
    token = encode(selected[-1].key, category) if len(entries) > limit else None
    return Page(selected, token)
