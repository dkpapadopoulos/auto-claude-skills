# Contract coverage

| Hidden test | Required sentence |
| --- | --- |
| `test_deep_delete` | The exported identity marker `DELETE` removes a key at any dictionary depth, missing deletions are no-ops, and `None` remains an ordinary stored value. |
| `test_none_is_data` | The exported identity marker `DELETE` removes a key at any dictionary depth, missing deletions are no-ops, and `None` remains an ordinary stored value. |
| `test_scalar_namespace` | Recursively merge dictionaries, replacing a non-dictionary target with an empty namespace before merging; scalar values and lists replace existing values, and keys including dots are literal. |
| `test_list_replaces` | Recursively merge dictionaries, replacing a non-dictionary target with an empty namespace before merging; scalar values and lists replace existing values, and keys including dots are literal. |
| `test_patch_and_snapshot_detached` | Neither the patch nor its nested mutable values may be mutated or retained by the store; snapshots must also remain independent. |
| `test_atomic_validation` | Validate the entire resulting document using the existing configuration rules before committing, so invalid patches leave both data and revision unchanged. |
| `test_revision_idempotence` | Empty patches and patches producing an equal document preserve the revision; any actual change increments it exactly once, including a patch with several changes. |
| `test_patch_root_type` | Add `apply_patch(store, patch)` in `settings.editor`; it returns the resulting revision and accepts only a dictionary patch, otherwise raising `TypeError("patch must be a mapping")`. |

Trap: Filtering deletion markers only at the top level breaks nested removal.
