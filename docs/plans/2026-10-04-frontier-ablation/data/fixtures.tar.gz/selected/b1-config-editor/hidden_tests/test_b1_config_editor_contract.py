from settings.model import Store
from settings.editor import apply_patch, DELETE
import unittest

class Contract(unittest.TestCase):
    def test_deep_delete(self):
        s = Store({"x": {"a": 1, "b": 2}})
        apply_patch(s, {"x": {"a": DELETE, "missing": DELETE}})
        self.assertEqual(s.snapshot(), {"x": {"b": 2}})

    def test_none_is_data(self):
        s = Store({"x": 3})
        apply_patch(s, {"x": None})
        self.assertEqual(s.snapshot(), {"x": None})

    def test_scalar_namespace(self):
        s = Store({"x": 3, "a.b": 1})
        apply_patch(s, {"x": {"y": [2]}, "a.b": 4})
        self.assertEqual(s.snapshot(), {"x": {"y": [2]}, "a.b": 4})

    def test_list_replaces(self):
        s = Store({"x": [1, 2]})
        apply_patch(s, {"x": []})
        self.assertEqual(s.snapshot(), {"x": []})

    def test_patch_and_snapshot_detached(self):
        s = Store()
        p = {"x": {"y": [1]}}
        apply_patch(s, p)
        self.assertEqual(p, {"x": {"y": [1]}})
        p["x"]["y"].append(2)
        out = s.snapshot()
        out["x"]["y"].append(3)
        self.assertEqual(s.snapshot(), {"x": {"y": [1]}})

    def test_atomic_validation(self):
        s = Store({"good": 1})
        with self.assertRaises(TypeError):
            apply_patch(s, {"good": 2, "bad": {3: "no"}})
        self.assertEqual(s.snapshot(), {"good": 1})
        self.assertEqual(s.revision, 0)

    def test_revision_idempotence(self):
        s = Store({"x": 1})
        self.assertEqual(apply_patch(s, {}), 0)
        self.assertEqual(apply_patch(s, {"missing": DELETE, "x": 1}), 0)
        self.assertEqual(apply_patch(s, {"x": 2, "y": 3}), 1)
        self.assertEqual(apply_patch(s, {"x": 2, "y": 3}), 1)

    def test_patch_root_type(self):
        with self.assertRaisesRegex(TypeError, "^patch must be a mapping$"):
            apply_patch(Store(), [])
