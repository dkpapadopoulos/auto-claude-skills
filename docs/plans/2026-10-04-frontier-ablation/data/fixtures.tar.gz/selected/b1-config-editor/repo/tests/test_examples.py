from settings.model import Store
from settings.editor import apply_patch, DELETE
import unittest

class Examples(unittest.TestCase):
    def test_update(self):
        store = Store({"server": {"port": 80, "host": "local"}, "old": True})
        self.assertEqual(apply_patch(store, {"server": {"port": 90}, "old": DELETE}), 1)
        self.assertEqual(store.snapshot(), {"server": {"port": 90, "host": "local"}})
