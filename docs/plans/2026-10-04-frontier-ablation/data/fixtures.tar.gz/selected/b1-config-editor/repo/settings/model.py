"""Configuration storage and validation shared by readers and editors.

Configuration documents are nested dictionaries with string keys. Leaves
are JSON scalars or lists. Lists are opaque values rather than namespaces.
A Store owns its document; callers receive detached snapshots.

Example lifecycle::

    store = Store({"service": {"port": 8080}})
    draft = store.snapshot()
    draft["service"]["port"] = 9090
    store.replace(draft)

Editing the draft alone does not change the store. Replacement validates
the complete candidate before installation and advances the revision only
when the validated candidate differs from the current document.
"""
from copy import deepcopy


def validate_document(value, path=""):
    """Reject non-string dictionary keys and unsupported leaf values."""
    if isinstance(value, dict):
        for key, child in value.items():
            if not isinstance(key, str):
                raise TypeError("configuration keys must be strings")
            validate_document(child, path + "/" + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            validate_document(child, path + "/" + str(index))
    elif value is not None and not isinstance(value, (str, bool, int, float)):
        raise TypeError("unsupported configuration value at " + (path or "/"))


def clone_document(document):
    """Validate a root document and return an independent copy."""
    if not isinstance(document, dict):
        raise TypeError("configuration must be a mapping")
    validate_document(document)
    return deepcopy(document)


def lookup(document, path, default=None):
    """Look up a tuple of literal keys without interpreting dots."""
    current = document
    for key in path:
        if not isinstance(current, dict) or key not in current:
            return deepcopy(default)
        current = current[key]
    return deepcopy(current)


def flatten(document, prefix=()):
    """Yield leaf paths in document order, including empty dictionaries."""
    for key, value in document.items():
        path = prefix + (key,)
        if isinstance(value, dict) and value:
            yield from flatten(value, path)
        else:
            yield path, deepcopy(value)


class Store:
    """An in-memory configuration with monotonically increasing revisions."""

    def __init__(self, document=None):
        self._document = clone_document({} if document is None else document)
        self._revision = 0

    @property
    def revision(self):
        return self._revision

    def snapshot(self):
        return clone_document(self._document)

    def get(self, path, default=None):
        return lookup(self._document, tuple(path), default)

    def replace(self, document):
        """Replace only after validation; unchanged documents keep revision."""
        candidate = clone_document(document)
        if candidate != self._document:
            self._document = candidate
            self._revision += 1
        return self._revision

    def paths(self):
        return tuple(path for path, _ in flatten(self._document))

    def export_rows(self):
        """Provide detached path/value records for diagnostics."""
        return [{"path": path, "value": value}
                for path, value in flatten(self._document)]
