# Add editor patches

Our editor currently replaces a whole settings document. Add incremental updates for its Save action.

Add `apply_patch(store, patch)` in `settings.editor`; it returns the resulting revision and accepts only a dictionary patch, otherwise raising `TypeError("patch must be a mapping")`.

Recursively merge dictionaries, replacing a non-dictionary target with an empty namespace before merging; scalar values and lists replace existing values, and keys including dots are literal.

The exported identity marker `DELETE` removes a key at any dictionary depth, missing deletions are no-ops, and `None` remains an ordinary stored value.

Neither the patch nor its nested mutable values may be mutated or retained by the store; snapshots must also remain independent.

Validate the entire resulting document using the existing configuration rules before committing, so invalid patches leave both data and revision unchanged.

Empty patches and patches producing an equal document preserve the revision; any actual change increments it exactly once, including a patch with several changes.
