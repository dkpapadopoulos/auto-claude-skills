"""Operations used by the configuration editor.

Dictionary values are namespaces. A dotted key is nevertheless a literal
key: display formatting must never be reused as a path parser.
"""
from copy import deepcopy
from .model import Store, clone_document, flatten

# An identity marker, deliberately different from the JSON value None.
DELETE = object()


def preview_replacement(store, document):
    """Show changes without installing a candidate document."""
    before = dict(flatten(store.snapshot()))
    after = dict(flatten(clone_document(document)))
    changes = []
    for path in sorted(before.keys() | after.keys()):
        if path not in before:
            changes.append(("added", path, deepcopy(after[path])))
        elif path not in after:
            changes.append(("removed", path, deepcopy(before[path])))
        elif before[path] != after[path]:
            changes.append(("changed", path, deepcopy(after[path])))
    return changes


def overlay_defaults(defaults, overrides):
    """Return ordinary dictionary merging, without patch marker semantics."""
    result = clone_document(defaults)
    overrides = clone_document(overrides)
    for key, value in overrides.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = overlay_defaults(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def format_path(path):
    """Render literal path components unambiguously for a debug panel."""
    return "/" + "/".join(str(key).replace("~", "~0").replace("/", "~1")
                           for key in path)


def summarize(store):
    """Describe the current revision and leaf values for operators."""
    rows = []
    for row in store.export_rows():
        rows.append((format_path(row["path"]), row["value"]))
    return {"revision": store.revision, "rows": rows}


def apply_patch(store, patch):
    """Apply an editor patch and return the resulting store revision."""
    if not isinstance(patch, dict):
        raise TypeError("patch must be a mapping")
    changes = {key: value for key, value in patch.items() if value is not DELETE}
    result = overlay_defaults(store.snapshot(), changes)
    for key, value in patch.items():
        if value is DELETE:
            result.pop(key, None)
    return store.replace(result)
