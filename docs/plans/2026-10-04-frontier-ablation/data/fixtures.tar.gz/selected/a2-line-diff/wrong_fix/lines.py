"""Lossless line records for text patches.

A line is terminated by LF only. CR and Unicode separator characters
are content, as in a source-code editor configured for LF files.
"""
from dataclasses import dataclass


def split_records(text):
    """Split text into records, retaining each terminating LF if present.

    The empty string has no records. A trailing LF belongs to the last
    record and does not introduce a phantom empty record.
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    return text.splitlines(keepends=True)


def join_records(records):
    """Reconstruct text from complete, unmodified line records."""
    return "".join(records)


def content(record):
    """Return a record's content with at most one terminating LF removed."""
    return record[:-1] if record.endswith("\n") else record


def terminated(record):
    """Report whether this record ends in LF."""
    return record.endswith("\n")


@dataclass(frozen=True)
class Document:
    """Immutable original text with a lossless line-oriented view."""
    text: str

    def __post_init__(self):
        if not isinstance(self.text, str):
            raise TypeError("text must be a string")

    @property
    def records(self):
        return tuple(split_records(self.text))

    def __len__(self):
        return len(self.records)

    def line(self, index):
        """Return a zero-based line record, including its LF."""
        return self.records[index]

    def slice(self, start, stop):
        """Return text for a half-open range of line records."""
        return join_records(self.records[start:stop])

    def numbered(self, start=1):
        """Return display pairs without removing line endings."""
        return tuple(enumerate(self.records, start))

    def with_text(self, text):
        """Construct another document, leaving this snapshot untouched."""
        return Document(text)
