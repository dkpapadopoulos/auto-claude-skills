# Traceability

Trap: Keeping splitlines terminators still misclassifies non-LF characters as record boundaries.

| Hidden test | Exact TASK.md sentence |
|---|---|
| test_lf_only | `split_records(text)` splits only on LF (U+000A), retaining each LF in its record; CR, CRLF's CR, vertical tab, form feed, NEL, and Unicode line/paragraph separators are ordinary content. |
| test_empty_blank | Empty text has no records; a final LF terminates the last record without adding a phantom record, and consecutive LFs represent blank lines. |
| test_source_coordinates | `diff(old, new)` returns ascending, nonoverlapping `Edit(start, stop, before, after)` replacements in zero-based, half-open source-record coordinates; before and after contain complete records including terminators. |
| test_newline_removal | `apply(old, diff(old, new))` must reproduce new exactly, including empty text, repeated lines, mixed content and final-newline changes. |
| test_roundtrips | `apply(old, diff(old, new))` must reproduce new exactly, including empty text, repeated lines, mixed content and final-newline changes. |
| test_identity | The existing SequenceMatcher alignment with autojunk disabled is retained, and identical texts produce no edits. |
| test_stale | `apply(old, edits)` rejects stale before-records and overlapping or out-of-range edits with ValueError. |
| test_inverse | `reverse(edits)` creates a script that reconstructs the original from the patched text. |
| test_document | `Document.records`, `Document.line(index)` and `Document.slice(start, stop)` expose the same LF-only, lossless record model. |
