import unittest
from lines import split_records, Document
from diffing import diff, apply, reverse, Edit

class ContractTests(unittest.TestCase):
    def test_lf_only(self):
        for char in ["\r", "\v", "\f", "\x85", "\u2028", "\u2029"]:
            self.assertEqual(split_records("a" + char + "b\n"), ["a" + char + "b\n"])

    def test_empty_blank(self):
        self.assertEqual(split_records(""), [])
        self.assertEqual(split_records("\n\nx\n"), ["\n", "\n", "x\n"])

    def test_source_coordinates(self):
        edits = diff("a\rb\nx\n", "a\rb\ny\n")
        self.assertEqual(len(edits), 1)
        e = edits[0]
        self.assertEqual((e.start, e.stop, e.before, e.after), (1, 2, ("x\n",), ("y\n",)))

    def test_newline_removal(self):
        old, new = "x\n", "x"
        self.assertTrue(diff(old, new))
        self.assertEqual(apply(old, diff(old,new)), new)

    def test_roundtrips(self):
        for old,new in [("", "x\n"), ("x\n", ""), ("x\nx\nx", "x\ny\nx\n"), ("a\r\nb", "a\rb\n")]:
            self.assertEqual(apply(old, diff(old,new)), new)

    def test_identity(self):
        for value in ["", "x\n", "\n", "a\rb", "x\n" * 220]:
            self.assertEqual(diff(value, value), [])

    def test_stale(self):
        with self.assertRaises(ValueError):
            apply("changed\n", [Edit(0, 1, ("original\n",), ("new\n",))])
        with self.assertRaises(ValueError):
            apply("a\n", [Edit(2, 2, (), ("b\n",))])
        with self.assertRaises(ValueError):
            apply("a\n", [Edit(0,1,("a\n",),()), Edit(0,1,("a\n",),())])

    def test_inverse(self):
        old, new = "a\nb\nc\n", "intro\na\nc\nend"
        edits = diff(old,new)
        self.assertEqual(apply(new, reverse(edits)), old)

    def test_document(self):
        doc = Document("a\vb\nx\n")
        self.assertEqual(doc.records, ("a\vb\n", "x\n"))
        self.assertEqual(doc.line(1), "x\n")
        self.assertEqual(doc.slice(0,1), "a\vb\n")

if __name__ == "__main__":
    unittest.main()
