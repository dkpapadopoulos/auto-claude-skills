import unittest
from lines import split_records, Document
from diffing import diff, apply, reverse, Edit

class ContractTests(unittest.TestCase):
    def test_reported_newline(self):
        edits = diff("hello", "hello\n")
        self.assertTrue(edits)
        self.assertEqual(apply("hello", edits), "hello\n")

    def test_simple_replace(self):
        self.assertEqual(apply("a\nb\n", diff("a\nb\n", "a\nc\n")), "a\nc\n")

if __name__ == "__main__":
    unittest.main()
