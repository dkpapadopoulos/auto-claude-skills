"""Stable line-based edit scripts and guarded patch application."""
from dataclasses import dataclass
from difflib import SequenceMatcher
from lines import split_records, join_records


@dataclass(frozen=True)
class Edit:
    """One source-coordinate replacement of the half-open range [start, stop)."""
    start: int
    stop: int
    before: tuple
    after: tuple

    def __post_init__(self):
        object.__setattr__(self, "before", tuple(self.before))
        object.__setattr__(self, "after", tuple(self.after))
        if self.start < 0 or self.stop < self.start:
            raise ValueError("invalid edit range")
        if self.stop - self.start != len(self.before):
            raise ValueError("edit range does not match records")

    @property
    def kind(self):
        """Classify the edit without inspecting text contents."""
        if self.start == self.stop:
            return "insert"
        if not self.after:
            return "delete"
        return "replace"

    @property
    def delta(self):
        """Number of records added minus the number removed."""
        return len(self.after) - len(self.before)


def diff(old, new):
    """Return ascending nonoverlapping edits from old text to new text.

    Coordinates refer to old records. Equality compares complete records,
    including line terminators. Repeated records use SequenceMatcher with
    autojunk disabled so frequency never makes a line ineligible to match.
    """
    before = split_records(old)
    after = split_records(new)
    matcher = SequenceMatcher(None, before, after, autojunk=False)
    result = []
    for tag, i, j, k, l in matcher.get_opcodes():
        if tag != "equal":
            result.append(Edit(i, j, tuple(before[i:j]), tuple(after[k:l])))
    return result


def apply(old, edits):
    """Apply source-coordinate edits, validating ordering and expected text.

    A stale before-record or an overlapping/out-of-range edit raises
    ValueError. The supplied edit iterable is never modified.
    """
    source = split_records(old)
    result = []
    cursor = 0
    for edit in edits:
        if edit.start < cursor or edit.stop > len(source):
            raise ValueError("invalid patch order or range")
        if tuple(source[edit.start:edit.stop]) != edit.before:
            raise ValueError("patch does not match source")
        result.extend(source[cursor:edit.start])
        result.extend(edit.after)
        cursor = edit.stop
    result.extend(source[cursor:])
    return join_records(result)


def reverse(edits):
    """Return an inverse script expressed in the resulting text's coordinates."""
    offset = 0
    result = []
    for edit in edits:
        start = edit.start + offset
        result.append(Edit(start, start + len(edit.after), edit.after, edit.before))
        offset += edit.delta
    return result


def summary(edits):
    """Return inserted and removed record counts for a script."""
    inserted = 0
    removed = 0
    for edit in edits:
        inserted += len(edit.after)
        removed += len(edit.before)
    return {"inserted": inserted, "removed": removed}


def changed(old, new):
    """Report whether any complete record differs."""
    return bool(diff(old, new))
