# Diff ignores adding a final newline
`diff("hello", "hello\n")` currently returns no edits, so saving the patch loses the newline change.
Fix the line representation used by the existing diff and patch APIs.

`split_records(text)` splits only on LF (U+000A), retaining each LF in its record; CR, CRLF's CR, vertical tab, form feed, NEL, and Unicode line/paragraph separators are ordinary content.
Empty text has no records; a final LF terminates the last record without adding a phantom record, and consecutive LFs represent blank lines.
`diff(old, new)` returns ascending, nonoverlapping `Edit(start, stop, before, after)` replacements in zero-based, half-open source-record coordinates; before and after contain complete records including terminators.
The existing SequenceMatcher alignment with autojunk disabled is retained, and identical texts produce no edits.
`apply(old, diff(old, new))` must reproduce new exactly, including empty text, repeated lines, mixed content and final-newline changes.
`apply(old, edits)` rejects stale before-records and overlapping or out-of-range edits with ValueError.
`reverse(edits)` creates a script that reconstructs the original from the patched text.
`Document.records`, `Document.line(index)` and `Document.slice(start, stop)` expose the same LF-only, lossless record model.
