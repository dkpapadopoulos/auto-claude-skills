import unittest
from datetime import date
from calendar_math import dates, DateRange
from recurrence import Rule, expand, expand_many

class SmokeTests(unittest.TestCase):

    def test_daily(self):
        r = Rule(date(2024, 1, 1), 'daily', 2)
        self.assertEqual(expand(r, date(2024, 1, 1), date(2024, 1, 3)), [date(2024, 1, 1), date(2024, 1, 2)])

    def test_half_open(self):
        self.assertEqual(dates(date(2024, 1, 1), date(2024, 1, 2)), [date(2024, 1, 1)])
