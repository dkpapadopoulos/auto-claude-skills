# Release review

This module is about to be released. Review it against the contract below and its docstrings, and fix every defect while preserving the public API.

Public API: `calendar_math.dates(start, end)`, `DateRange(start, end)` with contains(day), days and intersection(other), and `recurrence.Rule(anchor, frequency, count, interval=1)`, `expand(rule, start, end, *, excluded=())`, and `expand_many(rules, start, end, *, excluded=())`.

All inputs are explicit datetime.date objects (not datetime); date ranges are half-open [start, end), equal endpoints are empty, reversed ranges raise ValueError, and dates returns a list of every included date.

Rule frequency is "daily" or "monthly", count is a nonnegative integer candidate budget including the anchor, and interval is a positive integer; invalid frequency, count, or interval, including booleans, raises ValueError.

Daily candidate i is anchor plus i * interval days; monthly candidate i shifts the original anchor by i * interval months and clamps its original day to the target month end, without carrying clamping into later months.

Expand returns ascending dates from the first count candidate positions intersected with [start, end), minus excluded dates; excluded or out-of-range positions still consume count, and a zero count returns an empty list.

Excluded may be a one-shot iterable and is never mutated; expand_many returns the sorted deduplicated union of each rule expansion using the same exclusions for every rule and never mutates the supplied rules.

DateRange.contains follows the same half-open bounds, days is the number of included dates, and intersection returns a DateRange for nonempty overlap or None for empty, touching, or disjoint ranges.

Inputs and candidate dates in this release are within years 1901–2099; no current date or time is consulted.

Run the existing checks with `python3 -m unittest discover -s tests -v`.
