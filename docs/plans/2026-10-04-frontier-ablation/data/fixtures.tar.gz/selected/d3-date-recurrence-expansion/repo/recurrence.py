"""Bounded recurrence expansion for reports and booking previews.

A rule describes candidate positions before any query clipping or explicit
exclusions. This keeps repeated queries consistent across adjacent ranges.
Only daily and monthly frequencies are supported by this release.
"""
from dataclasses import dataclass
from datetime import timedelta
from calendar_math import (
    DateRange, require_date, require_nonnegative, require_positive, shift_month,
)


@dataclass(frozen=True)
class Rule:
    """A finite recurrence anchored to a date.

    count is the number of candidate positions, including the anchor.
    interval is measured in days or calendar months according to frequency.
    """

    anchor: object
    frequency: str
    count: int
    interval: int = 1

    def __post_init__(self):
        require_date(self.anchor)
        if self.frequency not in ('daily', 'monthly'):
            raise ValueError('unsupported frequency')
        require_nonnegative(self.count, 'count')
        normalized = require_positive(self.interval, 'interval')
        object.__setattr__(self, 'interval', normalized)

    def candidate(self, index):
        """Return candidate index relative to the original anchor.

        Index zero is the anchor even when count is zero; this arithmetic
        helper is independent of the rule's finite expansion limit.
        """
        require_nonnegative(index, 'index')
        if self.frequency == 'daily':
            return self.anchor + timedelta(days=index * self.interval)
        return shift_month(self.anchor, index * self.interval)


def next_date(rule, previous):
    """Advance a calendar cursor by one rule interval."""
    if rule.frequency == 'daily':
        return previous + timedelta(days=rule.interval)
    return shift_month(previous, rule.interval)


def expand(rule, start, end, *, excluded=()):
    """Return sorted occurrence dates in [start, end).

    Excluded dates remove occurrences without extending the candidate
    budget. The exclusion iterable is consumed once and never mutated.
    """
    span = DateRange(start, end)
    blocked = {require_date(day) for day in excluded}
    result = []
    candidate = rule.anchor
    position = 0
    emitted = 0
    while emitted < rule.count and candidate < span.end:
        if span.contains(candidate) and candidate not in blocked:
            result.append(candidate)
            emitted += 1
        position += 1
        candidate = next_date(rule, candidate)
    return result


def expand_many(rules, start, end, *, excluded=()):
    """Union occurrence dates from multiple rules, sorted and deduplicated.

    Shared exclusions are materialized once so generator inputs work for
    every rule. This operation never reorders the caller's rule collection.
    """
    blocked = tuple(excluded)
    DateRange(start, end)
    occurrences = set()
    for rule in rules:
        occurrences.update(expand(rule, start, end, excluded=blocked))
    return sorted(occurrences)
