import unittest
from datetime import date
from calendar_math import dates, DateRange
from recurrence import Rule, expand, expand_many

class ContractTests(unittest.TestCase):

    def test_month_anchor(self):
        r = Rule(date(2024, 1, 31), 'monthly', 4)
        self.assertEqual(expand(r, date(2024, 1, 1), date(2024, 5, 1)), [date(2024, 1, 31), date(2024, 2, 29), date(2024, 3, 31), date(2024, 4, 30)])

    def test_range_end(self):
        self.assertEqual(dates(date(2024, 2, 28), date(2024, 3, 1)), [date(2024, 2, 28), date(2024, 2, 29)])
        self.assertEqual(dates(date(2024, 1, 1), date(2024, 1, 1)), [])

    def test_excluded_budget(self):
        r = Rule(date(2024, 1, 1), 'daily', 3)
        blocked = [date(2024, 1, 2)]
        self.assertEqual(expand(r, date(2024, 1, 1), date(2024, 1, 8), excluded=blocked), [date(2024, 1, 1), date(2024, 1, 3)])
        self.assertEqual(blocked, [date(2024, 1, 2)])

    def test_clipped_budget(self):
        r = Rule(date(2024, 1, 1), 'daily', 3)
        self.assertEqual(expand(r, date(2024, 1, 3), date(2024, 1, 9)), [date(2024, 1, 3)])
        self.assertEqual(expand(r, date(2024, 1, 4), date(2024, 1, 9)), [])

    def test_zero_interval(self):
        with self.assertRaises(ValueError):
            Rule(date(2024, 1, 1), 'daily', 3, interval=0)

    def test_daily_stride(self):
        r = Rule(date(2024, 2, 27), 'daily', 4, interval=2)
        self.assertEqual(expand(r, date(2024, 2, 27), date(2024, 3, 4)), [date(2024, 2, 27), date(2024, 2, 29), date(2024, 3, 2)])

    def test_invalid_rules(self):
        for frequency, count, interval in [('weekly', 1, 1), ('daily', -1, 1), ('daily', True, 1), ('daily', 1, True), ('daily', 1, -2)]:
            with self.subTest(values=(frequency, count, interval)):
                with self.assertRaises(ValueError):
                    Rule(date(2024, 1, 1), frequency, count, interval)

    def test_range_algebra(self):
        a = DateRange(date(2024, 1, 1), date(2024, 1, 3))
        self.assertEqual(a.days, 2)
        self.assertTrue(a.contains(date(2024, 1, 1)))
        self.assertFalse(a.contains(date(2024, 1, 3)))
        self.assertIsNone(a.intersection(DateRange(date(2024, 1, 3), date(2024, 1, 5))))
        self.assertEqual(a.intersection(DateRange(date(2024, 1, 2), date(2024, 1, 5))), DateRange(date(2024, 1, 2), date(2024, 1, 3)))
        with self.assertRaises(ValueError):
            dates(date(2024, 1, 2), date(2024, 1, 1))

    def test_union_generator(self):
        rules = [Rule(date(2024, 1, 1), 'daily', 2), Rule(date(2024, 1, 1), 'daily', 3)]
        self.assertEqual(expand_many(rules, date(2024, 1, 1), date(2024, 1, 4), excluded=iter([date(2024, 1, 2)])), [date(2024, 1, 1), date(2024, 1, 3)])
        self.assertEqual(len(rules), 2)

    def test_zero_and_year_crossing(self):
        self.assertEqual(expand(Rule(date(2024, 1, 1), 'daily', 0), date(2024, 1, 1), date(2024, 2, 1)), [])
        r = Rule(date(2023, 11, 30), 'monthly', 3, interval=2)
        self.assertEqual(expand(r, date(2023, 11, 1), date(2024, 4, 1)), [date(2023, 11, 30), date(2024, 1, 30), date(2024, 3, 30)])
