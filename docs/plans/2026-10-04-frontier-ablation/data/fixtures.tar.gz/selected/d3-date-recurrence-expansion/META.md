# Contract traceability

| Test | Exact contract sentence(s) in TASK.md |
|---|---|
| `test_month_anchor` | Daily candidate i is anchor plus i * interval days; monthly candidate i shifts the original anchor by i * interval months and clamps its original day to the target month end, without carrying clamping into later months. Expand returns ascending dates from the first count candidate positions intersected with [start, end), minus excluded dates; excluded or out-of-range positions still consume count, and a zero count returns an empty list. |
| `test_range_end` | All inputs are explicit datetime.date objects (not datetime); date ranges are half-open [start, end), equal endpoints are empty, reversed ranges raise ValueError, and dates returns a list of every included date. |
| `test_excluded_budget` | Expand returns ascending dates from the first count candidate positions intersected with [start, end), minus excluded dates; excluded or out-of-range positions still consume count, and a zero count returns an empty list. Excluded may be a one-shot iterable and is never mutated; expand_many returns the sorted deduplicated union of each rule expansion using the same exclusions for every rule and never mutates the supplied rules. |
| `test_clipped_budget` | Expand returns ascending dates from the first count candidate positions intersected with [start, end), minus excluded dates; excluded or out-of-range positions still consume count, and a zero count returns an empty list. |
| `test_zero_interval` | Rule frequency is "daily" or "monthly", count is a nonnegative integer candidate budget including the anchor, and interval is a positive integer; invalid frequency, count, or interval, including booleans, raises ValueError. |
| `test_daily_stride` | Daily candidate i is anchor plus i * interval days; monthly candidate i shifts the original anchor by i * interval months and clamps its original day to the target month end, without carrying clamping into later months. Expand returns ascending dates from the first count candidate positions intersected with [start, end), minus excluded dates; excluded or out-of-range positions still consume count, and a zero count returns an empty list. |
| `test_invalid_rules` | Rule frequency is "daily" or "monthly", count is a nonnegative integer candidate budget including the anchor, and interval is a positive integer; invalid frequency, count, or interval, including booleans, raises ValueError. |
| `test_range_algebra` | All inputs are explicit datetime.date objects (not datetime); date ranges are half-open [start, end), equal endpoints are empty, reversed ranges raise ValueError, and dates returns a list of every included date. DateRange.contains follows the same half-open bounds, days is the number of included dates, and intersection returns a DateRange for nonempty overlap or None for empty, touching, or disjoint ranges. |
| `test_union_generator` | Expand returns ascending dates from the first count candidate positions intersected with [start, end), minus excluded dates; excluded or out-of-range positions still consume count, and a zero count returns an empty list. Excluded may be a one-shot iterable and is never mutated; expand_many returns the sorted deduplicated union of each rule expansion using the same exclusions for every rule and never mutates the supplied rules. |
| `test_zero_and_year_crossing` | Daily candidate i is anchor plus i * interval days; monthly candidate i shifts the original anchor by i * interval months and clamps its original day to the target month end, without carrying clamping into later months. Expand returns ascending dates from the first count candidate positions intersected with [start, end), minus excluded dates; excluded or out-of-range positions still consume count, and a zero count returns an empty list. |

Trap: Fixing bounds and counts still lets month-end clamping drift permanently.

Four independent defects (in overlay patch order):
- Monthly cursor arithmetic loses the original day after clamping.
- Date enumeration includes the exclusive end.
- Count is measured after filtering instead of before clipping and exclusions.
- Zero interval silently becomes one instead of raising ValueError.
