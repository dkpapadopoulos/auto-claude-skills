"""Calendar arithmetic on explicit datetime.date values.

There is no dependency on today's date. All intervals use a half-open
[start, end) convention, matching Python slicing and downstream reporting.
"""
from calendar import monthrange
from dataclasses import dataclass
from datetime import date, timedelta


DAY = timedelta(days=1)


def require_date(value):
    """Accept dates, rejecting datetime objects and implicit string parsing."""
    if type(value) is not date:
        raise ValueError('expected date')
    return value


def require_nonnegative(value, name):
    """Counts must be nonnegative integers, not boolean flags."""
    if type(value) is not int or value < 0:
        raise ValueError(name + ' must be a nonnegative integer')
    return value


def require_positive(value, name):
    """Intervals must be positive integer calendar units."""
    if type(value) is not int or value <= 0:
        raise ValueError(name + ' must be positive')
    return value


@dataclass(frozen=True)
class DateRange:
    """A half-open date interval; equal endpoints represent an empty range."""

    start: date
    end: date

    def __post_init__(self):
        require_date(self.start)
        require_date(self.end)
        if self.end < self.start:
            raise ValueError('reversed date range')

    def contains(self, day):
        """Whether a date is inside the half-open interval."""
        require_date(day)
        return self.start <= day < self.end

    @property
    def days(self):
        """Number of dates represented by this interval."""
        return (self.end - self.start).days

    def intersection(self, other):
        """Return an overlap, or None for empty or disjoint intervals."""
        start = max(self.start, other.start)
        end = min(self.end, other.end)
        if start >= end:
            return None
        return DateRange(start, end)


def dates(start, end):
    """Materialize all dates in [start, end), validating reversed ranges."""
    span = DateRange(start, end)
    return [span.start + index * DAY for index in range(span.days)]


def shift_month(anchor, offset):
    """Shift relative to the supplied anchor, clamping its day if needed.

    Callers generating recurrences should retain the original anchor.
    February clamping must not permanently change a January 31 schedule.
    """
    absolute = anchor.year * 12 + anchor.month - 1 + offset
    year, zero_month = divmod(absolute, 12)
    month = zero_month + 1
    day = min(anchor.day, monthrange(year, month)[1])
    return date(year, month, day)
