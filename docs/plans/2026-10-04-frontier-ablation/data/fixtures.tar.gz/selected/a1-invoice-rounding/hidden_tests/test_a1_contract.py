import unittest
from decimal import Decimal
from money import Currency, USD, JPY, KWD
from ledger import Line, Invoice, Ledger

class ContractTests(unittest.TestCase):
    def test_positive_ties(self):
        for value, expected in [("1.005", "1.01"), ("2.025", "2.03")]:
            self.assertEqual(USD.round(value), Decimal(expected))

    def test_negative_ties(self):
        self.assertEqual(USD.round("-1.005"), Decimal("-1.01"))

    def test_nearest(self):
        for value, expected in [("-1.004", "-1.00"), ("-1.006", "-1.01"), ("1.004", "1.00"), ("1.006", "1.01")]:
            self.assertEqual(USD.round(value), Decimal(expected))

    def test_precision(self):
        self.assertEqual(JPY.round("-2.5"), Decimal("-3"))
        self.assertEqual(KWD.round("0.0005"), Decimal("0.001"))
        self.assertEqual(Currency("TEST",4).round("0.00005"), Decimal("0.0001"))

    def test_quantity(self):
        self.assertEqual(Line("bulk", "0.335", 3).posted_total(), Decimal("1.01"))

    def test_line_boundary(self):
        self.assertEqual(Invoice("two", [Line("a", "0.005"), Line("b", "0.005")]).total, Decimal("0.02"))
        self.assertEqual(Invoice("empty", []).total, 0)

    def test_credit(self):
        invoice = Invoice("sale", [Line("a", "2.005"), Line("b", "0.335", 3)])
        self.assertEqual(invoice.total + invoice.credit("refund").total, 0)

    def test_ledger(self):
        book = Ledger()
        i = Invoice("sale", [Line("a", "1.005")])
        self.assertEqual(book.post(i), Decimal("1.01"))
        book.post(i)
        self.assertEqual(book.balance, Decimal("1.01"))

    def test_inputs(self):
        self.assertEqual(USD.round(Decimal("3.005")), Decimal("3.01"))
        self.assertEqual(USD.round(3), 3)
        for value in [1.1, True]:
            with self.assertRaises(TypeError): USD.round(value)
        for value in ["NaN", "Infinity"]:
            with self.assertRaises(ValueError): USD.round(value)

if __name__ == "__main__":
    unittest.main()
