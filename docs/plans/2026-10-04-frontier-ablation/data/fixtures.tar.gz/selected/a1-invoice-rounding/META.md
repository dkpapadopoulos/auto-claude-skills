# Traceability

Trap: Adding half a cent before truncation mishandles signed credit amounts.

| Hidden test | Exact TASK.md sentence |
|---|---|
| test_positive_ties | `Currency.round(amount)` rounds to the nearest minor unit, with exact halfway values rounded away from zero for both charges and credits. |
| test_negative_ties | `Currency.round(amount)` rounds to the nearest minor unit, with exact halfway values rounded away from zero for both charges and credits. |
| test_nearest | Non-halfway values round to the nearest minor unit, without a systematic upward bias. |
| test_precision | Currency precision is configurable from zero to four decimal places, including JPY (zero) and KWD (three). |
| test_quantity | `Line(description, unit_price, quantity=Decimal(1))` multiplies exact price by signed quantity before rounding. |
| test_line_boundary | `Invoice(number, lines, currency=USD).total` sums individually rounded line totals, and an empty invoice totals zero. |
| test_credit | `Invoice.credit(number)` reverses every line, so a credit and its original must sum to zero. |
| test_ledger | `Ledger.post(invoice)` returns the posted total; identical reposting is idempotent, and `balance` sums posted invoice totals. |
| test_inputs | `Currency.round` accepts finite Decimal, integer and decimal-string amounts; floats and booleans raise TypeError, and nonfinite values raise ValueError. |
