"""Invoice posting and small in-memory account statements.

Credit lines have negative quantities. Posting happens once per line;
there is no invoice-wide rounding adjustment.
"""
from dataclasses import dataclass
from decimal import Decimal
from money import USD, decimal_amount, same_currency, sum_posted


@dataclass(frozen=True)
class Line:
    """One invoice line with an exact price and signed quantity."""
    description: str
    unit_price: Decimal
    quantity: Decimal = Decimal(1)

    def __post_init__(self):
        object.__setattr__(self, "unit_price", decimal_amount(self.unit_price))
        object.__setattr__(self, "quantity", decimal_amount(self.quantity))

    @property
    def exact_total(self):
        """Multiply before performing any currency rounding."""
        return self.unit_price * self.quantity

    def posted_total(self, currency=USD):
        """Return this line's independently rounded amount."""
        return currency.round(self.exact_total)

    def credit(self):
        """Build a reversal without mutating the original line."""
        return Line(self.description, self.unit_price, -self.quantity)


@dataclass(frozen=True)
class Invoice:
    """An immutable snapshot of lines in a single currency."""
    number: str
    lines: tuple
    currency: object = USD

    def __post_init__(self):
        object.__setattr__(self, "lines", tuple(self.lines))
        if not self.number:
            raise ValueError("invoice number is required")

    @property
    def total(self):
        """Sum posted line amounts; empty invoices total zero."""
        return sum_posted((line.exact_total for line in self.lines), self.currency)

    def credit(self, number):
        """Return an invoice that reverses every line."""
        return Invoice(number, tuple(line.credit() for line in self.lines), self.currency)

    def rows(self):
        """Yield descriptions and formatted posted amounts in input order."""
        for line in self.lines:
            yield line.description, self.currency.format(line.exact_total)


class Ledger:
    """Append-only invoice ledger with idempotent identical reposting."""

    def __init__(self, currency=USD):
        self.currency = currency
        self._invoices = {}

    def post(self, invoice):
        """Post an invoice; conflicting reuse of its number is an error."""
        same_currency(self.currency, invoice.currency)
        previous = self._invoices.get(invoice.number)
        if previous is not None and previous != invoice:
            raise ValueError("invoice number already used")
        self._invoices[invoice.number] = invoice
        return invoice.total

    @property
    def balance(self):
        """Sum the posted invoices without rounding a second time."""
        return sum((item.total for item in self._invoices.values()), Decimal(0))

    def statement(self):
        """Return a detached list of invoice numbers and posted totals."""
        return [(item.number, item.total) for item in self._invoices.values()]

    def get(self, number):
        """Look up an immutable invoice by number, raising KeyError if absent."""
        return self._invoices[number]

    def __len__(self):
        return len(self._invoices)
