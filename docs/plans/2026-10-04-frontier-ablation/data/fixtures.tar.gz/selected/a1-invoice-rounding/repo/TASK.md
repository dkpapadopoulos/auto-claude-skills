# Half-cent invoice lines post inconsistently
An invoice with a single price of "1.005" USD currently posts 1.00; it should post 1.01.
Please correct currency rounding while preserving the invoice and ledger APIs.

`Currency.round(amount)` rounds to the nearest minor unit, with exact halfway values rounded away from zero for both charges and credits.
Non-halfway values round to the nearest minor unit, without a systematic upward bias.
Currency precision is configurable from zero to four decimal places, including JPY (zero) and KWD (three).
`Line(description, unit_price, quantity=Decimal(1))` multiplies exact price by signed quantity before rounding.
`Invoice(number, lines, currency=USD).total` sums individually rounded line totals, and an empty invoice totals zero.
`Invoice.credit(number)` reverses every line, so a credit and its original must sum to zero.
`Ledger.post(invoice)` returns the posted total; identical reposting is idempotent, and `balance` sums posted invoice totals.
`Currency.round` accepts finite Decimal, integer and decimal-string amounts; floats and booleans raise TypeError, and nonfinite values raise ValueError.
No behaviour change is requested for invoice numbering, statement ordering or currency mismatch checks.
