import unittest
from decimal import Decimal
from money import Currency, USD, JPY, KWD
from ledger import Line, Invoice, Ledger

class ContractTests(unittest.TestCase):
    def test_reported_half_cent(self):
        self.assertEqual(Invoice("one", [Line("part", "1.005")]).total, Decimal("1.01"))

    def test_ordinary(self):
        self.assertEqual(USD.round("2.341"), Decimal("2.34"))

if __name__ == "__main__":
    unittest.main()
