"""Decimal money policy shared by invoice and ledger calculations.

Amounts may arrive as strings, integers or Decimals. Binary floating-point
inputs are deliberately excluded from the accounting boundary.
"""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, ROUND_DOWN


def decimal_amount(value):
    """Return a finite Decimal, rejecting float and bool inputs."""
    if isinstance(value, (float, bool)):
        raise TypeError("amount must be decimal-compatible")
    try:
        result = Decimal(value)
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError("invalid amount") from exc
    if not result.is_finite():
        raise ValueError("amount must be finite")
    return result


@dataclass(frozen=True)
class Currency:
    """A currency code and number of minor-unit decimal places."""
    code: str
    places: int = 2

    def __post_init__(self):
        if not self.code or not self.code.isalpha():
            raise ValueError("invalid currency code")
        if not isinstance(self.places, int) or not 0 <= self.places <= 4:
            raise ValueError("invalid currency precision")

    @property
    def quantum(self):
        """The smallest posted unit for this currency."""
        return Decimal(1).scaleb(-self.places)

    def round(self, amount):
        """Round to nearest minor unit, with exact ties away from zero."""
        value = decimal_amount(amount)
        return value.quantize(self.quantum, rounding=ROUND_HALF_UP)

    def format(self, amount):
        """Render a posted amount followed by its currency code."""
        posted = self.round(amount)
        return f"{posted:.{self.places}f} {self.code}"


USD = Currency("USD")
JPY = Currency("JPY", 0)
KWD = Currency("KWD", 3)


def same_currency(left, right):
    """Raise when two monetary containers use different currency policies."""
    if left != right:
        raise ValueError("currency mismatch")


def sum_posted(amounts, currency=USD):
    """Round every supplied amount separately, then sum the posted values."""
    return sum((currency.round(amount) for amount in amounts), Decimal(0))
