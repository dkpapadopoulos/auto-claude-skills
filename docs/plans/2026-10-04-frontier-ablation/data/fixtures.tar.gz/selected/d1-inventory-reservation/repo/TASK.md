# Release review

This module is about to be released. Review it against the contract below and its docstrings, and fix every defect while preserving the public API.

Public API: `contracts.Line(sku, quantity)` and `inventory.Inventory(stock)`; methods are `reserve(order_id, lines)`, `cancel(order_id)`, `snapshot()`, `receipt(order_id)`, `available(sku)`, `active_orders()`, `restock(sku, quantity)`, and `total_available()`.

Stock is a mapping of nonempty string SKUs to nonnegative integers; quantities in Line and restock must be positive integers, booleans are invalid, and invalid input raises ValueError before any state changes.

Construction copies the stock mapping, and snapshot returns a fresh mapping; neither requests nor caller-owned mappings are modified.

Reserve consumes an iterable of Line objects, combines duplicate SKUs, sorts receipt lines by SKU, and permits reserving exactly all available units; missing SKUs have zero available units.

A shortage raises contracts.InsufficientStock and leaves all stock and orders unchanged, even if earlier lines could have been fulfilled.

Repeating an active order id with the same consolidated quantities returns an equal Receipt without deducting again; different quantities raise contracts.OrderConflict without changing state.

Cancel restores the reserved quantities exactly once and returns True, removes the active receipt, and returns False for an unknown or already cancelled order; cancelled ids may be reused.

Empty baskets are valid active reservations; Receipt exposes order_id, a tuple of Line objects as lines, units as the total quantity, and quantities() as a fresh dictionary.

Available returns zero for an unknown SKU; active_orders returns sorted ids as a tuple, restock returns the new available quantity, and total_available sums available units.

Run the existing checks with `python3 -m unittest discover -s tests -v`.
