"""Value objects and validation for the warehouse reservation service.

Stock is measured in indivisible units. A reservation belongs to one order;
repeated requests are compared after duplicate SKU lines are consolidated.
The service deliberately separates request normalization from stock changes.
"""
from dataclasses import dataclass
from collections.abc import Mapping


@dataclass(frozen=True)
class Line:
    """One positive quantity requested for a nonempty SKU."""

    sku: str
    quantity: int


@dataclass(frozen=True)
class Receipt:
    """Stable result of a successful reservation.

    Lines are consolidated and sorted by SKU. The tuple prevents callers
    from changing a saved order through the returned receipt.
    """

    order_id: str
    lines: tuple[Line, ...]

    @property
    def units(self):
        """Total individual units reserved by this order."""
        return sum(line.quantity for line in self.lines)

    def quantities(self):
        """Return a fresh dictionary suitable for display or comparison."""
        return {line.sku: line.quantity for line in self.lines}


class InsufficientStock(ValueError):
    """Raised when a request cannot be satisfied in its entirety."""


class OrderConflict(ValueError):
    """An existing order id was reused for a different basket."""


def validate_sku(sku):
    """SKU identifiers are nonempty strings; whitespace is significant."""
    if not isinstance(sku, str) or not sku:
        raise ValueError('invalid SKU')
    return sku


def validate_units(value, *, allow_zero=False):
    """Validate whole units, explicitly excluding booleans."""
    if type(value) is not int:
        raise ValueError('units must be integers')
    minimum = 0 if allow_zero else 1
    if value < minimum:
        raise ValueError('invalid units')
    return value


def normalize(lines):
    """Consume Line objects once and produce sorted consolidated lines."""
    counts = {}
    for line in lines:
        if not isinstance(line, Line):
            raise ValueError('expected Line')
        sku = validate_sku(line.sku)
        quantity = validate_units(line.quantity)
        counts[sku] = counts.get(sku, 0) + quantity
    return tuple(Line(sku, counts[sku]) for sku in sorted(counts))


def validate_stock(stock):
    """Validate the entire initial mapping before a service is created."""
    if not isinstance(stock, Mapping):
        raise ValueError('stock must be a mapping')
    for sku, quantity in stock.items():
        validate_sku(sku)
        validate_units(quantity, allow_zero=True)


def validate_order_id(order_id):
    """Order ids use the same nonempty string convention as SKUs."""
    if not isinstance(order_id, str) or not order_id:
        raise ValueError('invalid order id')
    return order_id
