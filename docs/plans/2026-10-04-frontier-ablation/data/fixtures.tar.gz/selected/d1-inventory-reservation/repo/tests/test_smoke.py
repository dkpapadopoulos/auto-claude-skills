import unittest
from inventory import Inventory
from contracts import Line, InsufficientStock, OrderConflict

class SmokeTests(unittest.TestCase):

    def test_basic(self):
        s = Inventory({'a': 5})
        self.assertEqual(s.reserve('o', [Line('a', 2)]).units, 2)
        self.assertEqual(s.available('a'), 3)

    def test_sell_out(self):
        s = Inventory({'a': 2})
        s.reserve('o', [Line('a', 2)])
        self.assertEqual(s.available('a'), 0)
