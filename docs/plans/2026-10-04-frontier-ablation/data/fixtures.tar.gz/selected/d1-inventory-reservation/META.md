# Contract traceability

| Test | Exact contract sentence(s) in TASK.md |
|---|---|
| `test_atomic_shortage` | A shortage raises contracts.InsufficientStock and leaves all stock and orders unchanged, even if earlier lines could have been fulfilled. Available returns zero for an unknown SKU; active_orders returns sorted ids as a tuple, restock returns the new available quantity, and total_available sums available units. |
| `test_exact_capacity` | Reserve consumes an iterable of Line objects, combines duplicate SKUs, sorts receipt lines by SKU, and permits reserving exactly all available units; missing SKUs have zero available units. Empty baskets are valid active reservations; Receipt exposes order_id, a tuple of Line objects as lines, units as the total quantity, and quantities() as a fresh dictionary. |
| `test_ownership` | Construction copies the stock mapping, and snapshot returns a fresh mapping; neither requests nor caller-owned mappings are modified. |
| `test_cancel_once` | Cancel restores the reserved quantities exactly once and returns True, removes the active receipt, and returns False for an unknown or already cancelled order; cancelled ids may be reused. |
| `test_idempotent_consolidation` | Construction copies the stock mapping, and snapshot returns a fresh mapping; neither requests nor caller-owned mappings are modified. Reserve consumes an iterable of Line objects, combines duplicate SKUs, sorts receipt lines by SKU, and permits reserving exactly all available units; missing SKUs have zero available units. Repeating an active order id with the same consolidated quantities returns an equal Receipt without deducting again; different quantities raise contracts.OrderConflict without changing state. |
| `test_conflict` | Repeating an active order id with the same consolidated quantities returns an equal Receipt without deducting again; different quantities raise contracts.OrderConflict without changing state. |
| `test_invalid_basket` | Stock is a mapping of nonempty string SKUs to nonnegative integers; quantities in Line and restock must be positive integers, booleans are invalid, and invalid input raises ValueError before any state changes. |
| `test_empty_basket` | Empty baskets are valid active reservations; Receipt exposes order_id, a tuple of Line objects as lines, units as the total quantity, and quantities() as a fresh dictionary. Available returns zero for an unknown SKU; active_orders returns sorted ids as a tuple, restock returns the new available quantity, and total_available sums available units. |
| `test_missing_sku` | Reserve consumes an iterable of Line objects, combines duplicate SKUs, sorts receipt lines by SKU, and permits reserving exactly all available units; missing SKUs have zero available units. A shortage raises contracts.InsufficientStock and leaves all stock and orders unchanged, even if earlier lines could have been fulfilled. Available returns zero for an unknown SKU; active_orders returns sorted ids as a tuple, restock returns the new available quantity, and total_available sums available units. |
| `test_restock_and_receipt_copy` | Empty baskets are valid active reservations; Receipt exposes order_id, a tuple of Line objects as lines, units as the total quantity, and quantities() as a fresh dictionary. Available returns zero for an unknown SKU; active_orders returns sorted ids as a tuple, restock returns the new available quantity, and total_available sums available units. |

Trap: Fixing individual operations leaves partial stock deductions after a late shortage.

Four independent defects (in overlay patch order):
- A late shortage leaks earlier stock deductions (transaction atomicity).
- Exact-capacity reservations incorrectly report shortage.
- Inventory aliases the caller stock mapping.
- Cancellation keeps the ledger entry and restores stock repeatedly.
