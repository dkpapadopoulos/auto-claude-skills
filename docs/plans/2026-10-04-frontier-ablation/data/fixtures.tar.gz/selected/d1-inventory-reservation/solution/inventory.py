"""In-memory reservations for a single warehouse.

Instances own their state. There is no persistence, background expiry, or
wall clock. Cancellation makes an order id available for reuse.
"""
from contracts import (
    Receipt, InsufficientStock, OrderConflict, normalize,
    validate_stock, validate_order_id, validate_sku, validate_units,
)


class Inventory:
    """Reserve whole baskets and expose detached stock snapshots.

    A rejected basket must leave both stock and the order ledger intact.
    This is a single-threaded service; callers serialize access themselves.
    """

    def __init__(self, stock):
        validate_stock(stock)
        self._stock = dict(stock)
        self._orders = {}

    def snapshot(self):
        """Return current available units as an independent dictionary."""
        return dict(self._stock)

    def available(self, sku):
        """Unknown SKUs have zero units available."""
        validate_sku(sku)
        return self._stock.get(sku, 0)

    def reserve(self, order_id, lines):
        """Reserve all normalized lines, or fail without changing state.

        Repeating the same normalized basket for the same active order is
        idempotent. A different basket for that id raises OrderConflict.
        """
        validate_order_id(order_id)
        requested = normalize(lines)
        previous = self._orders.get(order_id)
        if previous is not None:
            if previous.lines != requested:
                raise OrderConflict(order_id)
            return previous
        for line in requested:
            if self._stock.get(line.sku, 0) < line.quantity:
                raise InsufficientStock(line.sku)
        for line in requested:
            available = self._stock.get(line.sku, 0)
            if available < line.quantity:
                raise InsufficientStock(line.sku)
            self._stock[line.sku] = available - line.quantity
        receipt = Receipt(order_id, requested)
        self._orders[order_id] = receipt
        return receipt

    def cancel(self, order_id):
        """Restore one active order exactly once; return whether it existed."""
        validate_order_id(order_id)
        receipt = self._orders.pop(order_id, None)
        if receipt is None:
            return False
        for line in receipt.lines:
            self._stock[line.sku] = self._stock.get(line.sku, 0) + line.quantity
        return True

    def receipt(self, order_id):
        """Return an active receipt, or None for an unknown/cancelled order."""
        validate_order_id(order_id)
        return self._orders.get(order_id)

    def active_orders(self):
        """List active order ids in lexical order."""
        return tuple(sorted(self._orders))

    def restock(self, sku, quantity):
        """Add positive whole units to an existing or new SKU."""
        validate_sku(sku)
        validate_units(quantity)
        self._stock[sku] = self._stock.get(sku, 0) + quantity
        return self._stock[sku]

    def total_available(self):
        """Count available units, excluding units held by active orders."""
        return sum(self._stock.values())
