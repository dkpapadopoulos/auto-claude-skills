import unittest
from inventory import Inventory
from contracts import Line, InsufficientStock, OrderConflict

class ContractTests(unittest.TestCase):

    def test_atomic_shortage(self):
        s = Inventory({'a': 5, 'z': 1})
        with self.assertRaises(InsufficientStock):
            s.reserve('o', [Line('a', 2), Line('z', 2)])
        self.assertEqual(s.snapshot(), {'a': 5, 'z': 1})
        self.assertEqual(s.active_orders(), ())
        self.assertIsNone(s.receipt('o'))

    def test_exact_capacity(self):
        s = Inventory({'a': 2})
        r = s.reserve('o', [Line('a', 2)])
        self.assertEqual(r.units, 2)
        self.assertEqual(s.available('a'), 0)

    def test_ownership(self):
        stock = {'a': 7}
        s = Inventory(stock)
        s.reserve('o', [Line('a', 2)])
        self.assertEqual(stock, {'a': 7})
        stock['a'] = 90
        self.assertEqual(s.available('a'), 5)
        view = s.snapshot()
        view['a'] = 0
        self.assertEqual(s.available('a'), 5)

    def test_cancel_once(self):
        s = Inventory({'a': 7})
        s.reserve('o', [Line('a', 2)])
        self.assertTrue(s.cancel('o'))
        self.assertFalse(s.cancel('o'))
        self.assertIsNone(s.receipt('o'))
        self.assertEqual(s.snapshot(), {'a': 7})
        s.reserve('o', [Line('a', 1)])
        self.assertEqual(s.available('a'), 6)

    def test_idempotent_consolidation(self):
        s = Inventory({'a': 9, 'b': 5})
        lines = [Line('b', 1), Line('a', 1), Line('a', 2)]
        r = s.reserve('o', iter(lines))
        self.assertEqual(r.lines, (Line('a', 3), Line('b', 1)))
        self.assertEqual(s.reserve('o', [Line('a', 3), Line('b', 1)]), r)
        self.assertEqual(s.snapshot(), {'a': 6, 'b': 4})
        self.assertEqual(lines, [Line('b', 1), Line('a', 1), Line('a', 2)])

    def test_conflict(self):
        s = Inventory({'a': 9})
        s.reserve('o', [Line('a', 1)])
        with self.assertRaises(OrderConflict):
            s.reserve('o', [Line('a', 2)])
        self.assertEqual(s.available('a'), 8)

    def test_invalid_basket(self):
        s = Inventory({'a': 9})
        for bad in [0, -1, True, 1.5]:
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    s.reserve('o', [Line('a', 1), Line('a', bad)])
                self.assertEqual(s.available('a'), 9)

    def test_empty_basket(self):
        s = Inventory({})
        r = s.reserve('o', [])
        self.assertEqual((r.order_id, r.lines, r.units, r.quantities()), ('o', (), 0, {}))
        self.assertEqual(s.active_orders(), ('o',))

    def test_missing_sku(self):
        s = Inventory({})
        self.assertEqual(s.available('missing'), 0)
        with self.assertRaises(InsufficientStock):
            s.reserve('o', [Line('missing', 1)])
        self.assertEqual(s.snapshot(), {})

    def test_restock_and_receipt_copy(self):
        s = Inventory({'a': 5})
        self.assertEqual(s.restock('b', 3), 3)
        r = s.reserve('z', [Line('a', 1)])
        r.quantities()['a'] = 90
        self.assertEqual(s.receipt('z').quantities(), {'a': 1})
        self.assertEqual(s.total_available(), 7)
