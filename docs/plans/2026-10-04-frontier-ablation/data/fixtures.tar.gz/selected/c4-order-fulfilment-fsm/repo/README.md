# orderflow

Order fulfilment on top of a small state machine engine. Standard library only.

```python
from orderflow import Order, Warehouse

warehouse = Warehouse({"kettle": 10})
order = Order("A-1", "kettle", 2, warehouse)
order.pay()
order.pack()                    # reserves 2 kettles
order.address = "1 Mill Lane"
order.ship(carrier="courier")   # releases the reservation, removes the units
order.deliver()
```

## Modules

| module | contents |
|---|---|
| `orderflow/engine.py` | `Machine`, `Transition`, `HistoryEntry`, `InvalidTransition`, `GuardRejected` |
| `orderflow/warehouse.py` | `Warehouse` (`on_hand`, `reserved`, `available`, `reserve`, `release`, `remove`), `StockError` |
| `orderflow/orders.py` | `Order`, `STATES` |

The exact behaviour of each piece is described in its module and class
docstrings: how the engine handles an event (the six steps, and events fired
from callbacks), what the warehouse figures mean, and the order life cycle
with its stock handling.

## Tests

```
python3 -m unittest discover -s tests
```
