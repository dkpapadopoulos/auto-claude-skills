"""Order fulfilment built on the state machine engine.

Life cycle::

    new --pay--> paid --pack--> packed --ship--> shipped --deliver--> delivered

    new, paid, packed --cancel--> cancelled

Stock handling:

* ``pack`` is refused while the warehouse has fewer available units than the
  order needs.
* Entering ``packed`` reserves the order's units.
* Leaving ``packed`` - shipped or cancelled - releases that reservation.
* ``ship`` is refused until the order has a delivery address.  Shipping
  removes the units from the warehouse.

An order holds a reservation for exactly as long as it is in ``packed``.
"""

from typing import List, Optional, Tuple

from .engine import Machine, Transition
from .warehouse import Warehouse

STATES = ("new", "paid", "packed", "shipped", "delivered", "cancelled")


class Order:
    """One customer order for ``quantity`` units of a single SKU.

    Public attributes:

    ``machine``   the underlying ``Machine``; firing events on it directly is
                  equivalent to calling the methods below
    ``trail``     list of ``(kind, state)`` tuples, ``kind`` being ``"exit"``
                  or ``"enter"``; one entry is appended each time the order
                  actually leaves or enters a state
    ``address``   delivery address, may be set any time before shipping
    ``carrier``   carrier of the shipment, ``None`` until shipped

    With ``auto_pack=True`` the order is packed as soon as it is paid,
    provided the stock is available at that moment.
    """

    def __init__(self, order_id: str, sku: str, quantity: int,
                 warehouse: Warehouse, address: Optional[str] = None,
                 auto_pack: bool = False):
        if quantity <= 0:
            raise ValueError("quantity must be positive")
        self.order_id = order_id
        self.sku = sku
        self.quantity = quantity
        self.warehouse = warehouse
        self.address = address
        self.auto_pack = auto_pack
        self.carrier: Optional[str] = None
        self.trail: List[Tuple[str, str]] = []
        self.machine = self._build_machine()

    def _build_machine(self) -> Machine:
        machine = Machine(STATES, "new")
        machine.add_transition("new", "pay", "paid")
        machine.add_transition("paid", "pack", "packed", guard=self._stock_available)
        machine.add_transition("packed", "ship", "shipped",
                               guard=self._has_address, action=self._dispatch)
        machine.add_transition("shipped", "deliver", "delivered")
        machine.add_transition(("new", "paid", "packed"), "cancel", "cancelled")

        for state in STATES:
            machine.on_exit(state, self._note_exit)
            machine.on_enter(state, self._note_enter)
        machine.on_enter("paid", self._pack_if_possible)
        machine.on_enter("packed", self._reserve)
        machine.on_exit("packed", self._release)
        return machine

    # -- public operations --------------------------------------------------

    @property
    def state(self) -> str:
        return self.machine.state

    def pay(self) -> None:
        self.machine.fire("pay")

    def pack(self) -> None:
        self.machine.fire("pack")

    def ship(self, carrier: str = "standard") -> None:
        self.machine.fire("ship", carrier=carrier)

    def deliver(self) -> None:
        self.machine.fire("deliver")

    def cancel(self) -> None:
        self.machine.fire("cancel")

    # -- guards and actions -------------------------------------------------

    def _stock_available(self, machine: Machine, payload: dict) -> bool:
        return self.warehouse.available(self.sku) >= self.quantity

    def _has_address(self, machine: Machine, payload: dict) -> bool:
        return bool(self.address)

    def _dispatch(self, machine: Machine, payload: dict) -> None:
        self.warehouse.remove(self.sku, self.quantity)
        self.carrier = payload.get("carrier", "standard")

    # -- hooks --------------------------------------------------------------

    def _note_exit(self, machine: Machine, transition: Transition, payload: dict) -> None:
        self.trail.append(("exit", transition.source))

    def _note_enter(self, machine: Machine, transition: Transition, payload: dict) -> None:
        self.trail.append(("enter", transition.target))

    def _pack_if_possible(self, machine: Machine, transition: Transition,
                          payload: dict) -> None:
        if self.auto_pack and self._stock_available(machine, payload):
            machine.fire("pack")

    def _reserve(self, machine: Machine, transition: Transition, payload: dict) -> None:
        self.warehouse.reserve(self.sku, self.quantity)

    def _release(self, machine: Machine, transition: Transition, payload: dict) -> None:
        self.warehouse.release(self.sku, self.quantity)

    def __repr__(self) -> str:
        return f"Order({self.order_id!r}, {self.quantity} x {self.sku}, {self.state})"
