# Shipping fails with StockError after a first attempt without an address

Support hit this twice last week. A packed order had no delivery address yet,
so the first attempt to ship it was refused - that part is correct. The
customer then supplied the address, and the second attempt blew up:

```python
warehouse = Warehouse({"kettle": 10})
order = Order("A-1", "kettle", 2, warehouse)
order.pay()
order.pack()
order.ship()            # GuardRejected - fine, there is no address
order.address = "1 Mill Lane"
order.ship()            # StockError: cannot release 2 x kettle: only 0 reserved
```

The order is now stuck in `packed` and somebody has to fix it by hand.

`tests/test_orders.py` has a test for this,
`OrderFlowTests.test_ship_after_adding_address`, and it currently fails. Run
the tests with `python3 -m unittest discover -s tests`.

## What should be true when this is done

1. The scenario above works: the second `ship()` succeeds, the order is
   `shipped`, and the warehouse ends with `on_hand("kettle") == 8` and
   `reserved("kettle") == 0`.

2. A refused event changes nothing. Whether the event is not allowed in the
   current state (`InvalidTransition`) or its guard says no (`GuardRejected`),
   no hook and no action runs, and everything observable is exactly as it was
   before the call: the state, the history, the order's `trail`, and the
   warehouse figures `on_hand`, `reserved` and `available`. In particular an
   order that is still `packed` after a refused `ship` still holds its
   reservation, and a refused `pack` leaves no entry in the `trail`.

3. Point 2 holds however the event arrives - through the `Order` methods or
   through `order.machine.fire(...)` - and for any `Machine`, not only for
   orders. It also holds for an event that a hook fired and that was handled
   from the queue: the transitions completed before it stay in effect, the
   refused event changes nothing and runs no hook of the state the machine is
   in by then, and the exception reaches the caller of the outermost `fire`.

4. An accepted event still goes through the documented steps, each once and
   in order: exit hooks (in registration order), action, state change and
   history entry, enter hooks. A refused attempt followed by an accepted one
   runs each exit hook and the action once in total, not twice.

5. Other orders that share the warehouse are unaffected by an order's refused
   events: their reservations stay intact, and the warehouse figures always
   add up (every order in `packed` holds exactly its own quantity).

Please keep the public names and signatures as they are.
