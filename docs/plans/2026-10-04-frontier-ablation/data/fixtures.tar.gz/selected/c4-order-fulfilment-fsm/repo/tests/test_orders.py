import unittest

from orderflow import GuardRejected, InvalidTransition, Order, StockError, Warehouse


class OrderFlowTests(unittest.TestCase):
    def setUp(self):
        self.warehouse = Warehouse({"kettle": 10, "mug": 1})

    def packed_order(self, **kwargs):
        order = Order("A-1", "kettle", 2, self.warehouse, **kwargs)
        order.pay()
        order.pack()
        return order

    def test_happy_path(self):
        order = self.packed_order(address="1 Mill Lane")
        self.assertEqual(self.warehouse.reserved("kettle"), 2)
        self.assertEqual(self.warehouse.available("kettle"), 8)
        order.ship(carrier="courier")
        order.deliver()
        self.assertEqual(order.state, "delivered")
        self.assertEqual(order.carrier, "courier")
        self.assertEqual(self.warehouse.on_hand("kettle"), 8)
        self.assertEqual(self.warehouse.reserved("kettle"), 0)

    def test_trail_records_exits_and_enters(self):
        order = Order("A-1", "kettle", 2, self.warehouse)
        order.pay()
        self.assertEqual(order.trail, [("exit", "new"), ("enter", "paid")])

    def test_cancel_packed_order_releases_stock(self):
        order = self.packed_order()
        order.cancel()
        self.assertEqual(order.state, "cancelled")
        self.assertEqual(self.warehouse.reserved("kettle"), 0)
        self.assertEqual(self.warehouse.on_hand("kettle"), 10)

    def test_pack_is_refused_when_out_of_stock(self):
        order = Order("A-2", "mug", 3, self.warehouse)
        order.pay()
        with self.assertRaises(GuardRejected):
            order.pack()
        self.assertEqual(order.state, "paid")

    def test_ship_is_refused_without_address(self):
        order = self.packed_order()
        with self.assertRaises(GuardRejected):
            order.ship()
        self.assertEqual(order.state, "packed")

    def test_deliver_before_shipping_is_invalid(self):
        order = self.packed_order(address="1 Mill Lane")
        with self.assertRaises(InvalidTransition):
            order.deliver()

    def test_auto_pack(self):
        order = Order("A-3", "kettle", 4, self.warehouse, auto_pack=True)
        order.pay()
        self.assertEqual(order.state, "packed")
        self.assertEqual(self.warehouse.reserved("kettle"), 4)
        waiting = Order("A-4", "mug", 2, self.warehouse, auto_pack=True)
        waiting.pay()
        self.assertEqual(waiting.state, "paid")

    def test_warehouse_refuses_impossible_movements(self):
        with self.assertRaises(StockError):
            self.warehouse.reserve("mug", 2)
        with self.assertRaises(StockError):
            self.warehouse.release("mug", 1)

    def test_ship_after_adding_address(self):
        order = self.packed_order()
        with self.assertRaises(GuardRejected):
            order.ship()
        order.address = "1 Mill Lane"
        order.ship()
        self.assertEqual(order.state, "shipped")
        self.assertEqual(self.warehouse.on_hand("kettle"), 8)
        self.assertEqual(self.warehouse.reserved("kettle"), 0)


if __name__ == "__main__":
    unittest.main()
