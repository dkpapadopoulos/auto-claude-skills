"""Stock bookkeeping for one warehouse.

For every SKU the warehouse tracks

``on_hand``    units physically in the building
``reserved``   units set aside for packed orders that have not left yet
``available``  ``on_hand - reserved``: units a new order may still claim
"""

from typing import Dict, Mapping


class StockError(Exception):
    """A stock movement is impossible with the current figures."""


class Warehouse:
    def __init__(self, stock: Mapping[str, int]):
        for sku, units in stock.items():
            if units < 0:
                raise ValueError(f"negative stock for {sku!r}")
        self._on_hand: Dict[str, int] = dict(stock)
        self._reserved: Dict[str, int] = {sku: 0 for sku in stock}

    def _require_sku(self, sku: str) -> None:
        if sku not in self._on_hand:
            raise StockError(f"unknown SKU {sku!r}")

    def on_hand(self, sku: str) -> int:
        self._require_sku(sku)
        return self._on_hand[sku]

    def reserved(self, sku: str) -> int:
        self._require_sku(sku)
        return self._reserved[sku]

    def available(self, sku: str) -> int:
        self._require_sku(sku)
        return self._on_hand[sku] - self._reserved[sku]

    def reserve(self, sku: str, units: int) -> None:
        """Set ``units`` aside; they stop being available."""
        if units > self.available(sku):
            raise StockError(
                f"cannot reserve {units} x {sku}: only {self.available(sku)} available")
        self._reserved[sku] += units

    def release(self, sku: str, units: int) -> None:
        """Give up a reservation of ``units`` made earlier."""
        if units > self.reserved(sku):
            raise StockError(
                f"cannot release {units} x {sku}: only {self.reserved(sku)} reserved")
        self._reserved[sku] -= units

    def remove(self, sku: str, units: int) -> None:
        """Take ``units`` out of the building.

        Only unreserved units can be removed, so a reservation has to be
        released before its units are shipped.
        """
        if units > self.available(sku):
            raise StockError(
                f"cannot remove {units} x {sku}: only {self.available(sku)} available")
        self._on_hand[sku] -= units
