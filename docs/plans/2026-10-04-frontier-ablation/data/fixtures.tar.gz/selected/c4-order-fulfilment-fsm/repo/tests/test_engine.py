import unittest

from orderflow.engine import GuardRejected, HistoryEntry, InvalidTransition, Machine


def light():
    machine = Machine(("red", "green", "amber"), "red")
    machine.add_transition("red", "go", "green")
    machine.add_transition("green", "slow", "amber")
    machine.add_transition("amber", "stop", "red")
    return machine


class MachineTests(unittest.TestCase):
    def test_transition_updates_state_and_history(self):
        machine = light()
        machine.fire("go", reason="timer")
        self.assertEqual(machine.state, "green")
        self.assertEqual(machine.history,
                         (HistoryEntry("red", "go", "green", {"reason": "timer"}),))

    def test_unknown_event_is_refused(self):
        machine = light()
        with self.assertRaises(InvalidTransition) as caught:
            machine.fire("slow")
        self.assertEqual((caught.exception.state, caught.exception.event), ("red", "slow"))
        self.assertEqual(machine.state, "red")
        self.assertEqual(machine.history, ())

    def test_guard_can_refuse(self):
        machine = Machine(("closed", "open"), "closed")
        machine.add_transition("closed", "push", "open",
                               guard=lambda m, payload: payload.get("key") == "brass")
        self.assertFalse(machine.can("push", key="iron"))
        with self.assertRaises(GuardRejected):
            machine.fire("push", key="iron")
        self.assertEqual(machine.state, "closed")
        self.assertTrue(machine.can("push", key="brass"))
        machine.fire("push", key="brass")
        self.assertEqual(machine.state, "open")

    def test_callbacks_run_in_documented_order(self):
        calls = []
        machine = Machine(("a", "b"), "a")
        machine.add_transition(
            "a", "go", "b", action=lambda m, payload: calls.append(("action", m.state)))
        machine.on_exit("a", lambda m, t, payload: calls.append(("exit", m.state)))
        machine.on_enter("b", lambda m, t, payload: calls.append(("enter", m.state)))
        machine.fire("go")
        self.assertEqual(calls, [("exit", "a"), ("action", "a"), ("enter", "b")])

    def test_events_fired_from_hooks_are_queued(self):
        seen = []
        machine = light()
        machine.on_enter("green", lambda m, t, payload: m.fire("slow"))
        machine.on_enter("green", lambda m, t, payload: seen.append(m.state))
        machine.on_enter("amber", lambda m, t, payload: seen.append(m.state))
        machine.fire("go")
        self.assertEqual(machine.state, "amber")
        self.assertEqual(seen, ["green", "amber"])

    def test_several_sources_and_duplicates(self):
        machine = light()
        machine.add_transition(("red", "green"), "fail", "amber")
        self.assertEqual(machine.events(), ["fail", "go"])
        with self.assertRaises(ValueError):
            machine.add_transition("red", "go", "amber")
        with self.assertRaises(ValueError):
            machine.add_transition("red", "jump", "blue")


if __name__ == "__main__":
    unittest.main()
