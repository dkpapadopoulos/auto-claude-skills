"""A small finite-state machine engine.

Handling an event
-----------------
``Machine.fire(event, **payload)`` handles one event in these steps:

1. The transition registered for ``(current state, event)`` is looked up.  If
   there is none, ``InvalidTransition`` is raised and nothing else happens.
2. The transition's guard, if it has one, is called as
   ``guard(machine, payload)``.  If it returns a false value,
   ``GuardRejected`` is raised and nothing else happens: no hook runs, the
   action does not run, and state and history are exactly as they were.
3. The exit hooks of the current state run, in registration order.
4. The transition's action, if it has one, is called as
   ``action(machine, payload)``.
5. ``machine.state`` becomes the target state and a ``HistoryEntry`` is
   appended to ``machine.history``.
6. The enter hooks of the target state run, in registration order.

Hooks are called as ``hook(machine, transition, payload)``.  ``payload`` is
the dict of keyword arguments given to ``fire``.

Events fired from a callback
----------------------------
A hook or action may call ``fire``.  Such an event is not handled on the
spot: it is queued and handled - by the same six steps - once the transition
in progress has finished, in the order the events were fired.

If a queued event is refused (step 1 or 2) or a callback raises, the exception
propagates out of the outermost ``fire`` call and the events still waiting in
the queue are dropped.  Transitions that completed before that stay in effect,
and the machine remains usable.
"""

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, Iterable, List, Optional, Tuple, Union

Payload = Dict[str, Any]


class MachineError(Exception):
    """Base class for refused events."""

    def __init__(self, state: str, event: str, message: str):
        super().__init__(message)
        self.state = state
        self.event = event


class InvalidTransition(MachineError):
    """The current state has no transition for the event."""

    def __init__(self, state: str, event: str):
        super().__init__(state, event, f"event {event!r} is not allowed in state {state!r}")


class GuardRejected(MachineError):
    """The transition exists but its guard said no."""

    def __init__(self, state: str, event: str):
        super().__init__(state, event, f"event {event!r} was refused in state {state!r}")


@dataclass(frozen=True)
class Transition:
    source: str
    event: str
    target: str
    guard: Optional[Callable[["Machine", Payload], Any]] = None
    action: Optional[Callable[["Machine", Payload], Any]] = None

    def permits(self, machine: "Machine", payload: Payload) -> bool:
        """True if the transition has no guard or its guard agrees."""
        return self.guard is None or bool(self.guard(machine, payload))

    def execute(self, machine: "Machine", payload: Payload) -> None:
        """Carry out the transition's own part of the work."""
        if not self.permits(machine, payload):
            raise GuardRejected(self.source, self.event)
        if self.action is not None:
            self.action(machine, payload)


@dataclass(frozen=True)
class HistoryEntry:
    source: str
    event: str
    target: str
    payload: Payload = field(default_factory=dict)


Hook = Callable[["Machine", Transition, Payload], Any]


class Machine:
    """A state machine over a fixed set of named states."""

    def __init__(self, states: Iterable[str], initial: str):
        self._states: Tuple[str, ...] = tuple(states)
        if len(set(self._states)) != len(self._states):
            raise ValueError("state names must be unique")
        if initial not in self._states:
            raise ValueError(f"unknown initial state {initial!r}")
        self._state = initial
        self._transitions: Dict[Tuple[str, str], Transition] = {}
        self._enter_hooks: Dict[str, List[Hook]] = {s: [] for s in self._states}
        self._exit_hooks: Dict[str, List[Hook]] = {s: [] for s in self._states}
        self._history: List[HistoryEntry] = []
        self._queue: Deque[Tuple[str, Payload]] = deque()
        self._busy = False

    # -- configuration ------------------------------------------------------

    def add_transition(self, source: Union[str, Iterable[str]], event: str,
                       target: str, guard=None, action=None) -> None:
        """Register ``source --event--> target``.

        ``source`` may be one state or several; each gets its own transition.
        A state can have only one transition per event.
        """
        sources = (source,) if isinstance(source, str) else tuple(source)
        for state in sources + (target,):
            self._require_state(state)
        for state in sources:
            if (state, event) in self._transitions:
                raise ValueError(f"state {state!r} already handles {event!r}")
            self._transitions[(state, event)] = Transition(
                state, event, target, guard, action)

    def on_enter(self, state: str, hook: Hook) -> None:
        """Run ``hook`` every time ``state`` is entered."""
        self._require_state(state)
        self._enter_hooks[state].append(hook)

    def on_exit(self, state: str, hook: Hook) -> None:
        """Run ``hook`` every time ``state`` is left."""
        self._require_state(state)
        self._exit_hooks[state].append(hook)

    def _require_state(self, state: str) -> None:
        if state not in self._states:
            raise ValueError(f"unknown state {state!r}")

    # -- inspection ---------------------------------------------------------

    @property
    def state(self) -> str:
        return self._state

    @property
    def history(self) -> Tuple[HistoryEntry, ...]:
        """Every completed transition, oldest first."""
        return tuple(self._history)

    def events(self) -> List[str]:
        """Events the current state has a transition for (guards not asked)."""
        return sorted(event for state, event in self._transitions if state == self._state)

    def can(self, event: str, **payload: Any) -> bool:
        """True if ``fire(event, **payload)`` would be accepted right now."""
        transition = self._transitions.get((self._state, event))
        return transition is not None and transition.permits(self, payload)

    # -- running ------------------------------------------------------------

    def fire(self, event: str, **payload: Any) -> None:
        """Handle ``event`` (see the module docstring for the exact steps)."""
        self._queue.append((event, payload))
        if self._busy:
            return      # the outermost call drains the queue
        self._busy = True
        try:
            while self._queue:
                next_event, next_payload = self._queue.popleft()
                self._step(next_event, next_payload)
        finally:
            self._queue.clear()
            self._busy = False

    def _step(self, event: str, payload: Payload) -> None:
        transition = self._transitions.get((self._state, event))
        if transition is None:
            raise InvalidTransition(self._state, event)
        for hook in self._exit_hooks[transition.source]:
            hook(self, transition, payload)
        transition.execute(self, payload)
        self._state = transition.target
        self._history.append(
            HistoryEntry(transition.source, event, transition.target, dict(payload)))
        for hook in self._enter_hooks[transition.target]:
            hook(self, transition, payload)
