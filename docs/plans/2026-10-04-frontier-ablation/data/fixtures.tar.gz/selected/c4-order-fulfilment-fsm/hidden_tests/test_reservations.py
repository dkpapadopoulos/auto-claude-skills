"""Refused events on orders, and what they do to the warehouse figures."""

import unittest

from orderflow import GuardRejected, InvalidTransition, Order, Warehouse


def figures(warehouse, sku):
    return (warehouse.on_hand(sku), warehouse.reserved(sku), warehouse.available(sku))


class ReservationTests(unittest.TestCase):
    def setUp(self):
        self.warehouse = Warehouse({"kettle": 10, "mug": 1})

    def packed_order(self, order_id="A-1", quantity=2):
        order = Order(order_id, "kettle", quantity, self.warehouse)
        order.pay()
        order.pack()
        return order

    def test_refused_ship_keeps_the_reservation(self):
        order = self.packed_order()
        with self.assertRaises(GuardRejected):
            order.ship()
        self.assertEqual(order.state, "packed")
        self.assertEqual(figures(self.warehouse, "kettle"), (10, 2, 8))

    def test_refused_ship_leaves_trail_and_history_alone(self):
        order = self.packed_order()
        trail = list(order.trail)
        history = order.machine.history
        with self.assertRaises(GuardRejected):
            order.ship()
        self.assertEqual(order.trail, trail)
        self.assertEqual(order.machine.history, history)
        self.assertIsNone(order.carrier)

    def test_ship_after_adding_address(self):
        order = self.packed_order()
        with self.assertRaises(GuardRejected):
            order.ship()
        order.address = "1 Mill Lane"
        order.ship(carrier="courier")
        self.assertEqual(order.state, "shipped")
        self.assertEqual(order.carrier, "courier")
        self.assertEqual(figures(self.warehouse, "kettle"), (8, 0, 8))
        self.assertEqual(order.trail.count(("exit", "packed")), 1)

    def test_refused_ship_through_the_machine(self):
        order = self.packed_order()
        with self.assertRaises(GuardRejected):
            order.machine.fire("ship")
        self.assertEqual(order.state, "packed")
        self.assertEqual(figures(self.warehouse, "kettle"), (10, 2, 8))
        self.assertNotIn(("exit", "packed"), order.trail)

    def test_other_orders_keep_their_reservations(self):
        first = self.packed_order("A-1", 2)
        second = self.packed_order("A-2", 3)
        for _ in range(2):
            with self.assertRaises(GuardRejected):
                first.ship()
            self.assertEqual(figures(self.warehouse, "kettle"), (10, 5, 5))
        first.address = "1 Mill Lane"
        first.ship()
        self.assertEqual(figures(self.warehouse, "kettle"), (8, 3, 5))
        second.cancel()
        self.assertEqual(figures(self.warehouse, "kettle"), (8, 0, 8))

    def test_refused_pack_leaves_no_trail_entry(self):
        order = Order("B-1", "mug", 3, self.warehouse)
        order.pay()
        trail = list(order.trail)
        with self.assertRaises(GuardRejected):
            order.pack()
        self.assertEqual(order.state, "paid")
        self.assertEqual(order.trail, trail)
        self.assertEqual(figures(self.warehouse, "mug"), (1, 0, 1))

    def test_invalid_event_on_packed_order_changes_nothing(self):
        order = self.packed_order()
        trail = list(order.trail)
        with self.assertRaises(InvalidTransition):
            order.deliver()
        self.assertEqual(order.state, "packed")
        self.assertEqual(order.trail, trail)
        self.assertEqual(figures(self.warehouse, "kettle"), (10, 2, 8))


if __name__ == "__main__":
    unittest.main()
