"""Refused events on a plain ``Machine``."""

import unittest

from orderflow import GuardRejected, InvalidTransition, Machine


class RefusedEventTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self.allow = False
        self.machine = Machine(("a", "b", "c"), "a")
        self.machine.add_transition("a", "go", "b", guard=self.guard, action=self.action)
        self.machine.on_exit("a", self.record("exit a"))
        self.machine.on_exit("a", self.record("exit a again"))
        self.machine.on_enter("b", self.record("enter b"))

    def guard(self, machine, payload):
        self.calls.append("guard")
        return self.allow or payload.get("ok", False)

    def action(self, machine, payload):
        self.calls.append("action")

    def record(self, label):
        return lambda machine, transition, payload: self.calls.append(label)

    def test_guard_refusal_runs_no_hook_and_no_action(self):
        with self.assertRaises(GuardRejected):
            self.machine.fire("go")
        self.assertEqual([call for call in self.calls if call != "guard"], [])

    def test_guard_refusal_keeps_state_and_history(self):
        with self.assertRaises(GuardRejected):
            self.machine.fire("go")
        self.assertEqual(self.machine.state, "a")
        self.assertEqual(self.machine.history, ())

    def test_unknown_event_runs_nothing(self):
        with self.assertRaises(InvalidTransition):
            self.machine.fire("jump")
        self.assertEqual(self.calls, [])
        self.assertEqual(self.machine.state, "a")
        self.assertEqual(self.machine.history, ())

    def test_accepted_event_runs_exit_action_enter_in_order(self):
        self.allow = True
        self.machine.fire("go")
        self.assertEqual(self.machine.state, "b")
        self.assertEqual(len(self.machine.history), 1)
        self.assertEqual([call for call in self.calls if call != "guard"],
                         ["exit a", "exit a again", "action", "enter b"])

    def test_refused_then_accepted_runs_exit_hooks_once(self):
        with self.assertRaises(GuardRejected):
            self.machine.fire("go", ok=False)
        self.machine.fire("go", ok=True)
        self.assertEqual(self.machine.state, "b")
        self.assertEqual(self.calls.count("exit a"), 1)
        self.assertEqual(self.calls.count("exit a again"), 1)
        self.assertEqual(self.calls.count("action"), 1)
        self.assertEqual(len(self.machine.history), 1)

    def test_refused_queued_event_runs_no_hook_of_the_reached_state(self):
        self.allow = True
        self.machine.add_transition("b", "next", "c", guard=lambda m, payload: False)
        self.machine.on_enter("b", lambda m, transition, payload: m.fire("next"))
        self.machine.on_exit("b", self.record("exit b"))
        self.machine.on_enter("c", self.record("enter c"))
        with self.assertRaises(GuardRejected):
            self.machine.fire("go")
        self.assertEqual(self.machine.state, "b")
        self.assertEqual(len(self.machine.history), 1)
        self.assertIn("enter b", self.calls)
        self.assertNotIn("exit b", self.calls)
        self.assertNotIn("enter c", self.calls)


if __name__ == "__main__":
    unittest.main()
