# c4-order-fulfilment-fsm

Category c (debugging with a misleading symptom). Domain: a small state machine.

**Symptom site:** `orderflow/orders.py::Order._release` (the `packed` exit hook) raises
`StockError: cannot release 2 x kettle: only 0 reserved` on the second `ship()`.
**Root cause:** `orderflow/engine.py::Machine._step` runs the exit hooks before the guard is
asked (the guard check sits inside `Transition.execute`, after the hooks), so a refused event
already ran every exit hook of the current state.

**Trap (one line):** making the release hook idempotent with a per-order flag passes the visible
tests, but a refused `ship` still drops the reservation and still runs exit hooks.

## Hidden test -> requirement

`hidden_tests/test_refused_events.py` (`RefusedEventTests`, plain `Machine`)

| hidden test | required by |
|---|---|
| `test_guard_refusal_runs_no_hook_and_no_action` | TASK.md 2: "A refused event changes nothing. Whether the event is not allowed in the current state (`InvalidTransition`) or its guard says no (`GuardRejected`), no hook and no action runs"; TASK.md 3: "for any `Machine`, not only for orders" |
| `test_guard_refusal_keeps_state_and_history` | TASK.md 2: "everything observable is exactly as it was before the call: the state, the history" |
| `test_unknown_event_runs_nothing` | TASK.md 2 (the `InvalidTransition` case); engine docstring step 1: "`InvalidTransition` is raised and nothing else happens" |
| `test_accepted_event_runs_exit_action_enter_in_order` | TASK.md 4: "An accepted event still goes through the documented steps, each once and in order: exit hooks (in registration order), action, state change and history entry, enter hooks." |
| `test_refused_then_accepted_runs_exit_hooks_once` | TASK.md 4: "A refused attempt followed by an accepted one runs each exit hook and the action once in total, not twice." |
| `test_refused_queued_event_runs_no_hook_of_the_reached_state` | TASK.md 3: "It also holds for an event that a hook fired and that was handled from the queue: the transitions completed before it stay in effect, the refused event changes nothing and runs no hook of the state the machine is in by then, and the exception reaches the caller of the outermost `fire`." |

`hidden_tests/test_reservations.py` (`ReservationTests`, `Order` + `Warehouse`)

| hidden test | required by |
|---|---|
| `test_refused_ship_keeps_the_reservation` | TASK.md 2: "an order that is still `packed` after a refused `ship` still holds its reservation" and "the warehouse figures `on_hand`, `reserved` and `available`" are unchanged |
| `test_refused_ship_leaves_trail_and_history_alone` | TASK.md 2: "everything observable is exactly as it was before the call: the state, the history, the order's `trail`"; `Order` docstring: "`carrier` ... `None` until shipped" |
| `test_ship_after_adding_address` | TASK.md 1: "the second `ship()` succeeds, the order is `shipped`, and the warehouse ends with `on_hand(\"kettle\") == 8` and `reserved(\"kettle\") == 0`."; TASK.md 4 (exit hook once in total); `Order` docstring on `trail` and `carrier` |
| `test_refused_ship_through_the_machine` | TASK.md 3: "Point 2 holds however the event arrives - through the `Order` methods or through `order.machine.fire(...)`" |
| `test_other_orders_keep_their_reservations` | TASK.md 5: "Other orders that share the warehouse are unaffected by an order's refused events: their reservations stay intact, and the warehouse figures always add up (every order in `packed` holds exactly its own quantity)." |
| `test_refused_pack_leaves_no_trail_entry` | TASK.md 2: "a refused `pack` leaves no entry in the `trail`" |
| `test_invalid_event_on_packed_order_changes_nothing` | TASK.md 2 (the `InvalidTransition` case: state, `trail` and warehouse figures unchanged) |

## Overlays

* `solution/orderflow/engine.py` - `_step` asks `transition.permits(...)` and raises
  `GuardRejected` before any exit hook runs; `Transition.execute` only runs the action.
* `wrong_fix/orderflow/orders.py` - `_release` is guarded by a `_holding` flag set in
  `_reserve` (symptom-site patch).

## Expected results

| configuration | visible tests (15) | hidden tests (13) |
|---|---|---|
| untouched `repo/` | 1 fails (`test_ship_after_adding_address`) | 9 fail |
| `repo/` + `solution/` | all pass | all pass |
| `repo/` + `wrong_fix/` | all pass | 9 fail |
