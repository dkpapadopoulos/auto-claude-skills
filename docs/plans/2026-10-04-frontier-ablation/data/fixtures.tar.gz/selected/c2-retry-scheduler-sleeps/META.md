# c2-retry-scheduler-sleeps

Category c (debugging with a misleading symptom). Domain: retry/backoff scheduling with an injected sleeper (`ManualClock`; no real sleeping, no wall clock).

## Trap

The symptom is an extra `sleep` made by `RetryScheduler.run()` in `retrysched/scheduler.py`, but the defect is in `retrysched/queue.py`: `RetryQueue.next_due()` and `__len__` look at the raw heap, so entries left behind by `discard` (cancel) and by a replacing `push` (reschedule) still count. Returning from `run()` when no job is left (wrong_fix) cures the reported trailing sleep but still wakes up for superseded entries that sit before a live one, and leaves `next_wakeup()`/`pending_count()` wrong.

## Hidden tests -> requirement

| Hidden test | Required by |
|---|---|
| `test_wakeups.SleepsAfterCancelTest.test_no_sleep_after_last_job_when_later_job_was_cancelled` | TASK.md: "`run()` returns as soon as no job is pending. It does not sleep after the last job has succeeded, been given up on, or been cancelled." |
| `test_wakeups.SleepsAfterCancelTest.test_cancelled_earlier_job_does_not_split_the_sleep` | TASK.md: "For example: `a` is waiting for `t=1`, `b` is waiting for `t=20`, `a` is cancelled at `t=0`; `run()` must make the single call `sleep(20.0)`." |
| `test_wakeups.SleepsAfterCancelTest.test_cancelled_jobs_between_waiting_jobs` | TASK.md: "Every `sleep` call `run()` makes lasts exactly until the earliest job that is still waiting becomes due. A job that was cancelled, and the old time of a job that was rescheduled, never cause a sleep, never cut one short and never split one in two." |
| `test_wakeups.SleepsAfterRescheduleTest.test_rescheduling_later_gives_one_sleep_to_the_new_time` | Same TASK.md sentence, plus: "A rescheduled job runs exactly once, at its new time (`reschedule(job, 10)` at `t=0` means the next attempt happens at `t=10`, whether that is earlier or later than before), ..." |
| `test_wakeups.SleepsAfterRescheduleTest.test_rescheduling_earlier_leaves_nothing_to_wait_for` | TASK.md: "`run()` returns as soon as no job is pending." and "A job that was cancelled, and the old time of a job that was rescheduled, never cause a sleep, ..." |
| `test_wakeups.SleepsAfterRescheduleTest.test_rescheduled_job_runs_once_and_backoff_carries_on` | TASK.md: "A rescheduled job runs exactly once, at its new time ..., and its attempt count carries on: if that attempt is its second failure, the next wait is the policy's wait for a second failure." (`Event` fields: `scheduler.py` comment on `Event`, README "Scheduler" table.) |
| `test_wakeups.DocumentedBackoffTest.test_waits_grow_and_are_capped` | TASK.md: "The existing behaviour stays as documented: waits of `base_delay`, `base_delay * multiplier`, ... capped at `max_delay`; `retry_after` honoured; ..." (README "Backoff": `retry_after` is "still capped at `max_delay`".) |
| `test_wakeups.DocumentedBackoffTest.test_job_is_given_up_after_max_attempts` | TASK.md: "... a job is dropped with a `gave_up` event after `max_attempts` attempts; ..." |
| `test_pending_view.NextWakeupTest.test_next_wakeup_skips_cancelled_job` | TASK.md: "`next_wakeup()` returns the time at which the earliest job that is still waiting becomes due, and `None` when no job is waiting. Cancelled jobs and the old times of rescheduled jobs do not show up in it." |
| `test_pending_view.NextWakeupTest.test_next_wakeup_is_none_once_only_waiting_job_is_cancelled` | Same TASK.md sentence ("... and `None` when no job is waiting."). |
| `test_pending_view.NextWakeupTest.test_next_wakeup_follows_reschedule` | Same TASK.md sentence ("... the old times of rescheduled jobs do not show up in it."). |
| `test_pending_view.PendingCountTest.test_cancel_lowers_pending_count` | TASK.md: "`pending_count()` is the number of jobs that are still waiting. Cancelling a waiting job lowers it by one; rescheduling a job does not change it." |
| `test_pending_view.PendingCountTest.test_reschedule_keeps_pending_count` | Same TASK.md sentence ("... rescheduling a job does not change it."). |
| `test_pending_view.SameTimeOrderTest.test_rescheduled_job_goes_behind_jobs_already_due_at_that_time` | TASK.md: "... jobs due at the same time run in the order they were scheduled, and a rescheduled job counts as scheduled at the time of the `reschedule` call." |

## Expected results

| Configuration | `repo/tests` (23) | `hidden_tests` (14) |
|---|---|---|
| untouched `repo/` | 1 fails (`test_run_returns_when_last_job_is_done`) | 11 fail |
| `repo/` + `solution/` | all pass | all pass |
| `repo/` + `wrong_fix/` | all pass | 9 fail |
