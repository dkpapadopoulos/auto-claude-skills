"""Time-ordered queue of the jobs that are waiting to run.

The queue holds at most one entry per job id.  Entries live in a binary heap
ordered by due time; entries with the same due time keep the order in which
they were pushed.

Removing something from the middle of a heap is expensive, so ``push`` for a
job that is already queued and ``discard`` do not touch the heap.  They only
update the record of which entry is current for the job; the entry left behind
is recognised by its sequence number when it reaches the top of the heap.
"""

import heapq
import itertools


class RetryQueue:
    """Pending jobs ordered by the time they become due."""

    def __init__(self):
        self._heap = []  # (due, sequence, job_id)
        self._current = {}  # job_id -> sequence of its current entry
        self._sequence = itertools.count()

    def push(self, job_id, due):
        """Queue ``job_id`` to become due at time ``due``.

        If the job is already queued its due time is replaced: it will be
        handed out once, at the new time, and counts as pushed just now for
        the ordering of entries with equal due times.
        """
        sequence = next(self._sequence)
        self._current[job_id] = sequence
        heapq.heappush(self._heap, (due, sequence, job_id))

    def discard(self, job_id):
        """Remove ``job_id`` from the queue.

        Returns True if the job was queued, False if there was nothing to do.
        """
        return self._current.pop(job_id, None) is not None

    def __contains__(self, job_id):
        return job_id in self._current

    def __len__(self):
        """Number of jobs currently queued."""
        return len(self._heap)

    def next_due(self):
        """Due time of the job that will be handed out next.

        Returns None when no job is queued.
        """
        if not self._heap:
            return None
        return self._heap[0][0]

    def pop_due(self, now):
        """Remove and return the ids of all jobs due at or before ``now``.

        The ids are ordered by due time; jobs with the same due time come in
        the order they were pushed.
        """
        ready = []
        while self._heap and self._heap[0][0] <= now:
            _due, sequence, job_id = heapq.heappop(self._heap)
            if self._current.get(job_id) != sequence:
                continue  # replaced or discarded since it was pushed
            del self._current[job_id]
            ready.append(job_id)
        return ready
