import unittest

from retrysched import (
    GAVE_UP,
    OK,
    RETRY,
    BackoffPolicy,
    ManualClock,
    RetryAfter,
    RetryScheduler,
)


def make(policy=None):
    clock = ManualClock()
    scheduler = RetryScheduler(policy or BackoffPolicy(), clock=clock.now, sleep=clock.sleep)
    return clock, scheduler


class Flaky:
    """Job that raises the given errors one after the other, then succeeds."""

    def __init__(self, clock, *errors):
        self.clock = clock
        self.errors = list(errors)
        self.calls = []

    def __call__(self):
        self.calls.append(self.clock.now())
        if self.errors:
            raise self.errors.pop(0)


class BackoffTest(unittest.TestCase):
    def test_job_that_works_first_time(self):
        clock, scheduler = make()
        job = Flaky(clock)
        scheduler.submit("job", job)
        scheduler.run()
        self.assertEqual(job.calls, [0.0])
        self.assertEqual(clock.sleeps, [])
        self.assertEqual([event.outcome for event in scheduler.history], [OK])

    def test_waits_double_after_each_failure(self):
        clock, scheduler = make()
        job = Flaky(clock, OSError(), OSError(), OSError())
        scheduler.submit("job", job)
        scheduler.run()
        self.assertEqual(clock.sleeps, [1.0, 2.0, 4.0])
        self.assertEqual(job.calls, [0.0, 1.0, 3.0, 7.0])
        self.assertEqual(
            [(event.attempt, event.outcome) for event in scheduler.history],
            [(1, RETRY), (2, RETRY), (3, RETRY), (4, OK)],
        )

    def test_retry_after_is_honoured(self):
        clock, scheduler = make()
        job = Flaky(clock, RetryAfter(12))
        scheduler.submit("job", job)
        scheduler.run()
        self.assertEqual(clock.sleeps, [12.0])

    def test_gives_up_after_max_attempts(self):
        clock, scheduler = make(BackoffPolicy(max_attempts=2))
        job = Flaky(clock, OSError(), OSError(), OSError())
        scheduler.submit("job", job)
        scheduler.run()
        self.assertEqual(len(job.calls), 2)
        self.assertEqual(scheduler.history[-1].outcome, GAVE_UP)
        self.assertFalse(scheduler.is_pending("job"))


class JobManagementTest(unittest.TestCase):
    def test_submitting_a_pending_id_twice(self):
        clock, scheduler = make()
        scheduler.submit("job", Flaky(clock))
        with self.assertRaises(ValueError):
            scheduler.submit("job", Flaky(clock))

    def test_cancelled_job_is_not_run_again(self):
        clock, scheduler = make()
        job = Flaky(clock, OSError(), OSError())
        scheduler.submit("job", job)
        self.assertEqual(scheduler.tick(), 1)
        self.assertTrue(scheduler.cancel("job"))
        self.assertFalse(scheduler.cancel("job"))
        scheduler.run()
        self.assertEqual(job.calls, [0.0])
        self.assertFalse(scheduler.is_pending("job"))

    def test_reschedule_needs_a_waiting_job(self):
        clock, scheduler = make()
        with self.assertRaises(KeyError):
            scheduler.reschedule("nope", 1)

    def test_pending_count_and_next_wakeup(self):
        clock, scheduler = make()
        scheduler.submit("a", Flaky(clock, OSError()))
        scheduler.submit("b", Flaky(clock, RetryAfter(5)))
        self.assertEqual(scheduler.pending_count(), 2)
        scheduler.tick()
        self.assertEqual(scheduler.pending_count(), 2)
        self.assertEqual(scheduler.next_wakeup(), 1.0)
        scheduler.run()
        self.assertEqual(scheduler.pending_count(), 0)
        self.assertIsNone(scheduler.next_wakeup())


class CancelDuringRunTest(unittest.TestCase):
    def test_run_returns_when_last_job_is_done(self):
        clock, scheduler = make()

        def report():
            raise RetryAfter(30)

        sync = Flaky(clock, ConnectionError("reset by peer"))
        scheduler.submit("report", report)
        scheduler.submit("sync", sync)
        scheduler.tick()
        scheduler.cancel("report")
        scheduler.run()
        self.assertEqual(sync.calls, [0.0, 1.0])
        self.assertEqual(clock.sleeps, [1.0])
        self.assertEqual(clock.now(), 1.0)


if __name__ == "__main__":
    unittest.main()
