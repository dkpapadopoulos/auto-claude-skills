"""retrysched - run flaky jobs with exponential backoff.

The scheduler never touches the wall clock: the current time and the sleep
function are passed in, so workers use ``time.monotonic``/``time.sleep`` and
tests use :class:`ManualClock`.
"""

from .clock import ManualClock
from .policy import BackoffPolicy, RetryAfter
from .queue import RetryQueue
from .scheduler import GAVE_UP, OK, RETRY, Event, RetryScheduler

__all__ = [
    "BackoffPolicy",
    "Event",
    "GAVE_UP",
    "ManualClock",
    "OK",
    "RETRY",
    "RetryAfter",
    "RetryQueue",
    "RetryScheduler",
]
