"""Run jobs until they succeed, backing off between attempts."""

from collections import namedtuple

from .queue import RetryQueue

OK = "ok"
RETRY = "retry"
GAVE_UP = "gave_up"

#: One entry of :attr:`RetryScheduler.history`.  ``time`` is the clock reading
#: when the attempt finished, ``attempt`` counts from 1 and ``outcome`` is one
#: of :data:`OK`, :data:`RETRY` (failed, another attempt is queued) and
#: :data:`GAVE_UP` (failed on its last allowed attempt).
Event = namedtuple("Event", "time job_id attempt outcome")


class _Job:
    __slots__ = ("fn", "attempts")

    def __init__(self, fn):
        self.fn = fn
        self.attempts = 0


class RetryScheduler:
    """Runs submitted jobs, retrying the ones that raise.

    ``policy``  a :class:`~retrysched.policy.BackoffPolicy`
    ``clock``   callable returning the current time in seconds
    ``sleep``   callable taking a number of seconds; must make ``clock`` advance

    A job is a callable taking no arguments.  Returning normally means success.
    Raising any ``Exception`` is a failure: the job is queued again after
    ``policy.delay_for(failures, retry_after)`` seconds, where ``retry_after``
    is the exception's ``retry_after`` attribute if it has one.  A job that
    fails on attempt number ``policy.max_attempts`` is dropped.

    A job is *pending* from the moment it is submitted until it succeeds, is
    given up on, or is cancelled.
    """

    def __init__(self, policy, clock, sleep):
        self._policy = policy
        self._clock = clock
        self._sleep = sleep
        self._queue = RetryQueue()
        self._jobs = {}
        self.history = []

    # -- managing jobs ----------------------------------------------------

    def submit(self, job_id, fn):
        """Add a job; it is due immediately.

        Raises ``ValueError`` if a job with this id is still pending.
        """
        if job_id in self._jobs:
            raise ValueError(f"job {job_id!r} is already pending")
        self._jobs[job_id] = _Job(fn)
        self._queue.push(job_id, self._clock())

    def cancel(self, job_id):
        """Drop a pending job; it will not be run again.

        Returns True if the job was pending, False otherwise.
        """
        if job_id not in self._jobs:
            return False
        del self._jobs[job_id]
        self._queue.discard(job_id)
        return True

    def reschedule(self, job_id, delay):
        """Make a waiting job due ``delay`` seconds from now.

        This replaces the time the job was going to run at; the job runs once,
        at the new time.  Its attempt count is kept, so the backoff carries on
        from where it was.

        Raises ``KeyError`` if the job is not waiting and ``ValueError`` if
        ``delay`` is negative.
        """
        if delay < 0:
            raise ValueError("delay must not be negative")
        if job_id not in self._queue:
            raise KeyError(job_id)
        self._queue.push(job_id, self._clock() + delay)

    def is_pending(self, job_id):
        """True while the job has neither finished nor been cancelled."""
        return job_id in self._jobs

    def pending_count(self):
        """Number of jobs waiting for their first run or for a retry."""
        return len(self._queue)

    def next_wakeup(self):
        """Time at which the next waiting job becomes due, or None if none is waiting."""
        return self._queue.next_due()

    # -- running ----------------------------------------------------------

    def tick(self):
        """Run every job that is due right now, once each, without sleeping.

        Jobs run in order of due time; jobs due at the same time run in the
        order they were scheduled.  Returns the number of attempts made.
        """
        made = 0
        for job_id in self._queue.pop_due(self._clock()):
            job = self._jobs.get(job_id)
            if job is None or job_id in self._queue:
                continue  # cancelled (and maybe resubmitted) by a job earlier in this batch
            self._attempt(job_id, job)
            made += 1
        return made

    def run(self):
        """Run until no job is pending, sleeping between wake-ups.

        After running what is due, the scheduler sleeps exactly until the
        earliest waiting job becomes due and repeats.  It returns as soon as
        nothing is pending, and it never calls ``sleep`` with a zero or
        negative duration.
        """
        while True:
            self.tick()
            wakeup = self._queue.next_due()
            if wakeup is None:
                return
            wait = wakeup - self._clock()
            if wait > 0:
                self._sleep(wait)

    def _attempt(self, job_id, job):
        job.attempts += 1
        try:
            job.fn()
        except Exception as error:
            if self._jobs.get(job_id) is not job:
                return  # cancelled itself while running
            if self._policy.exhausted(job.attempts):
                del self._jobs[job_id]
                self._record(job_id, job.attempts, GAVE_UP)
                return
            hint = getattr(error, "retry_after", None)
            delay = self._policy.delay_for(job.attempts, hint)
            self._queue.push(job_id, self._clock() + delay)
            self._record(job_id, job.attempts, RETRY)
        else:
            if self._jobs.get(job_id) is not job:
                return  # cancelled itself while running
            del self._jobs[job_id]
            self._record(job_id, job.attempts, OK)

    def _record(self, job_id, attempt, outcome):
        self.history.append(Event(self._clock(), job_id, attempt, outcome))
