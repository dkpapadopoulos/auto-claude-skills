"""Backoff policy: how long to wait after a failure, and when to stop."""

from dataclasses import dataclass


class RetryAfter(Exception):
    """Raise from a job to ask for at least ``seconds`` before the next attempt.

    The scheduler honours the ``retry_after`` attribute of *any* exception a
    job raises; this class is just the convenient way to set it.
    """

    def __init__(self, seconds, message=""):
        super().__init__(message or f"retry after {seconds}s")
        self.retry_after = seconds


@dataclass(frozen=True)
class BackoffPolicy:
    """Exponential backoff with a ceiling and an attempt limit.

    ``base_delay``    wait after the first failure, in seconds
    ``multiplier``    growth factor applied for each further failure
    ``max_delay``     no single wait is longer than this
    ``max_attempts``  a job is run at most this many times in total
    """

    base_delay: float = 1.0
    multiplier: float = 2.0
    max_delay: float = 60.0
    max_attempts: int = 5

    def __post_init__(self):
        if self.base_delay <= 0:
            raise ValueError("base_delay must be positive")
        if self.multiplier < 1:
            raise ValueError("multiplier must be at least 1")
        if self.max_delay < self.base_delay:
            raise ValueError("max_delay must not be smaller than base_delay")
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be at least 1")

    def delay_for(self, failures, retry_after=None):
        """Seconds to wait after a job has failed ``failures`` times in a row.

        The first failure waits ``base_delay``; each further failure multiplies
        the wait by ``multiplier``.  If the failing attempt asked for a minimum
        wait (``retry_after``), the larger of the two is used.  The result is
        never above ``max_delay``.
        """
        if failures < 1:
            raise ValueError("failures must be at least 1")
        delay = self.base_delay * self.multiplier ** (failures - 1)
        if retry_after is not None and retry_after > delay:
            delay = retry_after
        return float(min(delay, self.max_delay))

    def exhausted(self, attempts):
        """True once a job has used up its ``max_attempts``."""
        return attempts >= self.max_attempts
