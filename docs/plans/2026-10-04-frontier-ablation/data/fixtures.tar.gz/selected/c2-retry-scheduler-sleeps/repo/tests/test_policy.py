import unittest

from retrysched import BackoffPolicy, RetryAfter


class DelayTest(unittest.TestCase):
    def test_exponential_progression(self):
        policy = BackoffPolicy(base_delay=0.5, multiplier=3.0, max_delay=100.0)
        self.assertEqual([policy.delay_for(n) for n in (1, 2, 3, 4)], [0.5, 1.5, 4.5, 13.5])

    def test_capped_at_max_delay(self):
        policy = BackoffPolicy(base_delay=1.0, multiplier=2.0, max_delay=5.0)
        self.assertEqual([policy.delay_for(n) for n in (1, 2, 3, 4, 5)], [1.0, 2.0, 4.0, 5.0, 5.0])

    def test_retry_after_raises_the_wait(self):
        policy = BackoffPolicy()
        self.assertEqual(policy.delay_for(1, retry_after=7), 7.0)
        self.assertEqual(policy.delay_for(4, retry_after=7), 8.0)

    def test_retry_after_is_capped_too(self):
        policy = BackoffPolicy(max_delay=10.0)
        self.assertEqual(policy.delay_for(1, retry_after=45), 10.0)

    def test_failures_must_be_positive(self):
        with self.assertRaises(ValueError):
            BackoffPolicy().delay_for(0)

    def test_exhausted(self):
        policy = BackoffPolicy(max_attempts=3)
        self.assertFalse(policy.exhausted(2))
        self.assertTrue(policy.exhausted(3))


class ValidationTest(unittest.TestCase):
    def test_rejects_bad_settings(self):
        for settings in (
            {"base_delay": 0},
            {"multiplier": 0.5},
            {"base_delay": 5.0, "max_delay": 1.0},
            {"max_attempts": 0},
        ):
            with self.subTest(settings=settings):
                with self.assertRaises(ValueError):
                    BackoffPolicy(**settings)

    def test_retry_after_exception_carries_seconds(self):
        self.assertEqual(RetryAfter(12).retry_after, 12)


if __name__ == "__main__":
    unittest.main()
