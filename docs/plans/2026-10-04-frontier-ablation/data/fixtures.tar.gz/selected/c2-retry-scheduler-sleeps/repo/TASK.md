# `run()` keeps the worker asleep after the last job has finished

## What happens

The nightly sync worker sat idle for almost half a minute after its last job
had completed, and only then exited. On the bigger tenants, where upstream asks
for long pauses, it is many minutes. It only happens on nights where the
operator cancelled a job.

I boiled it down to this (it is `test_run_returns_when_last_job_is_done` in
`tests/test_scheduler.py`, which currently fails):

```python
from retrysched import BackoffPolicy, ManualClock, RetryAfter, RetryScheduler

clock = ManualClock()
scheduler = RetryScheduler(BackoffPolicy(), clock=clock.now, sleep=clock.sleep)

def report():                 # upstream asks us to come back in 30 seconds
    raise RetryAfter(30)

calls = []
def sync():                   # fails once, then works
    calls.append(clock.now())
    if len(calls) == 1:
        raise ConnectionError("reset by peer")

scheduler.submit("report", report)
scheduler.submit("sync", sync)
scheduler.tick()              # both fail and wait for their retry
scheduler.cancel("report")    # the operator drops the report job
scheduler.run()

print(clock.sleeps)           # [1.0, 29.0]
```

`sync` is retried after one second and succeeds, which is right. After that
nothing is left to do, but `run()` sleeps another 29 seconds before it returns.
I expect `clock.sleeps == [1.0]` and `clock.now() == 1.0` at the end.

Everything else in `tests/` passes.

## What I expect

The README describes how the scheduler is meant to wait. Once this is fixed all
of the following should be true, with any mix of `cancel` and `reschedule`
calls made while jobs are waiting:

* `run()` returns as soon as no job is pending. It does not sleep after the
  last job has succeeded, been given up on, or been cancelled.
* Every `sleep` call `run()` makes lasts exactly until the earliest job that is
  still waiting becomes due. A job that was cancelled, and the old time of a
  job that was rescheduled, never cause a sleep, never cut one short and never
  split one in two. For example: `a` is waiting for `t=1`, `b` is waiting for
  `t=20`, `a` is cancelled at `t=0`; `run()` must make the single call
  `sleep(20.0)`.
* A rescheduled job runs exactly once, at its new time (`reschedule(job, 10)`
  at `t=0` means the next attempt happens at `t=10`, whether that is earlier or
  later than before), and its attempt count carries on: if that attempt is its
  second failure, the next wait is the policy's wait for a second failure.
* `next_wakeup()` returns the time at which the earliest job that is still
  waiting becomes due, and `None` when no job is waiting. Cancelled jobs and
  the old times of rescheduled jobs do not show up in it.
* `pending_count()` is the number of jobs that are still waiting. Cancelling a
  waiting job lowers it by one; rescheduling a job does not change it.
* The existing behaviour stays as documented: waits of `base_delay`,
  `base_delay * multiplier`, ... capped at `max_delay`; `retry_after` honoured;
  a job is dropped with a `gave_up` event after `max_attempts` attempts; jobs
  due at the same time run in the order they were scheduled, and a rescheduled
  job counts as scheduled at the time of the `reschedule` call.

Please keep the public API as it is (method names, arguments, `history`
events); the workers and their tests depend on it.
