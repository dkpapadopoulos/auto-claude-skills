import unittest

from retrysched import RetryQueue


class RetryQueueTest(unittest.TestCase):
    def test_pops_in_due_order(self):
        queue = RetryQueue()
        queue.push("late", 9.0)
        queue.push("early", 2.0)
        queue.push("middle", 5.0)
        self.assertEqual(queue.pop_due(5.0), ["early", "middle"])
        self.assertEqual(queue.pop_due(100.0), ["late"])

    def test_equal_due_times_keep_push_order(self):
        queue = RetryQueue()
        for job_id in ("c", "a", "b"):
            queue.push(job_id, 3.0)
        self.assertEqual(queue.pop_due(3.0), ["c", "a", "b"])

    def test_nothing_due_yet(self):
        queue = RetryQueue()
        queue.push("job", 4.0)
        self.assertEqual(queue.pop_due(3.9), [])
        self.assertIn("job", queue)

    def test_len_and_next_due(self):
        queue = RetryQueue()
        self.assertEqual(len(queue), 0)
        self.assertIsNone(queue.next_due())
        queue.push("a", 7.0)
        queue.push("b", 3.0)
        self.assertEqual(len(queue), 2)
        self.assertEqual(queue.next_due(), 3.0)
        queue.pop_due(3.0)
        self.assertEqual(len(queue), 1)
        self.assertEqual(queue.next_due(), 7.0)

    def test_discarded_job_is_not_handed_out(self):
        queue = RetryQueue()
        queue.push("a", 1.0)
        queue.push("b", 2.0)
        self.assertTrue(queue.discard("a"))
        self.assertFalse(queue.discard("a"))
        self.assertNotIn("a", queue)
        self.assertEqual(queue.pop_due(10.0), ["b"])

    def test_pushing_again_replaces_the_due_time(self):
        queue = RetryQueue()
        queue.push("a", 1.0)
        queue.push("a", 6.0)
        self.assertEqual(queue.pop_due(5.0), [])
        self.assertEqual(queue.pop_due(6.0), ["a"])
        self.assertEqual(queue.pop_due(99.0), [])


if __name__ == "__main__":
    unittest.main()
