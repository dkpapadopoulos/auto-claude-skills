# retrysched

Runs flaky jobs until they succeed, with exponential backoff between attempts.
The sync workers use it for anything that talks to an upstream service.

Nothing in here reads the wall clock or sleeps by itself. The scheduler is given
a `clock` callable and a `sleep` callable; production code passes
`time.monotonic` and `time.sleep`, tests pass the two methods of a
`ManualClock`.

```python
from retrysched import BackoffPolicy, ManualClock, RetryScheduler

clock = ManualClock()
scheduler = RetryScheduler(BackoffPolicy(), clock=clock.now, sleep=clock.sleep)
scheduler.submit("sync", sync_once)
scheduler.run()
print(clock.sleeps)       # every sleep the scheduler asked for, in order
print(scheduler.history)  # one Event(time, job_id, attempt, outcome) per attempt
```

## Backoff

`BackoffPolicy(base_delay=1.0, multiplier=2.0, max_delay=60.0, max_attempts=5)`

* After its first failure a job waits `base_delay` seconds, after the second
  `base_delay * multiplier`, and so on; no wait is longer than `max_delay`.
* If the exception a job raised has a `retry_after` attribute (for example
  `raise RetryAfter(30)`), the job waits at least that long, still capped at
  `max_delay`.
* A job runs at most `max_attempts` times. Failing on the last allowed attempt
  is recorded as `gave_up` and the job is dropped.

## Scheduler

| Method | Behaviour |
|---|---|
| `submit(job_id, fn)` | add a job, due immediately; `ValueError` if that id is still pending |
| `cancel(job_id)` | drop a pending job so it never runs again; returns whether it was pending |
| `reschedule(job_id, delay)` | make a waiting job due `delay` seconds from now instead of when it was going to run; it runs once, at the new time, and keeps its attempt count |
| `tick()` | run everything that is due right now, once each, without sleeping; returns the number of attempts made |
| `run()` | run until nothing is pending, sleeping between wake-ups |
| `pending_count()` | number of jobs waiting for their first run or for a retry |
| `next_wakeup()` | time at which the next waiting job becomes due, `None` if none is waiting |
| `history` | list of `Event(time, job_id, attempt, outcome)`, outcome is `"ok"`, `"retry"` or `"gave_up"` |

Jobs that are due at the same time run in the order they were scheduled. A job
that has been rescheduled counts as scheduled at the moment of the
`reschedule` call.

`run()` sleeps exactly until the earliest waiting job becomes due, runs what is
due, and repeats. It returns as soon as nothing is pending and never calls
`sleep` with a zero or negative duration.

## Running the tests

```
python3 -m unittest discover -s tests
```
