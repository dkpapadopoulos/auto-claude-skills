"""A hand-driven clock for deterministic runs."""


class ManualClock:
    """Time that only moves when told to.

    Pass ``clock.now`` and ``clock.sleep`` to :class:`RetryScheduler`.  Every
    ``sleep`` call is appended to :attr:`sleeps`, so a test can check exactly
    how the scheduler waited.
    """

    def __init__(self, start=0.0):
        self._now = float(start)
        self.sleeps = []

    def now(self):
        """Current time in seconds."""
        return self._now

    def sleep(self, seconds):
        """Record a sleep of ``seconds`` and move the time forward by it.

        Like ``time.sleep`` this rejects negative durations with ``ValueError``.
        """
        if seconds < 0:
            raise ValueError("sleep length must be non-negative")
        self.sleeps.append(float(seconds))
        self._now += seconds

    def advance(self, seconds):
        """Move the time forward without recording a sleep.

        Useful inside a job function to model work that takes time.
        """
        if seconds < 0:
            raise ValueError("cannot move the clock backwards")
        self._now += seconds
