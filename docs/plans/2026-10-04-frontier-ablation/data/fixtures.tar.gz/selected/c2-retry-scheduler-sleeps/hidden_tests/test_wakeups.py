import unittest

from retrysched import (
    GAVE_UP,
    OK,
    RETRY,
    BackoffPolicy,
    ManualClock,
    RetryAfter,
    RetryScheduler,
)


def make(policy=None):
    clock = ManualClock()
    scheduler = RetryScheduler(policy or BackoffPolicy(), clock=clock.now, sleep=clock.sleep)
    return clock, scheduler


class Scripted:
    """Job that raises the scripted errors in turn and succeeds afterwards."""

    def __init__(self, clock, *errors):
        self.clock = clock
        self.errors = list(errors)
        self.calls = []

    def __call__(self):
        self.calls.append(self.clock.now())
        if self.errors:
            raise self.errors.pop(0)


class SleepsAfterCancelTest(unittest.TestCase):
    def test_no_sleep_after_last_job_when_later_job_was_cancelled(self):
        clock, scheduler = make()
        slow = Scripted(clock, RetryAfter(45), RetryAfter(45))
        quick = Scripted(clock, TimeoutError())
        scheduler.submit("slow", slow)
        scheduler.submit("quick", quick)
        scheduler.tick()
        self.assertTrue(scheduler.cancel("slow"))
        scheduler.run()
        self.assertEqual(clock.sleeps, [1.0])
        self.assertEqual(clock.now(), 1.0)
        self.assertEqual(slow.calls, [0.0])
        self.assertEqual(quick.calls, [0.0, 1.0])

    def test_cancelled_earlier_job_does_not_split_the_sleep(self):
        clock, scheduler = make()
        a = Scripted(clock, OSError())
        b = Scripted(clock, RetryAfter(20))
        scheduler.submit("a", a)
        scheduler.submit("b", b)
        scheduler.tick()
        scheduler.cancel("a")
        scheduler.run()
        self.assertEqual(clock.sleeps, [20.0])
        self.assertEqual(a.calls, [0.0])
        self.assertEqual(b.calls, [0.0, 20.0])

    def test_cancelled_jobs_between_waiting_jobs(self):
        clock, scheduler = make()
        jobs = {
            "a": Scripted(clock, OSError()),
            "b": Scripted(clock, RetryAfter(2)),
            "c": Scripted(clock, RetryAfter(5)),
            "d": Scripted(clock, RetryAfter(9)),
            "e": Scripted(clock, RetryAfter(40)),
        }
        for job_id, job in jobs.items():
            scheduler.submit(job_id, job)
        self.assertEqual(scheduler.tick(), 5)
        for job_id in ("a", "c", "e"):
            self.assertTrue(scheduler.cancel(job_id))
        scheduler.run()
        self.assertEqual(clock.sleeps, [2.0, 7.0])
        self.assertEqual(clock.now(), 9.0)
        self.assertEqual(jobs["b"].calls, [0.0, 2.0])
        self.assertEqual(jobs["d"].calls, [0.0, 9.0])
        for job_id in ("a", "c", "e"):
            self.assertEqual(jobs[job_id].calls, [0.0])


class SleepsAfterRescheduleTest(unittest.TestCase):
    def test_rescheduling_later_gives_one_sleep_to_the_new_time(self):
        clock, scheduler = make()
        job = Scripted(clock, OSError())
        scheduler.submit("job", job)
        scheduler.tick()
        scheduler.reschedule("job", 10)
        scheduler.run()
        self.assertEqual(clock.sleeps, [10.0])
        self.assertEqual(job.calls, [0.0, 10.0])

    def test_rescheduling_earlier_leaves_nothing_to_wait_for(self):
        clock, scheduler = make()
        job = Scripted(clock, RetryAfter(30))
        scheduler.submit("job", job)
        scheduler.tick()
        scheduler.reschedule("job", 2)
        scheduler.run()
        self.assertEqual(clock.sleeps, [2.0])
        self.assertEqual(clock.now(), 2.0)
        self.assertEqual(job.calls, [0.0, 2.0])

    def test_rescheduled_job_runs_once_and_backoff_carries_on(self):
        clock, scheduler = make()
        job = Scripted(clock, OSError(), OSError())
        scheduler.submit("job", job)
        scheduler.tick()
        scheduler.reschedule("job", 10)
        scheduler.run()
        self.assertEqual(job.calls, [0.0, 10.0, 12.0])
        self.assertEqual(clock.sleeps, [10.0, 2.0])
        self.assertEqual(
            [(event.time, event.attempt, event.outcome) for event in scheduler.history],
            [(0.0, 1, RETRY), (10.0, 2, RETRY), (12.0, 3, OK)],
        )


class DocumentedBackoffTest(unittest.TestCase):
    def test_waits_grow_and_are_capped(self):
        clock, scheduler = make(BackoffPolicy(base_delay=1.0, multiplier=3.0, max_delay=5.0))
        job = Scripted(clock, OSError(), OSError(), OSError(), RetryAfter(90))
        scheduler.submit("job", job)
        scheduler.run()
        self.assertEqual(clock.sleeps, [1.0, 3.0, 5.0, 5.0])
        self.assertEqual(scheduler.history[-1].outcome, OK)

    def test_job_is_given_up_after_max_attempts(self):
        clock, scheduler = make(BackoffPolicy(max_attempts=3))
        job = Scripted(clock, OSError(), OSError(), OSError(), OSError())
        scheduler.submit("job", job)
        scheduler.run()
        self.assertEqual(job.calls, [0.0, 1.0, 3.0])
        self.assertEqual(clock.sleeps, [1.0, 2.0])
        self.assertEqual(
            [(event.attempt, event.outcome) for event in scheduler.history],
            [(1, RETRY), (2, RETRY), (3, GAVE_UP)],
        )
        self.assertEqual(scheduler.pending_count(), 0)


if __name__ == "__main__":
    unittest.main()
