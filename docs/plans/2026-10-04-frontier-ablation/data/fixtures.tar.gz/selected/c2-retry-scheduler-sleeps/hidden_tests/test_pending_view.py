import unittest

from retrysched import BackoffPolicy, ManualClock, RetryAfter, RetryScheduler


def make():
    clock = ManualClock()
    scheduler = RetryScheduler(BackoffPolicy(), clock=clock.now, sleep=clock.sleep)
    return clock, scheduler


def failing_once(error, log=None, name=None):
    """Job that raises ``error`` on its first call and succeeds afterwards."""
    state = {"calls": 0}

    def job():
        state["calls"] += 1
        if log is not None:
            log.append(name)
        if state["calls"] == 1:
            raise error

    return job


class NextWakeupTest(unittest.TestCase):
    def test_next_wakeup_skips_cancelled_job(self):
        clock, scheduler = make()
        scheduler.submit("a", failing_once(OSError()))
        scheduler.submit("b", failing_once(RetryAfter(20)))
        scheduler.tick()
        self.assertEqual(scheduler.next_wakeup(), 1.0)
        scheduler.cancel("a")
        self.assertEqual(scheduler.next_wakeup(), 20.0)

    def test_next_wakeup_is_none_once_only_waiting_job_is_cancelled(self):
        clock, scheduler = make()
        scheduler.submit("a", failing_once(OSError()))
        scheduler.tick()
        scheduler.cancel("a")
        self.assertIsNone(scheduler.next_wakeup())

    def test_next_wakeup_follows_reschedule(self):
        clock, scheduler = make()
        scheduler.submit("a", failing_once(OSError()))
        scheduler.tick()
        scheduler.reschedule("a", 10)
        self.assertEqual(scheduler.next_wakeup(), 10.0)


class PendingCountTest(unittest.TestCase):
    def test_cancel_lowers_pending_count(self):
        clock, scheduler = make()
        scheduler.submit("a", failing_once(OSError()))
        scheduler.submit("b", failing_once(RetryAfter(20)))
        scheduler.tick()
        self.assertEqual(scheduler.pending_count(), 2)
        scheduler.cancel("b")
        self.assertEqual(scheduler.pending_count(), 1)
        scheduler.run()
        self.assertEqual(scheduler.pending_count(), 0)

    def test_reschedule_keeps_pending_count(self):
        clock, scheduler = make()
        scheduler.submit("a", failing_once(OSError()))
        scheduler.tick()
        scheduler.reschedule("a", 3)
        scheduler.reschedule("a", 6)
        self.assertEqual(scheduler.pending_count(), 1)


class SameTimeOrderTest(unittest.TestCase):
    def test_rescheduled_job_goes_behind_jobs_already_due_at_that_time(self):
        clock, scheduler = make()
        log = []
        scheduler.submit("a", failing_once(OSError(), log, "a"))
        scheduler.submit("b", failing_once(OSError(), log, "b"))
        scheduler.tick()
        self.assertEqual(log, ["a", "b"])
        scheduler.reschedule("a", 1)
        scheduler.run()
        self.assertEqual(log, ["a", "b", "b", "a"])
        self.assertEqual(clock.sleeps, [1.0])


if __name__ == "__main__":
    unittest.main()
