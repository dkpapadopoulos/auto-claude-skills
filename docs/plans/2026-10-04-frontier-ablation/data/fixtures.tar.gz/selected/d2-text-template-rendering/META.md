# Contract traceability

| Test | Exact contract sentence(s) in TASK.md |
|---|---|
| `test_opaque_replacements` | Values are rendered once as opaque text: delimiter-looking replacement text is never parsed or expanded again; contexts are never mutated, and compiled templates may be reused with different contexts. |
| `test_falsey_values` | Present values use str(), except None renders as empty text; zero, False and the empty string are present values, and a non-mapping intermediate node is missing. |
| `test_filter_order` | The language replaces `{{ path }}` using dotted mapping keys only, allows whitespace around path and filters, and supports ordered `upper`, `lower`, and `html` filters separated by `\|`; html uses html.escape with quote=True, in written filter order. |
| `test_compiled_default` | Public API: `renderer.Template(source)` with `.fields` and `.render(context, *, missing="error")`, and `renderer.render(source, context, *, missing="error")`. Absent paths raise renderer.MissingValue (a KeyError) by default with the full dotted path as args[0]; missing="empty" substitutes empty text and missing="keep" preserves the entire original placeholder including filters and spaces; other policies raise ValueError. |
| `test_missing_modes` | Absent paths raise renderer.MissingValue (a KeyError) by default with the full dotted path as args[0]; missing="empty" substitutes empty text and missing="keep" preserves the entire original placeholder including filters and spaces; other policies raise ValueError. |
| `test_mapping_only` | The language replaces `{{ path }}` using dotted mapping keys only, allows whitespace around path and filters, and supports ordered `upper`, `lower`, and `html` filters separated by `\|`; html uses html.escape with quote=True, in written filter order. Present values use str(), except None renders as empty text; zero, False and the empty string are present values, and a non-mapping intermediate node is missing. Absent paths raise renderer.MissingValue (a KeyError) by default with the full dotted path as args[0]; missing="empty" substitutes empty text and missing="keep" preserves the entire original placeholder including filters and spaces; other policies raise ValueError. |
| `test_escaped` | A backslash immediately before `{{` removes that backslash and treats the complete placeholder as literal text; single braces and stray `}}` remain literal. Empty input renders empty text; unclosed placeholders, invalid dotted identifiers, and unknown or empty filters raise syntax.TemplateSyntaxError (a ValueError) at compilation, even if a value would be missing; escaped placeholders do not validate field contents but must close. |
| `test_syntax_errors` | Empty input renders empty text; unclosed placeholders, invalid dotted identifiers, and unknown or empty filters raise syntax.TemplateSyntaxError (a ValueError) at compilation, even if a value would be missing; escaped placeholders do not validate field contents but must close. |
| `test_fields_and_empty` | Empty input renders empty text; unclosed placeholders, invalid dotted identifiers, and unknown or empty filters raise syntax.TemplateSyntaxError (a ValueError) at compilation, even if a value would be missing; escaped placeholders do not validate field contents but must close. Template.fields is a tuple of unique unescaped paths in first appearance order. |
| `test_reuse` | The language replaces `{{ path }}` using dotted mapping keys only, allows whitespace around path and filters, and supports ordered `upper`, `lower`, and `html` filters separated by `\|`; html uses html.escape with quote=True, in written filter order. Values are rendered once as opaque text: delimiter-looking replacement text is never parsed or expanded again; contexts are never mutated, and compiled templates may be reused with different contexts. |

Trap: Correcting defaults and filters still recursively interprets replacement text.

Four independent defects (in overlay patch order):
- Replacement values are recursively parsed instead of remaining opaque.
- Falsey present values are incorrectly classified as missing.
- Filter pipelines execute in reverse order.
- Compiled templates have the wrong missing-value default.
