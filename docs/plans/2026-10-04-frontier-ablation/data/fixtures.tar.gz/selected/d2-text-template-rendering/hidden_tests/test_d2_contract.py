import unittest
from renderer import Template, render, MissingValue
from syntax import TemplateSyntaxError

class ContractTests(unittest.TestCase):

    def test_opaque_replacements(self):
        self.assertEqual(render('{{a}}', {'a': '{{b}}', 'b': 'expanded'}), '{{b}}')
        self.assertEqual(render('{{a}}', {'a': '{{unclosed'}), '{{unclosed')

    def test_falsey_values(self):
        self.assertEqual(render('{{z}}/{{f}}/{{e}}/{{n}}', {'z': 0, 'f': False, 'e': '', 'n': None}), '0/False//')

    def test_filter_order(self):
        self.assertEqual(render('{{x|html|upper}}', {'x': '<a>'}), '&LT;A&GT;')
        self.assertEqual(render('{{x|upper|html}}', {'x': '<a>'}), '&lt;A&gt;')
        self.assertEqual(render('{{x|html}}', {'x': '"'}), '&quot;')

    def test_compiled_default(self):
        with self.assertRaises(MissingValue) as caught:
            Template('{{person.name}}').render({})
        self.assertEqual(caught.exception.args[0], 'person.name')

    def test_missing_modes(self):
        t = Template('x{{ a.b | upper }}y')
        self.assertEqual(t.render({}, missing='empty'), 'xy')
        self.assertEqual(t.render({}, missing='keep'), 'x{{ a.b | upper }}y')
        with self.assertRaises(ValueError):
            t.render({}, missing='guess')

    def test_mapping_only(self):
        self.assertEqual(render('{{a.b}}', {'a': 3}, missing='keep'), '{{a.b}}')
        self.assertEqual(render('{{a.b}}', {'a': {'b': 'yes'}}), 'yes')

    def test_escaped(self):
        self.assertEqual(render(chr(92) + '{{bad-name}} {{x}}', {'x': 'ok'}), '{{bad-name}} ok')
        self.assertEqual(render('{x} }}', {}), '{x} }}')

    def test_syntax_errors(self):
        for source in ['{{x', '{{a..b}}', '{{x|wat}}', '{{x|}}', chr(92) + '{{x']:
            with self.subTest(source=source):
                with self.assertRaises(TemplateSyntaxError):
                    Template(source)

    def test_fields_and_empty(self):
        self.assertEqual(Template('{{b}} {{a}} {{b|upper}} ' + chr(92) + '{{c}}').fields, ('b', 'a'))
        self.assertEqual(render('', {}), '')

    def test_reuse(self):
        t = Template('{{ user.name | upper }}')
        context = {'user': {'name': 'Ada'}}
        self.assertEqual(t.render(context), 'ADA')
        self.assertEqual(t.render({'user': {'name': 'Bea'}}), 'BEA')
        self.assertEqual(context, {'user': {'name': 'Ada'}})
