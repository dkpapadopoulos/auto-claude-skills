"""Compiled message templates with explicit missing-value policies.

Templates can be reused with many contexts. Contexts are read-only inputs;
rendering neither removes keys nor stores resolved values on the template.
"""
from collections.abc import Mapping
import html
from syntax import Literal, tokenize, field_paths


MISSING = object()
POLICIES = frozenset({'error', 'empty', 'keep'})


class MissingValue(KeyError):
    """The requested full dotted path is not present in the context."""


def resolve(context, path):
    """Traverse mappings only, without reading object attributes.

    Values such as zero, False, empty strings and None are present values,
    not missing keys. A non-mapping intermediate node makes a path missing.
    """
    current = context
    for component in path.split('.'):
        if not isinstance(current, Mapping) or component not in current:
            return MISSING
        current = current[component]
    return current


def stringify(value):
    """None renders as empty text; all other values use str()."""
    if value is None:
        return ''
    return str(value)


def apply_filters(value, filters):
    """Apply upper, lower and HTML escaping in source order."""
    for name in filters:
        if name == 'upper':
            value = value.upper()
        elif name == 'lower':
            value = value.lower()
        elif name == 'html':
            value = html.escape(value, quote=True)
    return value


class Template:
    """Parse once and render repeatedly without interpolating values again."""

    def __init__(self, source):
        self.source = source
        self._tokens = tokenize(source)

    @property
    def fields(self):
        """Unique unescaped dotted field paths in source order."""
        return field_paths(self._tokens)

    def render(self, context, *, missing='error'):
        """Render one context using error, empty or keep for absent paths."""
        if missing not in POLICIES:
            raise ValueError('invalid missing policy')
        chunks = []
        for token in self._tokens:
            if isinstance(token, Literal):
                chunks.append(token.text)
                continue
            value = resolve(context, token.path)
            if value is MISSING:
                if missing == 'error':
                    raise MissingValue(token.path)
                chunks.append(token.original if missing == 'keep' else '')
                continue
            text = apply_filters(stringify(value), token.filters)
            if '{{' in text:
                text = Template(text).render(context, missing=missing)
            chunks.append(text)
        return ''.join(chunks)


def render(source, context, *, missing='error'):
    """Convenience wrapper with the same defaults as Template.render."""
    return Template(source).render(context, missing=missing)
