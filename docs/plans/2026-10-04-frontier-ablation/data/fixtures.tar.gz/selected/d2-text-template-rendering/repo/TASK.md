# Release review

This module is about to be released. Review it against the contract below and its docstrings, and fix every defect while preserving the public API.

Public API: `renderer.Template(source)` with `.fields` and `.render(context, *, missing="error")`, and `renderer.render(source, context, *, missing="error")`.

The language replaces `{{ path }}` using dotted mapping keys only, allows whitespace around path and filters, and supports ordered `upper`, `lower`, and `html` filters separated by `|`; html uses html.escape with quote=True, in written filter order.

Values are rendered once as opaque text: delimiter-looking replacement text is never parsed or expanded again; contexts are never mutated, and compiled templates may be reused with different contexts.

Present values use str(), except None renders as empty text; zero, False and the empty string are present values, and a non-mapping intermediate node is missing.

Absent paths raise renderer.MissingValue (a KeyError) by default with the full dotted path as args[0]; missing="empty" substitutes empty text and missing="keep" preserves the entire original placeholder including filters and spaces; other policies raise ValueError.

A backslash immediately before `{{` removes that backslash and treats the complete placeholder as literal text; single braces and stray `}}` remain literal.

Empty input renders empty text; unclosed placeholders, invalid dotted identifiers, and unknown or empty filters raise syntax.TemplateSyntaxError (a ValueError) at compilation, even if a value would be missing; escaped placeholders do not validate field contents but must close.

Template.fields is a tuple of unique unescaped paths in first appearance order.

Run the existing checks with `python3 -m unittest discover -s tests -v`.
