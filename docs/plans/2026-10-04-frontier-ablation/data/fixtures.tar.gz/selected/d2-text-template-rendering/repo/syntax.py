"""Tokenizer for the deliberately small notification template language.

Only double-brace placeholders are interpreted. Single braces are ordinary
text. A backslash immediately before an opening delimiter quotes that whole
placeholder. Tokens retain their source spelling for missing='keep'.
"""
from dataclasses import dataclass
import re


NAME = re.compile(r'[A-Za-z_][A-Za-z0-9_]*(?:[.][A-Za-z_][A-Za-z0-9_]*)*\Z')
FILTERS = frozenset({'upper', 'lower', 'html'})


class TemplateSyntaxError(ValueError):
    """A placeholder has invalid syntax or an unknown filter."""


@dataclass(frozen=True)
class Literal:
    """Text that must be copied without further interpretation."""

    text: str


@dataclass(frozen=True)
class Field:
    """A field path and its ordered pipeline of transformations."""

    path: str
    filters: tuple[str, ...]
    original: str


def parse_field(raw):
    """Parse a complete {{...}} token, allowing surrounding whitespace."""
    pieces = raw[2:-2].split('|')
    path = pieces[0].strip()
    if not NAME.fullmatch(path):
        raise TemplateSyntaxError('invalid field name')
    filters = tuple(piece.strip() for piece in pieces[1:])
    if any(name not in FILTERS for name in filters):
        raise TemplateSyntaxError('unknown filter')
    return Field(path, filters, raw)


def tokenize(source):
    """Return immutable tokens, including escaped literal placeholders.

    An unmatched opening delimiter is invalid even when escaped. A stray
    closing delimiter has no special significance and remains literal text.
    Adjacent literal fragments need not be coalesced by callers.
    """
    tokens = []
    cursor = 0
    while cursor < len(source):
        opening = source.find('{{', cursor)
        if opening < 0:
            tokens.append(Literal(source[cursor:]))
            break
        closing = source.find('}}', opening + 2)
        if closing < 0:
            raise TemplateSyntaxError('unclosed field')
        escaped = opening > cursor and source[opening - 1] == chr(92)
        prefix_end = opening - 1 if escaped else opening
        if prefix_end > cursor:
            tokens.append(Literal(source[cursor:prefix_end]))
        raw = source[opening:closing + 2]
        if escaped:
            tokens.append(Literal(raw))
        else:
            tokens.append(parse_field(raw))
        cursor = closing + 2
    return tuple(tokens)


def field_paths(tokens):
    """List unique field paths in first appearance order."""
    seen = set()
    paths = []
    for token in tokens:
        if isinstance(token, Field) and token.path not in seen:
            seen.add(token.path)
            paths.append(token.path)
    return tuple(paths)
