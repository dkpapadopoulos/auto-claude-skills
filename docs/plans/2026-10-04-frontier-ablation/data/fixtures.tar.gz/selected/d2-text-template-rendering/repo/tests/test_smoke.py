import unittest
from renderer import Template, render, MissingValue
from syntax import TemplateSyntaxError

class SmokeTests(unittest.TestCase):

    def test_greeting(self):
        self.assertEqual(render('Hi {{user.name|upper}}', {'user': {'name': 'Ada'}}), 'Hi ADA')

    def test_missing_default(self):
        with self.assertRaises(MissingValue):
            Template('{{name}}').render({})
