# Bank export only partly imports: "invalid amount" on rows that look fine

Finance sent over a March export that `ledgercsv.load` refuses to import
completely. Their export tool right-aligns the amount column, so the amounts
arrive padded with spaces:

```
date,description,amount,category
2024-03-01,Coffee beans,  12.50,office
2024-03-02,"Taxi, airport",  40.00,travel
2024-03-03,"Lunch, team", 118.20,meals
```

Loading this gives one row and two rejects:

```
line 3: amount: invalid (invalid amount '  40.00')
line 4: amount: invalid (invalid amount ' 118.20')
```

Line 2 has exactly the same padding and imports without complaint, which is
what makes this confusing. Finance cannot change the export format.

`tests/test_loader.py` has a test for this file,
`LoaderTests.test_padded_export_loads`, and it currently fails. Run the tests
with `python3 -m unittest discover -s tests`.

## What should be true when this is done

1. The file above loads with no rejects, and the three amounts are
   `Decimal("12.50")`, `Decimal("40.00")` and `Decimal("118.20")`.

2. The field rules in `README.md` hold for every field of every record, in
   every column and for every column kind (text, amount, date, integer), both
   in what `iter_records` yields and in what `load` returns:

   * Spaces and tabs around an unquoted field are not part of its value.
   * A quoted field is taken verbatim, including leading and trailing
     whitespace inside the quotes.
   * An unquoted field that is empty, or holds only spaces and tabs, is a
     missing value. `iter_records` reports it as `None`; `load` gives an
     optional column its default and rejects the record with problem
     `"missing"` when the column is required.
   * A quoted empty field (`""`) is an explicit empty string, never a missing
     value. `iter_records` reports it as `""`, and an optional text column
     keeps `""` instead of taking its default.

3. Values that really are malformed (for example `4O.00` with a letter O) are
   still rejected with problem `"invalid"`, and a reject's `line` is still the
   line on which its record starts, also when an earlier quoted field spans
   several lines.

4. Rows that load must be grouped correctly by `totals_by`: two rows of the
   same category end up under one key.

Please keep the public names and signatures listed in `README.md` as they are.
