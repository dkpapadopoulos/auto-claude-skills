"""Turn CSV text into typed rows.

``load`` reads the header record, binds its names to the schema and converts
every following record.  Records that cannot be converted are not fatal: they
are collected as ``Reject`` entries so the caller can show them to a person.
"""

from typing import Any, Dict, List, NamedTuple, Optional

from .schema import LEDGER_SCHEMA, Column, FieldError, Schema
from .tokenizer import Record, iter_records


class HeaderError(ValueError):
    """The header record does not fit the schema."""


class Reject(NamedTuple):
    """A record that was not imported.

    ``line``     1-based line on which the record starts
    ``column``   name of the offending column, ``None`` for ``field-count``
    ``problem``  ``"field-count"``, ``"missing"`` or ``"invalid"``
    ``detail``   human-readable explanation (wording may change)
    """

    line: int
    column: Optional[str]
    problem: str
    detail: str


class LoadResult(NamedTuple):
    rows: List[Dict[str, Any]]
    rejects: List[Reject]


def _bind_header(header: Record, schema: Schema) -> List[Optional[Column]]:
    """Map each header position to its schema column (``None`` = ignored).

    Header names are matched case-insensitively and ignoring surrounding
    whitespace, even when the name is quoted.  Columns the schema does not
    know are ignored.
    """
    layout: List[Optional[Column]] = []
    seen = set()
    for raw in header.values:
        column = schema.find((raw or "").strip())
        if column is not None:
            if column.name in seen:
                raise HeaderError(f"duplicate column {column.name!r}")
            seen.add(column.name)
        layout.append(column)
    missing = [c.name for c in schema if c.required and c.name not in seen]
    if missing:
        raise HeaderError("missing required column(s): " + ", ".join(missing))
    return layout


def _convert(record: Record, layout: List[Optional[Column]],
             schema: Schema) -> Dict[str, Any]:
    # Optional columns that are absent from the file keep their default.
    row = {column.name: column.default for column in schema}
    for column, raw in zip(layout, record.values):
        if column is not None:
            row[column.name] = column.convert(raw)
    return row


def load(text: str, schema: Schema = LEDGER_SCHEMA,
         delimiter: str = ",") -> LoadResult:
    """Load ``text`` and return ``LoadResult(rows, rejects)``.

    The first record is the header.  Every row is a dict with one key per
    schema column, in schema order.  A record is rejected - and reported in
    ``rejects`` in file order - when

    * its number of fields differs from the header's (``field-count``),
    * a required column has no value (``missing``), or
    * a value is not well-formed for its column's kind (``invalid``).

    Only the first offending column of a record is reported.  Malformed CSV
    (``CsvSyntaxError``) and an unusable header (``HeaderError``) are raised,
    not collected.
    """
    records = iter_records(text, delimiter)
    header = next(records, None)
    if header is None:
        raise HeaderError("no header record")
    layout = _bind_header(header, schema)

    rows: List[Dict[str, Any]] = []
    rejects: List[Reject] = []
    for record in records:
        if len(record.values) != len(layout):
            detail = f"expected {len(layout)} fields, got {len(record.values)}"
            rejects.append(Reject(record.line, None, "field-count", detail))
            continue
        try:
            rows.append(_convert(record, layout, schema))
        except FieldError as exc:
            rejects.append(Reject(record.line, exc.column, exc.problem, exc.detail))
    return LoadResult(rows, rejects)
