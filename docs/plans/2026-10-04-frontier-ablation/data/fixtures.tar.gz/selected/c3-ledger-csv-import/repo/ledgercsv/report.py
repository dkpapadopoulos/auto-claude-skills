"""Small reports over loaded rows."""

from decimal import Decimal
from typing import Any, Dict, Iterable, List

from .loader import Reject


def totals_by(rows: Iterable[Dict[str, Any]], key: str = "category",
              amount: str = "amount") -> Dict[Any, Decimal]:
    """Sum ``amount`` per distinct value of ``key``.

    The result keeps the order in which the key values first appear.  Rows
    whose amount is ``None`` are counted as zero.
    """
    totals: Dict[Any, Decimal] = {}
    for row in rows:
        value = row[amount]
        if value is None:
            value = Decimal("0")
        totals[row[key]] = totals.get(row[key], Decimal("0")) + value
    return totals


def format_rejects(rejects: Iterable[Reject]) -> List[str]:
    """Render rejects as one line of text each, for showing to a person."""
    lines = []
    for reject in rejects:
        where = f"line {reject.line}"
        if reject.column is not None:
            where += f": {reject.column}"
        lines.append(f"{where}: {reject.problem} ({reject.detail})")
    return lines
