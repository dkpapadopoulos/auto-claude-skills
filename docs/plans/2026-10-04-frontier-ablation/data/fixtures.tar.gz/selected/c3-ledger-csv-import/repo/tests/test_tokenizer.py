import unittest

from ledgercsv.tokenizer import CsvSyntaxError, iter_records


def values(text, **kwargs):
    return [record.values for record in iter_records(text, **kwargs)]


class TokenizerTests(unittest.TestCase):
    def test_plain_fields_are_trimmed(self):
        self.assertEqual(values("a , b ,\tc\n"), [["a", "b", "c"]])

    def test_empty_unquoted_fields_are_missing(self):
        self.assertEqual(values("a,,c\n,x\ny,\n"),
                         [["a", None, "c"], [None, "x"], ["y", None]])

    def test_quoted_field_keeps_delimiters_and_quotes(self):
        self.assertEqual(values('1,"say ""hi"", ok",3\n'),
                         [["1", 'say "hi", ok', "3"]])

    def test_quoted_field_keeps_its_whitespace(self):
        self.assertEqual(values('"  a  ",b\n'), [["  a  ", "b"]])

    def test_quoted_empty_field_is_empty_string(self):
        self.assertEqual(values('"",x\n'), [["", "x"]])

    def test_blanks_around_a_quoted_field_are_ignored(self):
        self.assertEqual(values('a,  "b c"  ,d\n'), [["a", "b c", "d"]])

    def test_multiline_field_and_line_numbers(self):
        records = list(iter_records('"a\nb",x\n\nnext,y'))
        self.assertEqual([(r.line, r.values) for r in records],
                         [(1, ["a\nb", "x"]), (4, ["next", "y"])])

    def test_blank_lines_are_skipped(self):
        self.assertEqual(values("a,b\n\n   \nc,d\n"), [["a", "b"], ["c", "d"]])

    def test_crlf_line_endings(self):
        self.assertEqual(values("a,b\r\nc,d\r\n"), [["a", "b"], ["c", "d"]])

    def test_other_delimiter(self):
        self.assertEqual(values("a;b,c;d\n", delimiter=";"), [["a", "b,c", "d"]])

    def test_unterminated_quote(self):
        with self.assertRaises(CsvSyntaxError) as caught:
            list(iter_records('a,b\nc,"d\ne,f\n'))
        self.assertEqual(caught.exception.line, 2)

    def test_text_after_closing_quote(self):
        with self.assertRaises(CsvSyntaxError):
            list(iter_records('"a"b,c\n'))


if __name__ == "__main__":
    unittest.main()
