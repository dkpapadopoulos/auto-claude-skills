import unittest
from datetime import date
from decimal import Decimal

from ledgercsv import HeaderError, Reject, format_rejects, load, totals_by

HEADER = "date,description,amount,category\n"


class LoaderTests(unittest.TestCase):
    def test_basic_rows(self):
        result = load(HEADER + "2024-03-01,Coffee beans,12.50,office\n"
                               "2024-03-04,Stamps,3.20,office\n")
        self.assertEqual(result.rejects, [])
        self.assertEqual(result.rows[0], {
            "date": date(2024, 3, 1),
            "description": "Coffee beans",
            "amount": Decimal("12.50"),
            "category": "office",
        })
        self.assertEqual(len(result.rows), 2)

    def test_quoted_description_with_delimiter(self):
        result = load(HEADER + '2024-03-01,"Miller, Smith and Co",99.00,legal\n')
        self.assertEqual(result.rejects, [])
        self.assertEqual(result.rows[0]["description"], "Miller, Smith and Co")
        self.assertEqual(result.rows[0]["amount"], Decimal("99.00"))

    def test_amount_with_thousands_separator(self):
        result = load(HEADER + '2024-03-01,Rent,"1,250.00",office\n')
        self.assertEqual(result.rows[0]["amount"], Decimal("1250.00"))

    def test_missing_category_takes_default(self):
        result = load(HEADER + "2024-03-01,Coffee beans,12.50,\n")
        self.assertEqual(result.rows[0]["category"], "uncategorized")

    def test_missing_amount_is_rejected(self):
        result = load(HEADER + "2024-03-01,Coffee beans,,office\n")
        self.assertEqual(result.rows, [])
        reject = result.rejects[0]
        self.assertEqual((reject.line, reject.column, reject.problem),
                         (2, "amount", "missing"))

    def test_malformed_amount_is_rejected(self):
        result = load(HEADER + "2024-03-01,Coffee beans,12.5O,office\n"
                               "2024-03-02,Stamps,3.20,office\n")
        self.assertEqual(len(result.rows), 1)
        reject = result.rejects[0]
        self.assertEqual((reject.line, reject.column, reject.problem),
                         (2, "amount", "invalid"))

    def test_wrong_field_count_is_rejected(self):
        result = load(HEADER + "2024-03-01,Coffee beans,12.50\n")
        self.assertIsInstance(result.rejects[0], Reject)
        self.assertEqual(result.rejects[0].problem, "field-count")
        self.assertIsNone(result.rejects[0].column)

    def test_header_matching(self):
        text = "Date, Amount ,Ref,DESCRIPTION\n2024-03-01,5.00,A-17,Stamps\n"
        result = load(text)
        self.assertEqual(result.rows, [{
            "date": date(2024, 3, 1),
            "description": "Stamps",
            "amount": Decimal("5.00"),
            "category": "uncategorized",
        }])

    def test_missing_required_column(self):
        with self.assertRaises(HeaderError):
            load("date,description\n2024-03-01,Stamps\n")

    def test_padded_export_loads(self):
        # The export right-aligns the amount column.
        text = (HEADER +
                "2024-03-01,Coffee beans,  12.50,office\n"
                '2024-03-02,"Taxi, airport",  40.00,travel\n'
                '2024-03-03,"Lunch, team", 118.20,meals\n')
        result = load(text)
        self.assertEqual(format_rejects(result.rejects), [])
        self.assertEqual([row["amount"] for row in result.rows],
                         [Decimal("12.50"), Decimal("40.00"), Decimal("118.20")])

    def test_totals_by_category(self):
        result = load(HEADER + "2024-03-01,Coffee beans,12.50,office\n"
                               "2024-03-02,Train,30.00,travel\n"
                               "2024-03-04,Stamps,3.20,office\n")
        self.assertEqual(totals_by(result.rows),
                         {"office": Decimal("15.70"), "travel": Decimal("30.00")})


if __name__ == "__main__":
    unittest.main()
