"""Character-level CSV tokenizer.

Field rules (the same list is in README.md):

* Fields are separated by the delimiter, records by a line break.
* A field may be written in double quotes.  A quoted field is taken verbatim:
  delimiters, line breaks and leading/trailing whitespace inside the quotes
  are part of the value, and ``""`` stands for one literal quote character.
* An unquoted field has the spaces and tabs around it removed.
* An unquoted field that is empty after that is a *missing* value and is
  reported as ``None``.  A quoted empty field (``""``) is the empty string.
* Spaces and tabs between a quoted field and the delimiters next to it are
  ignored; any other text there is a syntax error.
* Lines holding nothing but spaces and tabs are skipped.
* ``\\r\\n`` and a lone ``\\r`` are read as ``\\n``.

The rules apply to every field of every record.
"""

from typing import Iterator, List, NamedTuple, Optional

_BLANK = " \t"

# Scanner states.
_FIELD_START = "field-start"    # only blanks seen in the current field so far
_UNQUOTED = "unquoted"          # inside an unquoted field
_QUOTED = "quoted"              # inside a quoted field
_QUOTE_SEEN = "quote-seen"      # quote inside a quoted field: escape or end?
_AFTER_QUOTED = "after-quoted"  # quoted field closed, delimiter not yet seen


class CsvSyntaxError(ValueError):
    """The text is not well-formed CSV.  ``line`` is the 1-based line number."""

    def __init__(self, line: int, message: str):
        super().__init__(f"line {line}: {message}")
        self.line = line
        self.message = message


class Record(NamedTuple):
    """One record: the line it starts on and its field values."""

    line: int
    values: List[Optional[str]]


class _Scanner:
    """Consumes characters one at a time and assembles records."""

    def __init__(self, delimiter: str):
        self.delimiter = delimiter
        self.state = _FIELD_START
        self.chars: List[str] = []              # characters of the current field
        self.values: List[Optional[str]] = []   # finished fields of the record
        self.quoted = False                     # current field is a quoted one
        self.line = 1                           # line of the next character
        self.record_line = 1                    # line the current record began

    def _end_field(self) -> None:
        text = "".join(self.chars)
        if self.quoted:
            self.values.append(text)
        else:
            text = text.strip(_BLANK)
            self.values.append(text or None)
        self.chars = []
        self.state = _FIELD_START

    def _end_record(self) -> Optional[Record]:
        has_content = bool(
            self.values or self.quoted or "".join(self.chars).strip(_BLANK)
        )
        record = None
        if has_content:
            self._end_field()
            record = Record(self.record_line, self.values)
        self.chars = []
        self.values = []
        self.quoted = False
        self.state = _FIELD_START
        return record

    def feed(self, ch: str) -> Optional[Record]:
        """Consume one character; return a record if this character ends one."""
        if self.state == _QUOTED:
            if ch == '"':
                self.state = _QUOTE_SEEN
            else:
                if ch == "\n":
                    self.line += 1
                self.chars.append(ch)
            return None

        if self.state == _QUOTE_SEEN:
            if ch == '"':
                # A doubled quote is one literal quote; stay inside the field.
                self.chars.append('"')
                self.state = _QUOTED
                return None
            self.state = _AFTER_QUOTED

        if ch == self.delimiter:
            self._end_field()
            return None

        if ch == "\n":
            record = self._end_record()
            self.line += 1
            self.record_line = self.line
            return record

        if self.state == _AFTER_QUOTED:
            if ch not in _BLANK:
                raise CsvSyntaxError(self.line, "unexpected text after closing quote")
            return None

        if ch == '"':
            if self.state != _FIELD_START:
                raise CsvSyntaxError(self.line, "quote inside an unquoted field")
            self.chars = []     # blanks in front of the opening quote
            self.quoted = True
            self.state = _QUOTED
            return None

        self.chars.append(ch)
        if ch not in _BLANK:
            self.state = _UNQUOTED
        return None

    def finish(self) -> Optional[Record]:
        """Signal the end of the text; return the last record, if any."""
        if self.state == _QUOTED:
            raise CsvSyntaxError(self.record_line, "unterminated quoted field")
        return self._end_record()


def _check_delimiter(delimiter: str) -> None:
    if len(delimiter) != 1 or delimiter in '" \r\n':
        raise ValueError(f"unsupported delimiter {delimiter!r}")


def iter_records(text: str, delimiter: str = ",") -> Iterator[Record]:
    """Yield a ``Record`` for every non-blank record in ``text``.

    ``Record.values`` holds one entry per field: a ``str``, or ``None`` for a
    missing value (see the field rules in the module docstring).
    ``Record.line`` is the 1-based line on which the record starts; a quoted
    field that spans several lines makes the following records start further
    down.

    Raises ``CsvSyntaxError`` for malformed input and ``ValueError`` for an
    unsupported delimiter (it must be a single character other than a quote,
    a space or a line break).
    """
    _check_delimiter(delimiter)
    scanner = _Scanner(delimiter)
    for ch in text.replace("\r\n", "\n").replace("\r", "\n"):
        record = scanner.feed(ch)
        if record is not None:
            yield record
    record = scanner.finish()
    if record is not None:
        yield record
