# ledgercsv

A small importer for ledger exports. Standard library only.

```python
from ledgercsv import format_rejects, load, totals_by

result = load(open("march.csv", encoding="utf-8").read())
for line in format_rejects(result.rejects):
    print(line)
print(totals_by(result.rows))
```

## Public API

| name | what it does |
|---|---|
| `iter_records(text, delimiter=",")` | yields `Record(line, values)` for each record |
| `load(text, schema=LEDGER_SCHEMA, delimiter=",")` | returns `LoadResult(rows, rejects)` |
| `Schema`, `Column` | describe the columns of a file |
| `totals_by(rows, key="category", amount="amount")` | sums amounts per key |
| `format_rejects(rejects)` | one printable line per reject |

`LEDGER_SCHEMA` is `date` (date), `description` (text), `amount` (amount) and
an optional `category` (text, default `"uncategorized"`).

## Field rules

* Fields are separated by the delimiter, records by a line break.
* A field may be written in double quotes. A quoted field is taken verbatim:
  delimiters, line breaks and leading/trailing whitespace inside the quotes
  are part of the value, and `""` stands for one literal quote character.
* An unquoted field has the spaces and tabs around it removed.
* An unquoted field that is empty after that is a *missing* value:
  `iter_records` reports it as `None`. A quoted empty field (`""`) is the
  empty string, which is a value like any other.
* Spaces and tabs between a quoted field and the delimiters next to it are
  ignored.
* Lines holding nothing but spaces and tabs are skipped.
* `Record.line` is the 1-based line on which the record starts.

The rules apply to every field of every record.

## Loading

The first record is the header. Header names are matched to schema columns
case-insensitively; columns the schema does not know are ignored.

For each following record:

* a missing value in an optional column becomes the column's default;
* a missing value in a required column rejects the record with problem
  `"missing"`;
* a value that is not well-formed for the column's kind rejects the record
  with problem `"invalid"`;
* a record whose number of fields differs from the header's is rejected with
  problem `"field-count"`.

A `Reject` carries `line`, `column`, `problem` and a human-readable `detail`
whose wording is not part of the contract.

## Tests

```
python3 -m unittest discover -s tests
```
