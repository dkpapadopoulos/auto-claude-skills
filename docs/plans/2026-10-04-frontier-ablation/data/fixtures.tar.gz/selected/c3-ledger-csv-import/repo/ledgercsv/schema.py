"""Column definitions and value conversion.

Each column has a *kind* that decides how the text of a field becomes a value:

``text``     the text itself, unchanged
``amount``   ``decimal.Decimal``; digits with an optional sign, optional
             thousands separators (``1,250.00``) and at most two decimals
``date``     ``datetime.date`` from ``YYYY-MM-DD``
``integer``  ``int``; digits with an optional sign

The parsers are strict: they describe exactly what a well-formed value looks
like and refuse everything else.
"""

import re
from datetime import date
from decimal import Decimal
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional

_AMOUNT = re.compile(r"[+-]?(\d{1,3}(,\d{3})+|\d+)(\.\d{1,2})?")
_DATE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
_INTEGER = re.compile(r"[+-]?\d+")


class FieldError(ValueError):
    """A field cannot be turned into a value.

    ``problem`` is ``"missing"`` (a required column has no value) or
    ``"invalid"`` (the text is not a well-formed value of the column's kind).
    """

    def __init__(self, column: str, problem: str, detail: str):
        super().__init__(f"{column}: {problem} ({detail})")
        self.column = column
        self.problem = problem
        self.detail = detail


def parse_amount(value: str) -> Decimal:
    if not _AMOUNT.fullmatch(value):
        raise ValueError(f"invalid amount {value!r}")
    return Decimal(value.replace(",", ""))


def parse_date(value: str) -> date:
    match = _DATE.fullmatch(value)
    if not match:
        raise ValueError(f"invalid date {value!r}")
    year, month, day = (int(part) for part in match.groups())
    try:
        return date(year, month, day)
    except ValueError:
        raise ValueError(f"invalid date {value!r}") from None


def parse_integer(value: str) -> int:
    if not _INTEGER.fullmatch(value):
        raise ValueError(f"invalid integer {value!r}")
    return int(value)


def parse_text(value: str) -> str:
    return value


_PARSERS: Dict[str, Callable[[str], Any]] = {
    "amount": parse_amount,
    "date": parse_date,
    "integer": parse_integer,
    "text": parse_text,
}


class Column:
    """One column of a schema.

    A required column must have a value in every row.  An optional column
    takes ``default`` when its field is missing.
    """

    def __init__(self, name: str, kind: str = "text", required: bool = True,
                 default: Any = None):
        if kind not in _PARSERS:
            raise ValueError(f"unknown column kind {kind!r}")
        self.name = name
        self.kind = kind
        self.required = required
        self.default = default

    def convert(self, raw: Optional[str]) -> Any:
        """Convert the field text ``raw``; ``None`` means the value is missing."""
        if raw is None:
            if self.required:
                raise FieldError(self.name, "missing", "a value is required")
            return self.default
        try:
            return _PARSERS[self.kind](raw)
        except ValueError as exc:
            raise FieldError(self.name, "invalid", str(exc)) from None

    def __repr__(self) -> str:
        return f"Column({self.name!r}, {self.kind!r}, required={self.required})"


class Schema:
    """An ordered set of columns with unique (case-insensitive) names."""

    def __init__(self, columns: Iterable[Column]):
        self._columns: List[Column] = list(columns)
        self._by_name: Dict[str, Column] = {}
        for column in self._columns:
            key = column.name.lower()
            if key in self._by_name:
                raise ValueError(f"duplicate column {column.name!r}")
            self._by_name[key] = column

    def __iter__(self) -> Iterator[Column]:
        return iter(self._columns)

    def __len__(self) -> int:
        return len(self._columns)

    def find(self, name: str) -> Optional[Column]:
        """Return the column called ``name`` (any letter case), or ``None``."""
        return self._by_name.get(name.lower())


LEDGER_SCHEMA = Schema([
    Column("date", "date"),
    Column("description", "text"),
    Column("amount", "amount"),
    Column("category", "text", required=False, default="uncategorized"),
])
