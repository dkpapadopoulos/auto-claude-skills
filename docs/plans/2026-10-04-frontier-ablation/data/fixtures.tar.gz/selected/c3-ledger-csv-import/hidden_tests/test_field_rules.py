"""Field rules, checked through ``iter_records``."""

import unittest

from ledgercsv import iter_records


def values(text, **kwargs):
    return [record.values for record in iter_records(text, **kwargs)]


class FieldRuleTests(unittest.TestCase):
    def test_unquoted_fields_after_a_quoted_field_are_trimmed(self):
        self.assertEqual(values('"a b", c ,\td\t\n'), [["a b", "c", "d"]])

    def test_empty_unquoted_fields_after_a_quoted_field_are_missing(self):
        self.assertEqual(values('"x",,y,\n'), [["x", None, "y", None]])
        self.assertEqual(values('"x",  ,y\n'), [["x", None, "y"]])

    def test_quoted_fields_are_verbatim_wherever_they_are(self):
        self.assertEqual(values('" a ",b,"  "\n'), [[" a ", "b", "  "]])
        self.assertEqual(values('p , " q " , r\n'), [["p", " q ", "r"]])

    def test_quoted_empty_field_is_an_empty_string_not_missing(self):
        self.assertEqual(values('"",x,""\n'), [["", "x", ""]])
        self.assertEqual(values('x,"",\n'), [["x", "", None]])

    def test_rules_hold_after_a_multiline_quoted_field(self):
        records = list(iter_records('"line one\nline two", 7 ,\nnext, "q" , z \n'))
        self.assertEqual(
            [(record.line, record.values) for record in records],
            [(1, ["line one\nline two", "7", None]), (3, ["next", "q", "z"])],
        )

    def test_rules_hold_with_another_delimiter(self):
        self.assertEqual(values('"a;b"; c ;;"";d \n', delimiter=";"),
                         [["a;b", "c", None, "", "d"]])


if __name__ == "__main__":
    unittest.main()
