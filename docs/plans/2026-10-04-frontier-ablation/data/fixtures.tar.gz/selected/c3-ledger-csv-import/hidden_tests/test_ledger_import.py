"""The same field rules, checked through ``load`` and ``totals_by``."""

import unittest
from datetime import date
from decimal import Decimal

from ledgercsv import Column, Schema, load, totals_by

HEADER = "date,description,amount,category\n"


class LedgerImportTests(unittest.TestCase):
    def test_reported_export_loads(self):
        text = (HEADER +
                "2024-03-01,Coffee beans,  12.50,office\n"
                '2024-03-02,"Taxi, airport",  40.00,travel\n'
                '2024-03-03,"Lunch, team", 118.20,meals\n')
        result = load(text)
        self.assertEqual(result.rejects, [])
        self.assertEqual([row["amount"] for row in result.rows],
                         [Decimal("12.50"), Decimal("40.00"), Decimal("118.20")])
        self.assertEqual([row["description"] for row in result.rows],
                         ["Coffee beans", "Taxi, airport", "Lunch, team"])

    def test_padded_category_after_quoted_description(self):
        text = (HEADER +
                "2024-03-01,Train,15.00,travel\n"
                '2024-03-02,"Taxi, airport",40.00, travel \n')
        result = load(text)
        self.assertEqual(result.rejects, [])
        self.assertEqual(result.rows[1]["category"], "travel")
        self.assertEqual(totals_by(result.rows), {"travel": Decimal("55.00")})

    def test_blank_category_after_quoted_description_takes_default(self):
        text = (HEADER +
                '2024-03-02,"Taxi, airport",40.00,\n'
                '2024-03-03,"Lunch, team",18.20,  \n')
        result = load(text)
        self.assertEqual(result.rejects, [])
        self.assertEqual([row["category"] for row in result.rows],
                         ["uncategorized", "uncategorized"])

    def test_blank_amount_after_quoted_description_is_missing(self):
        text = (HEADER +
                "2024-03-01,Train,15.00,travel\n"
                '2024-03-02,"Taxi, airport",,travel\n')
        result = load(text)
        self.assertEqual(len(result.rows), 1)
        self.assertEqual(len(result.rejects), 1)
        reject = result.rejects[0]
        self.assertEqual((reject.line, reject.column, reject.problem),
                         (3, "amount", "missing"))

    def test_quoted_text_is_kept_verbatim(self):
        text = HEADER + '2024-03-02,"  indented, twice  ", 40.00 ," travel "\n'
        result = load(text)
        self.assertEqual(result.rejects, [])
        self.assertEqual(result.rows[0]["description"], "  indented, twice  ")
        self.assertEqual(result.rows[0]["category"], " travel ")
        self.assertEqual(result.rows[0]["amount"], Decimal("40.00"))

    def test_quoted_empty_category_is_not_defaulted(self):
        text = (HEADER +
                '2024-03-02,"Taxi, airport",40.00,""\n'
                '2024-03-03,Stamps,3.20,""\n')
        result = load(text)
        self.assertEqual(result.rejects, [])
        self.assertEqual([row["category"] for row in result.rows], ["", ""])

    def test_padded_date_and_integer_after_quoted_field(self):
        schema = Schema([
            Column("payee"),
            Column("paid_on", "date"),
            Column("items", "integer"),
            Column("amount", "amount"),
        ])
        text = ("payee,paid_on,items,amount\n"
                '"Miller, Smith and Co", 2024-03-05 , 3 ,\t7.25\n')
        result = load(text, schema)
        self.assertEqual(result.rejects, [])
        self.assertEqual(result.rows, [{
            "payee": "Miller, Smith and Co",
            "paid_on": date(2024, 3, 5),
            "items": 3,
            "amount": Decimal("7.25"),
        }])

    def test_malformed_amount_is_still_rejected_with_its_line(self):
        text = (HEADER +
                '2024-03-01,"Two-line\ndescription", 12.50 ,office\n'
                '2024-03-02,"Taxi, airport", 4O.00 ,travel\n'
                "2024-03-03,Stamps,3.20,office\n")
        result = load(text)
        self.assertEqual(len(result.rows), 2)
        self.assertEqual(len(result.rejects), 1)
        reject = result.rejects[0]
        self.assertEqual((reject.line, reject.column, reject.problem),
                         (4, "amount", "invalid"))


if __name__ == "__main__":
    unittest.main()
