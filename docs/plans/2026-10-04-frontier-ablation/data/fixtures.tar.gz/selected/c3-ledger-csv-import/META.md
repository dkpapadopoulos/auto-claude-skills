# c3-ledger-csv-import

Category c (debugging with a misleading symptom). Domain: CSV record parsing.

**Symptom site:** `ledgercsv/schema.py::parse_amount` raises `invalid amount '  40.00'`.
**Root cause:** `ledgercsv/tokenizer.py::_Scanner._end_field` never clears `self.quoted`, so
every unquoted field that follows a quoted field in the same record is treated as quoted:
it is not trimmed, and an empty one becomes `""` instead of `None`.

**Trap (one line):** stripping whitespace in `parse_amount` passes the visible tests, but the
quoted flag still leaks, so later text/date/integer fields stay untrimmed and blank fields are
no longer "missing".

## Hidden test -> requirement

`hidden_tests/test_field_rules.py` (`FieldRuleTests`, through `iter_records`)

| hidden test | required by |
|---|---|
| `test_unquoted_fields_after_a_quoted_field_are_trimmed` | TASK.md 2: "Spaces and tabs around an unquoted field are not part of its value." (rules "hold for every field of every record") |
| `test_empty_unquoted_fields_after_a_quoted_field_are_missing` | TASK.md 2: "An unquoted field that is empty, or holds only spaces and tabs, is a missing value. `iter_records` reports it as `None`" |
| `test_quoted_fields_are_verbatim_wherever_they_are` | TASK.md 2: "A quoted field is taken verbatim, including leading and trailing whitespace inside the quotes." plus README: "Spaces and tabs between a quoted field and the delimiters next to it are ignored." |
| `test_quoted_empty_field_is_an_empty_string_not_missing` | TASK.md 2: "A quoted empty field (`\"\"`) is an explicit empty string, never a missing value. `iter_records` reports it as `\"\"`" |
| `test_rules_hold_after_a_multiline_quoted_field` | TASK.md 2: "The field rules in `README.md` hold for every field of every record"; README: "`Record.line` is the 1-based line on which the record starts." |
| `test_rules_hold_with_another_delimiter` | TASK.md 2 (all four rules) with the documented `iter_records(text, delimiter=",")` parameter (README, Public API) |

`hidden_tests/test_ledger_import.py` (`LedgerImportTests`, through `load` / `totals_by`)

| hidden test | required by |
|---|---|
| `test_reported_export_loads` | TASK.md 1: "The file above loads with no rejects, and the three amounts are `Decimal(\"12.50\")`, `Decimal(\"40.00\")` and `Decimal(\"118.20\")`." |
| `test_padded_category_after_quoted_description` | TASK.md 2: "Spaces and tabs around an unquoted field are not part of its value."; TASK.md 4: "two rows of the same category end up under one key." |
| `test_blank_category_after_quoted_description_takes_default` | TASK.md 2: "`load` gives an optional column its default" |
| `test_blank_amount_after_quoted_description_is_missing` | TASK.md 2: "rejects the record with problem `\"missing\"` when the column is required." |
| `test_quoted_text_is_kept_verbatim` | TASK.md 2: "A quoted field is taken verbatim, including leading and trailing whitespace inside the quotes." |
| `test_quoted_empty_category_is_not_defaulted` | TASK.md 2: "an optional text column keeps `\"\"` instead of taking its default." |
| `test_padded_date_and_integer_after_quoted_field` | TASK.md 2: "in every column and for every column kind (text, amount, date, integer)" |
| `test_malformed_amount_is_still_rejected_with_its_line` | TASK.md 3: "Values that really are malformed (for example `4O.00` with a letter O) are still rejected with problem `\"invalid\"`, and a reject's `line` is still the line on which its record starts, also when an earlier quoted field spans several lines." |

## Overlays

* `solution/ledgercsv/tokenizer.py` - `_end_field` resets `self.quoted = False`.
* `wrong_fix/ledgercsv/schema.py` - `parse_amount` strips its argument (symptom-site patch).

## Expected results

| configuration | visible tests (23) | hidden tests (14) |
|---|---|---|
| untouched `repo/` | 1 fails (`test_padded_export_loads`) | 13 fail |
| `repo/` + `solution/` | all pass | all pass |
| `repo/` + `wrong_fix/` | all pass | 10 fail |
